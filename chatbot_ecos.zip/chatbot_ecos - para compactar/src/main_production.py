#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aplicação principal otimizada para produção
Sistema ECOS Chatbot Omnichannel
"""

import os
import sys
from flask import Flask, request, g
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.middleware.proxy_fix import ProxyFix

# Adiciona o diretório atual ao path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Imports dos módulos do sistema
from config.production import config
from models.multi_tenant import db
from utils.multi_tenant import MultiTenantManager

def create_app(config_name=None):
    """Factory para criar aplicação Flask otimizada"""
    
    # Determina configuração baseada no ambiente
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'production')
    
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    
    # Middleware para proxy reverso (nginx)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)
    
    # Inicializa extensões
    db.init_app(app)
    migrate = Migrate(app, db)
    
    # Inicializa configurações específicas
    config[config_name].init_app(app)
    
    # Middleware multi-tenant
    @app.before_request
    def load_clinic():
        """Carrega clínica baseada no domínio ou parâmetro"""
        try:
            # Tenta identificar pela URL
            host = request.host
            clinic_slug = None
            
            # Verifica mapeamento de domínios
            domain_mapping = app.config.get('CLINIC_DOMAIN_MAPPING', {})
            if host in domain_mapping:
                clinic_slug = domain_mapping[host]
            
            # Verifica parâmetro na URL
            if not clinic_slug:
                clinic_slug = request.args.get('clinic')
            
            # Verifica subdomínio
            if not clinic_slug and '.' in host:
                subdomain = host.split('.')[0]
                if subdomain not in ['www', 'chatbot']:
                    clinic_slug = subdomain
            
            # Usa padrão se não encontrou
            if not clinic_slug:
                clinic_slug = app.config.get('DEFAULT_CLINIC_SLUG', 'ecos')
            
            # Define clínica atual
            MultiTenantManager.set_current_clinic_slug(clinic_slug)
            
        except Exception as e:
            app.logger.error(f\"Erro ao carregar clínica: {e}\")\n            MultiTenantManager.set_current_clinic_slug('ecos')\n    \n    # Registra blueprints\n    register_blueprints(app)\n    \n    # Handlers de erro\n    register_error_handlers(app)\n    \n    # Comandos CLI\n    register_cli_commands(app)\n    \n    return app\n\ndef register_blueprints(app):\n    \"\"\"Registra todos os blueprints\"\"\"\n    \n    try:\n        # Autenticação\n        from routes.auth_v2 import auth_bp\n        app.register_blueprint(auth_bp, url_prefix='/auth')\n        \n        # Dashboard\n        from routes.dashboard_v2 import dashboard_bp\n        app.register_blueprint(dashboard_bp)\n        \n        # Super Admin\n        from routes.super_admin import super_admin_bp\n        app.register_blueprint(super_admin_bp, url_prefix='/super')\n        \n        # Webhooks Omnichannel\n        from routes.webhook_omnichannel import webhook_omnichannel_bp\n        app.register_blueprint(webhook_omnichannel_bp, url_prefix='/webhook')\n        \n        # Relatórios\n        from routes.reports import reports_bp\n        app.register_blueprint(reports_bp, url_prefix='/reports')\n        \n        # API de usuários\n        from routes.user import user_bp\n        app.register_blueprint(user_bp, url_prefix='/api/users')\n        \n        app.logger.info('Blueprints registrados com sucesso')\n        \n    except Exception as e:\n        app.logger.error(f'Erro ao registrar blueprints: {e}')\n        # Registra blueprints básicos como fallback\n        try:\n            from routes.auth import auth_bp as auth_fallback\n            app.register_blueprint(auth_fallback, url_prefix='/auth')\n            \n            from routes.dashboard import dashboard_bp as dashboard_fallback\n            app.register_blueprint(dashboard_fallback)\n            \n            app.logger.info('Blueprints fallback registrados')\n        except Exception as fallback_error:\n            app.logger.error(f'Erro nos blueprints fallback: {fallback_error}')\n\ndef register_error_handlers(app):\n    \"\"\"Registra handlers de erro personalizados\"\"\"\n    \n    @app.errorhandler(404)\n    def not_found_error(error):\n        return {\n            'error': 'Página não encontrada',\n            'message': 'A página solicitada não existe.',\n            'status': 404\n        }, 404\n    \n    @app.errorhandler(500)\n    def internal_error(error):\n        db.session.rollback()\n        app.logger.error(f'Erro interno: {error}')\n        return {\n            'error': 'Erro interno do servidor',\n            'message': 'Ocorreu um erro inesperado. Tente novamente.',\n            'status': 500\n        }, 500\n    \n    @app.errorhandler(403)\n    def forbidden_error(error):\n        return {\n            'error': 'Acesso negado',\n            'message': 'Você não tem permissão para acessar este recurso.',\n            'status': 403\n        }, 403\n\ndef register_cli_commands(app):\n    \"\"\"Registra comandos CLI personalizados\"\"\"\n    \n    @app.cli.command()\n    def init_db():\n        \"\"\"Inicializa o banco de dados\"\"\"\n        db.create_all()\n        print('Banco de dados inicializado.')\n    \n    @app.cli.command()\n    def seed_data():\n        \"\"\"Popula banco com dados iniciais\"\"\"\n        try:\n            from data.initial_setup_multitenant import setup_initial_data\n            setup_initial_data()\n            print('Dados iniciais inseridos com sucesso.')\n        except Exception as e:\n            print(f'Erro ao inserir dados: {e}')\n    \n    @app.cli.command()\n    def create_superuser():\n        \"\"\"Cria usuário super administrador\"\"\"\n        try:\n            from models.multi_tenant import User\n            from werkzeug.security import generate_password_hash\n            \n            # Verifica se já existe\n            existing = User.query.filter_by(username='onindigital').first()\n            if existing:\n                print('Super usuário já existe.')\n                return\n            \n            # Cria super usuário\n            superuser = User(\n                username='onindigital',\n                password_hash=generate_password_hash('onindigital2025@super'),\n                user_type='super_admin',\n                is_active=True,\n                clinic_id=None  # Super admin não pertence a clínica específica\n            )\n            \n            db.session.add(superuser)\n            db.session.commit()\n            \n            print('Super usuário criado: onindigital / onindigital2025@super')\n            \n        except Exception as e:\n            print(f'Erro ao criar super usuário: {e}')\n    \n    @app.cli.command()\n    def test_connections():\n        \"\"\"Testa conexões com serviços externos\"\"\"\n        print('Testando conexões...')\n        \n        # Testa banco de dados\n        try:\n            db.session.execute('SELECT 1')\n            print('✅ Banco de dados: OK')\n        except Exception as e:\n            print(f'❌ Banco de dados: {e}')\n        \n        # Testa WhatsApp (Evolution API)\n        try:\n            import requests\n            whatsapp_url = app.config.get('WHATSAPP_BASE_URL')\n            if whatsapp_url:\n                response = requests.get(f'{whatsapp_url}/instance/list', timeout=5)\n                if response.status_code == 200:\n                    print('✅ WhatsApp (Evolution API): OK')\n                else:\n                    print(f'⚠️ WhatsApp: Status {response.status_code}')\n            else:\n                print('⚠️ WhatsApp: URL não configurada')\n        except Exception as e:\n            print(f'❌ WhatsApp: {e}')\n        \n        # Testa Facebook/Instagram\n        try:\n            facebook_token = app.config.get('FACEBOOK_PAGE_ACCESS_TOKEN')\n            if facebook_token:\n                print('✅ Facebook/Instagram: Token configurado')\n            else:\n                print('⚠️ Facebook/Instagram: Token não configurado')\n        except Exception as e:\n            print(f'❌ Facebook/Instagram: {e}')\n        \n        print('Teste de conexões concluído.')\n\n# Rotas básicas\ndef register_basic_routes(app):\n    \"\"\"Registra rotas básicas da aplicação\"\"\"\n    \n    @app.route('/')\n    def index():\n        \"\"\"Página inicial - redireciona para login\"\"\"\n        from flask import redirect, url_for\n        return redirect(url_for('auth.login'))\n    \n    @app.route('/health')\n    def health_check():\n        \"\"\"Health check para monitoramento\"\"\"\n        try:\n            # Testa conexão com banco\n            db.session.execute('SELECT 1')\n            \n            return {\n                'status': 'healthy',\n                'timestamp': datetime.utcnow().isoformat(),\n                'version': '2.1.0',\n                'environment': app.config.get('ENV', 'production')\n            }\n        except Exception as e:\n            return {\n                'status': 'unhealthy',\n                'error': str(e),\n                'timestamp': datetime.utcnow().isoformat()\n            }, 500\n    \n    @app.route('/api/status')\n    def api_status():\n        \"\"\"Status da API\"\"\"\n        clinic = MultiTenantManager.get_current_clinic()\n        \n        return {\n            'api_version': '2.1.0',\n            'clinic': clinic.slug if clinic else None,\n            'platforms': ['telegram', 'whatsapp', 'facebook', 'instagram'],\n            'status': 'operational'\n        }\n\nif __name__ == '__main__':\n    # Cria aplicação\n    app = create_app()\n    \n    # Registra rotas básicas\n    register_basic_routes(app)\n    \n    # Configurações de desenvolvimento\n    if app.config.get('DEBUG'):\n        app.run(\n            host='0.0.0.0',\n            port=int(os.environ.get('PORT', 5000)),\n            debug=True\n        )\n    else:\n        # Em produção, usar gunicorn ou similar\n        app.run(\n            host='0.0.0.0',\n            port=int(os.environ.get('PORT', 5000)),\n            debug=False\n        )"
