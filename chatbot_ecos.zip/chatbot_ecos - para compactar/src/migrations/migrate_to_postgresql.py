#!/usr/bin/env python3
"""
Script de migração de SQLite para PostgreSQL com suporte multi-tenant
"""

import os
import sys
import json
import sqlite3
from datetime import datetime
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

# Adiciona o diretório raiz ao path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from src.config.database import DatabaseConfig
from src.models.multi_tenant import db, Clinic, User, Exam, Appointment, AdminUser, ChatLog, SystemConfig

class DataMigrator:
    """Migrador de dados SQLite para PostgreSQL"""
    
    def __init__(self, sqlite_path='ecos_chatbot.db'):
        self.sqlite_path = sqlite_path
        self.postgres_url = DatabaseConfig.get_database_url()
        
        # Conexões
        self.sqlite_conn = None
        self.postgres_engine = None
        self.postgres_session = None
        
        # Estatísticas
        self.stats = {
            'clinics': 0,
            'users': 0,
            'exams': 0,
            'appointments': 0,
            'admin_users': 0,
            'chat_logs': 0,
            'system_configs': 0,
            'errors': []
        }
    
    def connect(self):
        """Estabelece conexões com os bancos"""
        try:
            # SQLite
            if os.path.exists(self.sqlite_path):
                self.sqlite_conn = sqlite3.connect(self.sqlite_path)
                self.sqlite_conn.row_factory = sqlite3.Row
                print(f"✅ Conectado ao SQLite: {self.sqlite_path}")
            else:
                print(f"⚠️ Arquivo SQLite não encontrado: {self.sqlite_path}")
                return False
            
            # PostgreSQL
            self.postgres_engine = create_engine(self.postgres_url)
            Session = sessionmaker(bind=self.postgres_engine)
            self.postgres_session = Session()
            print(f"✅ Conectado ao PostgreSQL: {self.postgres_url[:50]}...")
            
            return True
            
        except Exception as e:
            print(f"❌ Erro ao conectar: {e}")
            return False
    
    def create_default_clinic(self):
        """Cria clínica padrão ECOS"""
        try:
            # Verifica se já existe
            existing = self.postgres_session.query(Clinic).filter_by(slug='ecos').first()
            if existing:
                print("✅ Clínica ECOS já existe")
                return existing
            
            # Cria nova clínica
            clinic = Clinic(
                name='ECOS - Radiologia e Diagnóstico',
                slug='ecos',
                description='ECOS - Radiologia e Diagnóstico por imagem com tecnologia de ponta, médicos especialistas (RQE) e atendimento humanizado. Precisão, cuidado e conforto em cada exame.',
                address='Rua São Paulo, 407 - Lençóis Paulista - CEP 18.682-049',
                phone_call='(14) 3436-2300',
                phone_whatsapp='(14) 98171-3057',
                email='contato@onindigital.com.br',
                business_hours='Segunda a Sexta: 7h às 18h | Sábado: 7h às 12h',
                primary_color='#1627a3',
                secondary_color='#15aae5',
                active=True,
                plan='PRO'
            )
            
            self.postgres_session.add(clinic)
            self.postgres_session.commit()
            
            self.stats['clinics'] += 1
            print(f"✅ Clínica ECOS criada com ID: {clinic.id}")
            return clinic
            
        except Exception as e:
            print(f"❌ Erro ao criar clínica ECOS: {e}")
            self.stats['errors'].append(f"Clinic creation: {e}")
            return None
    
    def migrate_users(self, clinic):
        """Migra usuários do SQLite"""
        try:
            cursor = self.sqlite_conn.cursor()
            cursor.execute("SELECT * FROM users")
            users = cursor.fetchall()
            
            for user_data in users:
                try:
                    user = User(
                        clinic_id=clinic.id,
                        telegram_id=user_data['telegram_id'],
                        whatsapp_id=user_data.get('whatsapp_id'),
                        facebook_id=user_data.get('facebook_id'),
                        name=user_data.get('name'),
                        cpf=user_data.get('cpf'),
                        birth_date=user_data.get('birth_date'),
                        current_state=user_data.get('current_state', 'START'),
                        covenant_type=user_data.get('covenant_type'),
                        selected_exams=user_data.get('selected_exams'),
                        total_price=user_data.get('total_price', 0.0),
                        photo_file_id=user_data.get('photo_file_id'),
                        photo_approved=bool(user_data.get('photo_approved', False)),
                        satisfaction_rating=user_data.get('satisfaction_rating'),
                        created_at=datetime.fromisoformat(user_data['created_at']) if user_data.get('created_at') else datetime.utcnow(),
                        last_interaction=datetime.fromisoformat(user_data['last_interaction']) if user_data.get('last_interaction') else datetime.utcnow(),
                        session_start=datetime.fromisoformat(user_data['session_start']) if user_data.get('session_start') else datetime.utcnow()
                    )
                    
                    self.postgres_session.add(user)
                    self.stats['users'] += 1
                    
                except Exception as e:
                    print(f"⚠️ Erro ao migrar usuário {user_data.get('id', 'N/A')}: {e}")
                    self.stats['errors'].append(f"User {user_data.get('id', 'N/A')}: {e}")
            
            self.postgres_session.commit()
            print(f"✅ Migrados {self.stats['users']} usuários")
            
        except Exception as e:
            print(f"❌ Erro ao migrar usuários: {e}")
            self.stats['errors'].append(f"Users migration: {e}")
    
    def migrate_exams(self, clinic):
        """Migra exames do SQLite"""
        try:
            cursor = self.sqlite_conn.cursor()
            cursor.execute("SELECT * FROM exams")
            exams = cursor.fetchall()
            
            for exam_data in exams:
                try:
                    exam = Exam(
                        clinic_id=clinic.id,
                        exam_id=exam_data['exam_id'],
                        exam_name=exam_data['exam_name'],
                        category=exam_data['category'],
                        price_particular=float(exam_data.get('price_particular', 0)),
                        price_funeraria=float(exam_data.get('price_funeraria', 0)),
                        price_unimed=float(exam_data.get('price_unimed', 0)),
                        preparation_required=bool(exam_data.get('preparation_required', False)),
                        preparation_instructions=exam_data.get('preparation_instructions'),
                        active=bool(exam_data.get('active', True)),
                        created_at=datetime.fromisoformat(exam_data['created_at']) if exam_data.get('created_at') else datetime.utcnow(),
                        updated_at=datetime.fromisoformat(exam_data['updated_at']) if exam_data.get('updated_at') else datetime.utcnow()
                    )
                    
                    self.postgres_session.add(exam)
                    self.stats['exams'] += 1
                    
                except Exception as e:
                    print(f"⚠️ Erro ao migrar exame {exam_data.get('exam_id', 'N/A')}: {e}")
                    self.stats['errors'].append(f"Exam {exam_data.get('exam_id', 'N/A')}: {e}")
            
            self.postgres_session.commit()
            print(f"✅ Migrados {self.stats['exams']} exames")
            
        except Exception as e:
            print(f"❌ Erro ao migrar exames: {e}")
            self.stats['errors'].append(f"Exams migration: {e}")
    
    def migrate_appointments(self, clinic):
        """Migra agendamentos do SQLite"""
        try:
            cursor = self.sqlite_conn.cursor()
            cursor.execute("SELECT * FROM appointments")
            appointments = cursor.fetchall()
            
            for apt_data in appointments:
                try:
                    # Busca usuário correspondente
                    user = self.postgres_session.query(User).filter_by(
                        clinic_id=clinic.id,
                        id=apt_data['user_id']  # Pode não funcionar, usar telegram_id como fallback
                    ).first()
                    
                    if not user:
                        # Tenta buscar por telegram_id se disponível
                        continue
                    
                    appointment = Appointment(
                        clinic_id=clinic.id,
                        user_id=user.id,
                        exams=apt_data['exams'],
                        total_price=float(apt_data.get('total_price', 0)),
                        covenant_type=apt_data['covenant_type'],
                        status=apt_data.get('status', 'PENDING'),
                        preparation_instructions=apt_data.get('preparation_instructions'),
                        scheduled_exams=apt_data.get('scheduled_exams'),
                        photo_file_id=apt_data.get('photo_file_id'),
                        created_at=datetime.fromisoformat(apt_data['created_at']) if apt_data.get('created_at') else datetime.utcnow(),
                        confirmed_at=datetime.fromisoformat(apt_data['confirmed_at']) if apt_data.get('confirmed_at') else None,
                        scheduled_at=datetime.fromisoformat(apt_data['scheduled_at']) if apt_data.get('scheduled_at') else None,
                        scheduled_by=apt_data.get('scheduled_by')
                    )
                    
                    self.postgres_session.add(appointment)
                    self.stats['appointments'] += 1
                    
                except Exception as e:
                    print(f"⚠️ Erro ao migrar agendamento {apt_data.get('id', 'N/A')}: {e}")
                    self.stats['errors'].append(f"Appointment {apt_data.get('id', 'N/A')}: {e}")
            
            self.postgres_session.commit()
            print(f"✅ Migrados {self.stats['appointments']} agendamentos")
            
        except Exception as e:
            print(f"❌ Erro ao migrar agendamentos: {e}")
            self.stats['errors'].append(f"Appointments migration: {e}")
    
    def migrate_admin_users(self, clinic):
        """Migra usuários administrativos do SQLite"""
        try:
            cursor = self.sqlite_conn.cursor()
            cursor.execute("SELECT * FROM admin_users")
            admin_users = cursor.fetchall()
            
            for admin_data in admin_users:
                try:
                    # Super admin não tem clinic_id
                    clinic_id = None if admin_data.get('user_type') == 'SUPER_ADMIN' else clinic.id
                    
                    admin_user = AdminUser(
                        clinic_id=clinic_id,
                        username=admin_data['username'],
                        password_hash=admin_data['password_hash'],
                        full_name=admin_data['full_name'],
                        email=admin_data.get('email'),
                        user_type=admin_data.get('user_type', 'OPERATOR'),
                        can_manage_exams=bool(admin_data.get('can_manage_exams', False)),
                        can_manage_users=bool(admin_data.get('can_manage_users', False)),
                        can_view_reports=bool(admin_data.get('can_view_reports', False)),
                        can_schedule=bool(admin_data.get('can_schedule', True)),
                        can_manage_clinics=bool(admin_data.get('can_manage_clinics', False)),
                        active=bool(admin_data.get('active', True)),
                        created_at=datetime.fromisoformat(admin_data['created_at']) if admin_data.get('created_at') else datetime.utcnow(),
                        last_login=datetime.fromisoformat(admin_data['last_login']) if admin_data.get('last_login') else None
                    )
                    
                    self.postgres_session.add(admin_user)
                    self.stats['admin_users'] += 1
                    
                except Exception as e:
                    print(f"⚠️ Erro ao migrar admin {admin_data.get('username', 'N/A')}: {e}")
                    self.stats['errors'].append(f"Admin {admin_data.get('username', 'N/A')}: {e}")
            
            self.postgres_session.commit()
            print(f"✅ Migrados {self.stats['admin_users']} usuários administrativos")
            
        except Exception as e:
            print(f"❌ Erro ao migrar usuários administrativos: {e}")
            self.stats['errors'].append(f"Admin users migration: {e}")
    
    def create_super_admin(self):
        """Cria super administrador On In Digital"""
        try:
            from werkzeug.security import generate_password_hash
            
            # Verifica se já existe
            existing = self.postgres_session.query(AdminUser).filter_by(
                username='onindigital',
                user_type='SUPER_ADMIN'
            ).first()
            
            if existing:
                print("✅ Super admin On In Digital já existe")
                return existing
            
            super_admin = AdminUser(
                clinic_id=None,  # Super admin não pertence a uma clínica específica
                username='onindigital',
                password_hash=generate_password_hash('onindigital2025@super'),
                full_name='On In Digital - Super Admin',
                email='contato@onindigital.com.br',
                user_type='SUPER_ADMIN',
                can_manage_exams=True,
                can_manage_users=True,
                can_view_reports=True,
                can_schedule=True,
                can_manage_clinics=True,
                active=True
            )
            
            self.postgres_session.add(super_admin)
            self.postgres_session.commit()
            
            print(f"✅ Super admin criado: onindigital / onindigital2025@super")
            return super_admin
            
        except Exception as e:
            print(f"❌ Erro ao criar super admin: {e}")
            self.stats['errors'].append(f"Super admin creation: {e}")
            return None
    
    def run_migration(self):
        """Executa migração completa"""
        print("🚀 Iniciando migração SQLite → PostgreSQL")
        print("=" * 50)
        
        if not self.connect():
            return False
        
        try:
            # 1. Cria clínica padrão
            print("\n📋 Criando clínica ECOS...")
            clinic = self.create_default_clinic()
            if not clinic:
                return False
            
            # 2. Cria super admin
            print("\n👤 Criando super administrador...")
            self.create_super_admin()
            
            # 3. Migra dados
            print("\n📊 Migrando dados...")
            self.migrate_users(clinic)
            self.migrate_exams(clinic)
            self.migrate_appointments(clinic)
            self.migrate_admin_users(clinic)
            
            # 4. Estatísticas finais
            print("\n" + "=" * 50)
            print("📊 ESTATÍSTICAS DA MIGRAÇÃO")
            print("=" * 50)
            print(f"✅ Clínicas: {self.stats['clinics']}")
            print(f"✅ Usuários: {self.stats['users']}")
            print(f"✅ Exames: {self.stats['exams']}")
            print(f"✅ Agendamentos: {self.stats['appointments']}")
            print(f"✅ Admins: {self.stats['admin_users']}")
            
            if self.stats['errors']:
                print(f"\n⚠️ Erros encontrados: {len(self.stats['errors'])}")
                for error in self.stats['errors'][:5]:  # Mostra apenas os primeiros 5
                    print(f"   - {error}")
                if len(self.stats['errors']) > 5:
                    print(f"   ... e mais {len(self.stats['errors']) - 5} erros")
            
            print("\n🎉 Migração concluída com sucesso!")
            return True
            
        except Exception as e:
            print(f"❌ Erro durante migração: {e}")
            return False
        
        finally:
            if self.sqlite_conn:
                self.sqlite_conn.close()
            if self.postgres_session:
                self.postgres_session.close()
    
    def verify_migration(self):
        """Verifica integridade da migração"""
        print("\n🔍 Verificando integridade da migração...")
        
        try:
            # Conta registros no PostgreSQL
            clinic_count = self.postgres_session.query(Clinic).count()
            user_count = self.postgres_session.query(User).count()
            exam_count = self.postgres_session.query(Exam).count()
            appointment_count = self.postgres_session.query(Appointment).count()
            admin_count = self.postgres_session.query(AdminUser).count()
            
            print(f"📊 Registros no PostgreSQL:")
            print(f"   - Clínicas: {clinic_count}")
            print(f"   - Usuários: {user_count}")
            print(f"   - Exames: {exam_count}")
            print(f"   - Agendamentos: {appointment_count}")
            print(f"   - Admins: {admin_count}")
            
            # Verifica se há dados
            if user_count > 0 or exam_count > 0:
                print("✅ Migração verificada com sucesso!")
                return True
            else:
                print("⚠️ Nenhum dado encontrado. Verifique a migração.")
                return False
                
        except Exception as e:
            print(f"❌ Erro na verificação: {e}")
            return False

def main():
    """Função principal"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Migra dados do SQLite para PostgreSQL')
    parser.add_argument('--sqlite', default='ecos_chatbot.db', help='Caminho do arquivo SQLite')
    parser.add_argument('--verify-only', action='store_true', help='Apenas verifica a migração')
    
    args = parser.parse_args()
    
    migrator = DataMigrator(args.sqlite)
    
    if args.verify_only:
        if migrator.connect():
            migrator.verify_migration()
    else:
        success = migrator.run_migration()
        if success:
            migrator.verify_migration()
        return 0 if success else 1

if __name__ == '__main__':
    exit(main())
