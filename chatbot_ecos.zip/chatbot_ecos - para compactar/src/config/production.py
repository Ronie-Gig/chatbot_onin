import os
from datetime import timedelta

class ProductionConfig:
    """Configuração otimizada para produção"""
    
    # Flask
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'prod-secret-key-change-me'
    DEBUG = False
    TESTING = False
    
    # Database
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'postgresql://user:pass@localhost/chatbot_ecos'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 10,
        'pool_recycle': 120,
        'pool_pre_ping': True,
        'max_overflow': 20
    }
    
    # Session
    PERMANENT_SESSION_LIFETIME = timedelta(hours=24)
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Security
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = 3600
    
    # Logging
    LOG_LEVEL = 'INFO'
    LOG_FILE = '/var/log/chatbot_ecos/app.log'
    
    # Rate Limiting
    RATELIMIT_STORAGE_URL = 'redis://localhost:6379'
    RATELIMIT_DEFAULT = "100 per hour"
    
    # Telegram
    TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN')
    TELEGRAM_WEBHOOK_URL = os.environ.get('TELEGRAM_WEBHOOK_URL')
    
    # WhatsApp (Evolution API)
    WHATSAPP_BASE_URL = os.environ.get('WHATSAPP_BASE_URL', 'http://localhost:8080')
    WHATSAPP_API_KEY = os.environ.get('WHATSAPP_API_KEY')
    WHATSAPP_INSTANCE_NAME = os.environ.get('WHATSAPP_INSTANCE_NAME', 'chatbot_instance')
    
    # Facebook/Instagram (Meta)
    FACEBOOK_PAGE_ACCESS_TOKEN = os.environ.get('FACEBOOK_PAGE_ACCESS_TOKEN')
    FACEBOOK_VERIFY_TOKEN = os.environ.get('FACEBOOK_VERIFY_TOKEN')
    FACEBOOK_APP_SECRET = os.environ.get('FACEBOOK_APP_SECRET')
    
    # Email
    MAIL_SERVER = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
    MAIL_PORT = int(os.environ.get('MAIL_PORT', 587))
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD')
    
    # File Upload
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    UPLOAD_FOLDER = '/var/uploads/chatbot_ecos'
    
    # Cache
    CACHE_TYPE = 'redis'
    CACHE_REDIS_URL = 'redis://localhost:6379/1'
    CACHE_DEFAULT_TIMEOUT = 300
    
    # Monitoring
    SENTRY_DSN = os.environ.get('SENTRY_DSN')
    
    # Multi-tenant
    DEFAULT_CLINIC_SLUG = 'ecos'
    CLINIC_DOMAIN_MAPPING = {
        'ecos.onindigital.com.br': 'ecos',
        'chatbot.onindigital.com.br': 'default'
    }
    
    @staticmethod
    def init_app(app):
        """Inicializa configurações específicas de produção"""
        
        # Logging
        import logging
        from logging.handlers import RotatingFileHandler
        
        if not app.debug:
            # Cria diretório de logs se não existir
            import os
            log_dir = os.path.dirname(ProductionConfig.LOG_FILE)
            if not os.path.exists(log_dir):
                os.makedirs(log_dir)
            
            # Configura handler de arquivo
            file_handler = RotatingFileHandler(
                ProductionConfig.LOG_FILE,
                maxBytes=10240000,  # 10MB
                backupCount=10
            )
            file_handler.setFormatter(logging.Formatter(
                '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
            ))
            file_handler.setLevel(logging.INFO)
            app.logger.addHandler(file_handler)
            
            app.logger.setLevel(logging.INFO)
            app.logger.info('Chatbot ECOS startup')
        
        # Sentry para monitoramento de erros
        if ProductionConfig.SENTRY_DSN:
            try:
                import sentry_sdk
                from sentry_sdk.integrations.flask import FlaskIntegration
                
                sentry_sdk.init(
                    dsn=ProductionConfig.SENTRY_DSN,
                    integrations=[FlaskIntegration()],
                    traces_sample_rate=0.1
                )
            except ImportError:
                app.logger.warning('Sentry SDK não instalado')

class DevelopmentConfig:
    """Configuração para desenvolvimento"""
    
    # Flask
    SECRET_KEY = 'dev-secret-key'
    DEBUG = True
    TESTING = False
    
    # Database
    SQLALCHEMY_DATABASE_URI = 'sqlite:///chatbot_ecos_dev.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Session
    PERMANENT_SESSION_LIFETIME = timedelta(hours=1)
    SESSION_COOKIE_SECURE = False
    SESSION_COOKIE_HTTPONLY = True
    
    # Logging
    LOG_LEVEL = 'DEBUG'
    
    # Telegram
    TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN')
    TELEGRAM_WEBHOOK_URL = os.environ.get('TELEGRAM_WEBHOOK_URL', 'https://your-ngrok-url.ngrok.io')
    
    # WhatsApp
    WHATSAPP_BASE_URL = 'http://localhost:8080'
    WHATSAPP_API_KEY = 'dev-api-key'
    WHATSAPP_INSTANCE_NAME = 'dev_instance'
    
    # Facebook/Instagram
    FACEBOOK_PAGE_ACCESS_TOKEN = 'dev-token'
    FACEBOOK_VERIFY_TOKEN = 'dev-verify'
    FACEBOOK_APP_SECRET = 'dev-secret'
    
    # File Upload
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    UPLOAD_FOLDER = './uploads'
    
    # Multi-tenant
    DEFAULT_CLINIC_SLUG = 'ecos'
    CLINIC_DOMAIN_MAPPING = {
        'localhost:5000': 'ecos',
        '127.0.0.1:5000': 'ecos'
    }

# Configurações disponíveis
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}
