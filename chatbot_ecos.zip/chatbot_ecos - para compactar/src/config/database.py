import os
from urllib.parse import urlparse

class DatabaseConfig:
    """Configuração de banco de dados multi-ambiente"""
    
    @staticmethod
    def get_database_url():
        """Retorna URL do banco baseada no ambiente"""
        
        # Prioridade: PostgreSQL > SQLite
        postgres_url = os.getenv('DATABASE_URL') or os.getenv('POSTGRES_URL')
        
        if postgres_url:
            # Ajusta URL do Supabase se necessário
            if postgres_url.startswith('postgresql://'):
                return postgres_url
            elif postgres_url.startswith('postgres://'):
                return postgres_url.replace('postgres://', 'postgresql://', 1)
            else:
                return postgres_url
        
        # Fallback para SQLite local
        return 'sqlite:///ecos_chatbot.db'
    
    @staticmethod
    def get_config():
        """Retorna configuração completa do banco"""
        database_url = DatabaseConfig.get_database_url()
        
        config = {
            'SQLALCHEMY_DATABASE_URI': database_url,
            'SQLALCHEMY_TRACK_MODIFICATIONS': False,
            'SQLALCHEMY_ENGINE_OPTIONS': {}
        }
        
        # Configurações específicas para PostgreSQL
        if database_url.startswith('postgresql://'):
            config['SQLALCHEMY_ENGINE_OPTIONS'] = {
                'pool_pre_ping': True,
                'pool_recycle': 300,
                'connect_args': {
                    'sslmode': 'require',
                    'connect_timeout': 10
                }
            }
        
        return config
    
    @staticmethod
    def is_postgresql():
        """Verifica se está usando PostgreSQL"""
        return DatabaseConfig.get_database_url().startswith('postgresql://')
    
    @staticmethod
    def is_sqlite():
        """Verifica se está usando SQLite"""
        return DatabaseConfig.get_database_url().startswith('sqlite:///')

# Configurações do Supabase
SUPABASE_CONFIG = {
    'url': os.getenv('SUPABASE_URL', ''),
    'key': os.getenv('SUPABASE_ANON_KEY', ''),
    'service_role_key': os.getenv('SUPABASE_SERVICE_ROLE_KEY', '')
}

# Configurações de migração
MIGRATION_CONFIG = {
    'backup_before_migration': True,
    'verify_data_integrity': True,
    'batch_size': 1000,  # Para migrações grandes
    'timeout': 300  # 5 minutos
}
