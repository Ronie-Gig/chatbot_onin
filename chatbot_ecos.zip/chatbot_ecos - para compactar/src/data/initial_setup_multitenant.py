#!/usr/bin/env python3
"""
Configuração inicial para sistema multi-tenant
Cria clínica ECOS, usuários administrativos e dados iniciais
"""

import os
import sys
from datetime import datetime
from werkzeug.security import generate_password_hash

# Adiciona o diretório raiz ao path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from src.models.multi_tenant import db, Clinic, AdminUser, Exam, SystemConfig

def create_ecos_clinic():
    """Cria clínica ECOS com dados completos"""
    try:
        # Verifica se já existe
        existing = Clinic.query.filter_by(slug='ecos').first()
        if existing:
            print("✅ Clínica ECOS já existe")
            return existing
        
        # Cria nova clínica ECOS
        clinic = Clinic(
            name='ECOS - Radiologia e Diagnóstico',
            slug='ecos',
            description='ECOS - Radiologia e Diagnóstico por imagem com tecnologia de ponta, médicos especialistas (RQE) e atendimento humanizado. Precisão, cuidado e conforto em cada exame.',
            address='Rua São Paulo, 407 - Lençóis Paulista - CEP 18.682-049',
            phone_call='(14) 3436-2300',
            phone_whatsapp='(14) 98171-3057',
            email='contato@onindigital.com.br',
            business_hours='Segunda a Sexta: 7h às 18h | Sábado: 7h às 12h',
            logo_url='/static/images/ecos-logo.png',  # Será adicionado depois
            primary_color='#1627a3',  # On In Digital azul escuro
            secondary_color='#15aae5',  # On In Digital azul claro
            telegram_token=os.getenv('TELEGRAM_BOT_TOKEN', ''),
            whatsapp_token=os.getenv('WHATSAPP_TOKEN', ''),
            facebook_token=os.getenv('FACEBOOK_TOKEN', ''),
            active=True,
            plan='PRO'
        )
        
        db.session.add(clinic)
        db.session.commit()
        
        print(f"✅ Clínica ECOS criada com ID: {clinic.id}")
        return clinic
        
    except Exception as e:
        print(f"❌ Erro ao criar clínica ECOS: {e}")
        db.session.rollback()
        return None

def create_super_admin():
    """Cria super administrador On In Digital"""
    try:
        # Verifica se já existe
        existing = AdminUser.query.filter_by(
            username='onindigital',
            user_type='SUPER_ADMIN'
        ).first()
        
        if existing:
            print("✅ Super admin On In Digital já existe")
            return existing
        
        super_admin = AdminUser(
            clinic_id=None,  # Super admin não pertence a uma clínica específica
            username='onindigital',
            password_hash=generate_password_hash('onindigital2025@super'),
            full_name='On In Digital - Super Admin',
            email='contato@onindigital.com.br',
            user_type='SUPER_ADMIN',
            can_manage_exams=True,
            can_manage_users=True,
            can_view_reports=True,
            can_schedule=True,
            can_manage_clinics=True,
            active=True
        )
        
        db.session.add(super_admin)
        db.session.commit()
        
        print(f"✅ Super admin criado: onindigital / onindigital2025@super")
        return super_admin
        
    except Exception as e:
        print(f"❌ Erro ao criar super admin: {e}")
        db.session.rollback()
        return None

def create_ecos_admin_users(clinic):
    """Cria usuários administrativos para ECOS"""
    try:
        users_created = 0
        
        # Master ECOS
        if not AdminUser.query.filter_by(clinic_id=clinic.id, username='master').first():
            master = AdminUser(
                clinic_id=clinic.id,
                username='master',
                password_hash=generate_password_hash('ecos2025@master'),
                full_name='Master ECOS',
                email='master@ecos.com.br',
                user_type='MASTER',
                can_manage_exams=True,
                can_manage_users=True,
                can_view_reports=True,
                can_schedule=True,
                can_manage_clinics=False,
                active=True
            )
            db.session.add(master)
            users_created += 1
        
        # Operadores ECOS
        for i in range(1, 4):
            username = f'operador{i}'
            if not AdminUser.query.filter_by(clinic_id=clinic.id, username=username).first():
                operator = AdminUser(
                    clinic_id=clinic.id,
                    username=username,
                    password_hash=generate_password_hash('ecos2025'),
                    full_name=f'Operador {i} ECOS',
                    email=f'operador{i}@ecos.com.br',
                    user_type='OPERATOR',
                    can_manage_exams=False,
                    can_manage_users=False,
                    can_view_reports=False,
                    can_schedule=True,
                    can_manage_clinics=False,
                    active=True
                )
                db.session.add(operator)
                users_created += 1
        
        db.session.commit()
        print(f"✅ {users_created} usuários administrativos criados para ECOS")
        
    except Exception as e:
        print(f"❌ Erro ao criar usuários administrativos: {e}")
        db.session.rollback()

def create_ecos_exams(clinic):
    """Cria exames iniciais para ECOS"""
    try:
        # Verifica se já existem exames
        existing_count = Exam.query.filter_by(clinic_id=clinic.id).count()
        if existing_count > 0:
            print(f"✅ {existing_count} exames já existem para ECOS")
            return
        
        # Lista de exames básicos
        exams_data = [
            # Ultrassonografia
            {
                'exam_id': 'US001',
                'exam_name': 'Ultrassom Abdominal Total',
                'category': 'Ultrassonografia',
                'price_particular': 120.00,
                'price_funeraria': 100.00,
                'price_unimed': 0.00,
                'preparation_required': True,
                'preparation_instructions': 'Jejum de 8 horas. Beber 4 copos de água 1 hora antes do exame e não urinar.'
            },
            {
                'exam_id': 'US002',
                'exam_name': 'Ultrassom Pélvico Transvaginal',
                'category': 'Ultrassonografia',
                'price_particular': 100.00,
                'price_funeraria': 80.00,
                'price_unimed': 0.00,
                'preparation_required': True,
                'preparation_instructions': 'Bexiga vazia. Não é necessário jejum.'
            },
            {
                'exam_id': 'US003',
                'exam_name': 'Ultrassom Obstétrico',
                'category': 'Ultrassonografia',
                'price_particular': 150.00,
                'price_funeraria': 120.00,
                'price_unimed': 0.00,
                'preparation_required': False,
                'preparation_instructions': 'Não é necessário preparo específico.'
            },
            
            # Tomografia
            {
                'exam_id': 'TC001',
                'exam_name': 'Tomografia de Crânio',
                'category': 'Tomografia Computadorizada',
                'price_particular': 300.00,
                'price_funeraria': 250.00,
                'price_unimed': 0.00,
                'preparation_required': False,
                'preparation_instructions': 'Não é necessário preparo específico.'
            },
            {
                'exam_id': 'TC002',
                'exam_name': 'Tomografia de Abdome e Pelve',
                'category': 'Tomografia Computadorizada',
                'price_particular': 400.00,
                'price_funeraria': 350.00,
                'price_unimed': 0.00,
                'preparation_required': True,
                'preparation_instructions': 'Jejum de 4 horas. Beber contraste conforme orientação.'
            },
            
            # Raio-X
            {
                'exam_id': 'RX001',
                'exam_name': 'Raio-X de Tórax',
                'category': 'Raio-X',
                'price_particular': 50.00,
                'price_funeraria': 40.00,
                'price_unimed': 0.00,
                'preparation_required': False,
                'preparation_instructions': 'Não é necessário preparo específico.'
            },
            {
                'exam_id': 'RX002',
                'exam_name': 'Raio-X de Coluna Lombar',
                'category': 'Raio-X',
                'price_particular': 80.00,
                'price_funeraria': 60.00,
                'price_unimed': 0.00,
                'preparation_required': False,
                'preparation_instructions': 'Não é necessário preparo específico.'
            },
            
            # Ressonância
            {
                'exam_id': 'RM001',
                'exam_name': 'Ressonância de Crânio',
                'category': 'Ressonância Magnética',
                'price_particular': 600.00,
                'price_funeraria': 500.00,
                'price_unimed': 0.00,
                'preparation_required': False,
                'preparation_instructions': 'Informar sobre implantes metálicos. Retirar objetos metálicos.'
            },
            
            # Mamografia
            {
                'exam_id': 'MG001',
                'exam_name': 'Mamografia Bilateral',
                'category': 'Mamografia',
                'price_particular': 180.00,
                'price_funeraria': 150.00,
                'price_unimed': 0.00,
                'preparation_required': True,
                'preparation_instructions': 'Não usar desodorante, talco ou creme na região das mamas e axilas.'
            },
            
            # Densitometria
            {
                'exam_id': 'DO001',
                'exam_name': 'Densitometria Óssea',
                'category': 'Densitometria Óssea',
                'price_particular': 200.00,
                'price_funeraria': 160.00,
                'price_unimed': 0.00,
                'preparation_required': False,
                'preparation_instructions': 'Não é necessário preparo específico.'
            }
        ]
        
        exams_created = 0
        for exam_data in exams_data:
            exam = Exam(
                clinic_id=clinic.id,
                **exam_data,
                active=True
            )
            db.session.add(exam)
            exams_created += 1
        
        db.session.commit()
        print(f"✅ {exams_created} exames criados para ECOS")
        
    except Exception as e:
        print(f"❌ Erro ao criar exames: {e}")
        db.session.rollback()

def create_system_configs():
    """Cria configurações do sistema"""
    try:
        configs = [
            # Configurações globais
            {
                'clinic_id': None,
                'key': 'system_version',
                'value': '2.0.0-multitenant',
                'description': 'Versão do sistema'
            },
            {
                'clinic_id': None,
                'key': 'on_in_digital_branding',
                'value': 'true',
                'description': 'Exibir branding On In Digital'
            },
            {
                'clinic_id': None,
                'key': 'on_in_digital_logo_light',
                'value': '/static/images/logo-on-inperfilinstagram.png',
                'description': 'Logo On In Digital para fundo claro'
            },
            {
                'clinic_id': None,
                'key': 'on_in_digital_logo_dark',
                'value': '/static/images/logo-on-inperfilinstagraminvertido.png',
                'description': 'Logo On In Digital para fundo escuro'
            },
            {
                'clinic_id': None,
                'key': 'on_in_digital_colors',
                'value': '{"primary": "#1627a3", "secondary": "#15aae5"}',
                'description': 'Cores padrão On In Digital'
            }
        ]
        
        configs_created = 0
        for config_data in configs:
            # Verifica se já existe
            existing = SystemConfig.query.filter_by(
                clinic_id=config_data['clinic_id'],
                key=config_data['key']
            ).first()
            
            if not existing:
                config = SystemConfig(**config_data)
                db.session.add(config)
                configs_created += 1
        
        db.session.commit()
        print(f"✅ {configs_created} configurações do sistema criadas")
        
    except Exception as e:
        print(f"❌ Erro ao criar configurações: {e}")
        db.session.rollback()

def run_initial_setup():
    """Executa configuração inicial completa"""
    print("🚀 Iniciando configuração inicial multi-tenant")
    print("=" * 50)
    
    try:
        # 1. Cria clínica ECOS
        print("\n📋 Criando clínica ECOS...")
        clinic = create_ecos_clinic()
        if not clinic:
            print("❌ Falha ao criar clínica ECOS")
            return False
        
        # 2. Cria super admin
        print("\n👤 Criando super administrador...")
        create_super_admin()
        
        # 3. Cria usuários administrativos ECOS
        print("\n👥 Criando usuários administrativos ECOS...")
        create_ecos_admin_users(clinic)
        
        # 4. Cria exames iniciais
        print("\n🧪 Criando exames iniciais...")
        create_ecos_exams(clinic)
        
        # 5. Cria configurações do sistema
        print("\n⚙️ Criando configurações do sistema...")
        create_system_configs()
        
        print("\n" + "=" * 50)
        print("🎉 Configuração inicial concluída com sucesso!")
        print("\n📋 Credenciais criadas:")
        print("👑 Super Admin: onindigital / onindigital2025@super")
        print("👑 Master ECOS: master / ecos2025@master")
        print("👤 Operadores: operador1, operador2, operador3 / ecos2025")
        print("\n🌐 Acesso:")
        print("🏥 ECOS: http://ecos.onindigital.com.br")
        print("🔧 Admin: http://chatbot.onindigital.com.br")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro na configuração inicial: {e}")
        return False

def main():
    """Função principal para execução standalone"""
    from src.main import app
    
    with app.app_context():
        # Cria tabelas se não existirem
        db.create_all()
        
        # Executa configuração
        success = run_initial_setup()
        return 0 if success else 1

if __name__ == '__main__':
    exit(main())
