"""
Script de configuração inicial do sistema
Cria usuários administrativos, configurações e dados iniciais
"""

from werkzeug.security import generate_password_hash
from datetime import datetime
from src.models.chatbot import db, AdminUser, ClinicInfo, SystemConfig, Exam
from src.data.exams_data import get_exams_data

def create_admin_users():
    """Cria usuários administrativos padrão"""
    
    # Usuário Master
    master_user = AdminUser.query.filter_by(username='master').first()
    if not master_user:
        master_user = AdminUser(
            username='master',
            password_hash=generate_password_hash('ecos2025@master'),
            full_name='Administrador Master',
            email='master@ecos.com.br',
            user_type='MASTER',
            can_manage_exams=True,
            can_manage_users=True,
            can_view_reports=True,
            can_schedule=True,
            active=True
        )
        db.session.add(master_user)
        print("✅ Usuário master criado")
    else:
        print("ℹ️ Usuário master já existe")
    
    # Operadores
    for i in range(1, 4):  # operador1, operador2, operador3
        username = f'operador{i}'
        operator = AdminUser.query.filter_by(username=username).first()
        
        if not operator:
            operator = AdminUser(
                username=username,
                password_hash=generate_password_hash('ecos2025'),
                full_name=f'Operador {i}',
                email=f'operador{i}@ecos.com.br',
                user_type='OPERATOR',
                can_manage_exams=False,
                can_manage_users=False,
                can_view_reports=False,
                can_schedule=True,
                active=True
            )
            db.session.add(operator)
            print(f"✅ Usuário {username} criado")
        else:
            print(f"ℹ️ Usuário {username} já existe")

def create_clinic_info():
    """Cria informações da clínica"""
    clinic = ClinicInfo.query.first()
    
    if not clinic:
        clinic = ClinicInfo(
            name='ECOS - Radiologia e Diagnóstico',
            description='ECOS - Radiologia e Diagnóstico por imagem com tecnologia de ponta, médicos especialistas (RQE) e atendimento humanizado. Precisão, cuidado e conforto em cada exame.',
            address='Rua São Paulo, 407 - Lençóis Paulista - CEP 18.682-049',
            phone_call='(14) 3436-2300',
            phone_whatsapp='(14) 98171-3057',
            email='contato@onindigital.com.br',
            business_hours='Segunda a Sexta: 7h às 18h | Sábado: 7h às 12h'
        )
        db.session.add(clinic)
        print("✅ Informações da clínica criadas")
    else:
        # Atualiza informações existentes
        clinic.name = 'ECOS - Radiologia e Diagnóstico'
        clinic.description = 'ECOS - Radiologia e Diagnóstico por imagem com tecnologia de ponta, médicos especialistas (RQE) e atendimento humanizado. Precisão, cuidado e conforto em cada exame.'
        clinic.address = 'Rua São Paulo, 407 - Lençóis Paulista - CEP 18.682-049'
        clinic.phone_call = '(14) 3436-2300'
        clinic.phone_whatsapp = '(14) 98171-3057'
        clinic.email = 'contato@onindigital.com.br'
        clinic.business_hours = 'Segunda a Sexta: 7h às 18h | Sábado: 7h às 12h'
        print("✅ Informações da clínica atualizadas")

def create_system_config():
    """Cria configurações do sistema"""
    configs = [
        {
            'key': 'WELCOME_MESSAGE',
            'value': '🏥 Olá! Bem-vindo à ECOS - Radiologia e Diagnóstico!\n\nSou seu assistente virtual e estou aqui para ajudar com:\n• 📅 Agendamento de exames\n• 💰 Orçamentos personalizados\n• 📍 Informações da clínica\n• 👨‍⚕️ Falar com atendente\n\nComo posso ajudar você hoje?',
            'description': 'Mensagem de boas-vindas do chatbot'
        },
        {
            'key': 'PHOTO_INSTRUCTIONS',
            'value': '📸 **Por favor, envie uma foto do seu pedido médico.**\n\n⚠️ **Importante:**\n• Certifique-se de que a foto está nítida\n• Todos os dados devem estar legíveis\n• Evite reflexos ou sombras\n\nApós enviar, você poderá confirmar se a imagem está adequada.',
            'description': 'Instruções para envio de foto do pedido médico'
        },
        {
            'key': 'BUSINESS_HOURS',
            'value': 'Segunda a Sexta: 7h às 18h | Sábado: 7h às 12h',
            'description': 'Horário de funcionamento da clínica'
        }
    ]
    
    for config_data in configs:
        config = SystemConfig.query.filter_by(key=config_data['key']).first()
        if not config:
            config = SystemConfig(**config_data)
            db.session.add(config)
            print(f"✅ Configuração {config_data['key']} criada")
        else:
            config.value = config_data['value']
            config.description = config_data['description']
            print(f"✅ Configuração {config_data['key']} atualizada")

def load_exams_data():
    """Carrega dados dos exames"""
    exams_data = get_exams_data()
    
    # Remove exames antigos
    Exam.query.delete()
    
    # Adiciona novos exames
    for exam_data in exams_data:
        exam = Exam(
            exam_id=exam_data['exam_id'],
            exam_name=exam_data['exam_name'],
            category=exam_data['category'],
            price_particular=exam_data['price_particular'],
            price_funeraria=exam_data['price_funeraria'],
            price_unimed=exam_data['price_unimed'],
            preparation_required=exam_data['preparation_required'],
            preparation_instructions=exam_data['preparation_instructions'],
            active=True
        )
        db.session.add(exam)
    
    print(f"✅ {len(exams_data)} exames carregados")

def run_initial_setup():
    """Executa configuração inicial completa"""
    try:
        print("🚀 Iniciando configuração inicial...")
        
        # Cria usuários administrativos
        create_admin_users()
        
        # Cria informações da clínica
        create_clinic_info()
        
        # Cria configurações do sistema
        create_system_config()
        
        # Carrega dados dos exames
        load_exams_data()
        
        # Salva todas as alterações
        db.session.commit()
        
        print("✅ Configuração inicial concluída com sucesso!")
        print("\n📋 Credenciais de acesso:")
        print("👑 Master: master / ecos2025@master")
        print("👤 Operadores: operador1, operador2, operador3 / ecos2025")
        
        return True
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro na configuração inicial: {e}")
        return False

if __name__ == '__main__':
    # Para execução direta do script
    from flask import Flask
    from src.models.chatbot import db
    
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database/app.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    
    with app.app_context():
        db.create_all()
        run_initial_setup()

