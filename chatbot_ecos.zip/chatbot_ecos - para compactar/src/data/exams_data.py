"""
Dados dos 37 exames da Clínica ECOS
Conforme tabela fornecida pelo cliente
"""

EXAMS_DATA = [
    {
        'exam_id': 'US-ABD-01',
        'exam_name': 'Abdomen Superior',
        'category': 'Ultrassonografia',
        'price_funeraria': 270.00,
        'price_particular': 540.00,
        'price_unimed': 0.00,  # Coberto pelo plano
        'preparation_required': True,
        'preparation_instructions': 'Jejum de 12 horas'
    },
    {
        'exam_id': 'US-ABD-02',
        'exam_name': 'Abdomen Total',
        'category': 'Ultrassonografia',
        'price_funeraria': 370.00,
        'price_particular': 740.00,
        'price_unimed': 0.00,
        'preparation_required': True,
        'preparation_instructions': 'Jejum de 12 horas e bexiga cheia (tomar 3 copos de Água 1 hora antes do exame)'
    },
    {
        'exam_id': 'US-ART-01',
        'exam_name': 'Articulação',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-ESC-01',
        'exam_name': 'Bolsa Escrotal',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-ESC-02',
        'exam_name': 'Bolsa Escrotal com Doppler',
        'category': 'Ultrassonografia com Doppler',
        'price_funeraria': 440.00,
        'price_particular': 800.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-CRA-01',
        'exam_name': 'Craneo',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'DOP-REN-01',
        'exam_name': 'Doppler de Artérias Renais',
        'category': 'Doppler',
        'price_funeraria': 430.00,
        'price_particular': 860.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'DOP-ILI-01',
        'exam_name': 'Doppler de Iliacas',
        'category': 'Doppler',
        'price_funeraria': 430.00,
        'price_particular': 430.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'DOP-ORG-01',
        'exam_name': 'Doppler Orgãos e Estruturas Isolados',
        'category': 'Doppler',
        'price_funeraria': 430.00,
        'price_particular': 860.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'DOP-CAV-01',
        'exam_name': 'Doppler Veia Cava',
        'category': 'Doppler',
        'price_funeraria': 430.00,
        'price_particular': 860.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'DOP-MIA-01',
        'exam_name': 'Doppler Venoso Membro Inferior Unilateral - Arterial',
        'category': 'Doppler',
        'price_funeraria': 430.00,
        'price_particular': 860.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'DOP-MIV-01',
        'exam_name': 'Doppler Venoso Membro Inferior Unilateral - Venoso',
        'category': 'Doppler',
        'price_funeraria': 430.00,
        'price_particular': 860.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-END-01',
        'exam_name': 'Endovaginal',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-END-02',
        'exam_name': 'Endovaginal para Controle de Ovulação (7º. Dia da Menstruação)',
        'category': 'Ultrassonografia',
        'price_funeraria': 440.00,
        'price_particular': 880.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-SAL-01',
        'exam_name': 'Glândulas Salivares',
        'category': 'Ultrassonografia',
        'price_funeraria': 250.00,
        'price_particular': 500.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-OCU-01',
        'exam_name': 'Globo Ocular',
        'category': 'Ultrassonografia',
        'price_funeraria': 250.00,
        'price_particular': 500.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-OCU-02',
        'exam_name': 'Globo Ocular com Doppler',
        'category': 'Ultrassonografia com Doppler',
        'price_funeraria': 430.00,
        'price_particular': 860.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-MAM-01',
        'exam_name': 'Mamas',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-OBS-01',
        'exam_name': 'Obstétrico',
        'category': 'Ultrassonografia Obstétrica',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-OBS-02',
        'exam_name': 'Obstétrico com Doppler',
        'category': 'Ultrassonografia Obstétrica',
        'price_funeraria': 320.00,
        'price_particular': 640.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-OBS-03',
        'exam_name': 'Obstetrico Morfológico (22 A 24 Semanas)',
        'category': 'Ultrassonografia Obstétrica',
        'price_funeraria': 320.00,
        'price_particular': 340.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-OBS-04',
        'exam_name': 'Obstétrico 1º Trimestre',
        'category': 'Ultrassonografia Obstétrica',
        'price_funeraria': 320.00,
        'price_particular': 640.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-OBS-05',
        'exam_name': 'Obstétrico Biofísico Fetal',
        'category': 'Ultrassonografia Obstétrica',
        'price_funeraria': 0.00,  # Sem preço definido
        'price_particular': 0.00,  # Sem preço definido
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-OBS-06',
        'exam_name': 'Obstétrico Gemelar',
        'category': 'Ultrassonografia Obstétrica',
        'price_funeraria': 320.00,
        'price_particular': 640.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-OBS-07',
        'exam_name': 'Obstétrico Gemelar com Doppler',
        'category': 'Ultrassonografia Obstétrica',
        'price_funeraria': 0.00,  # Sem preço definido
        'price_particular': 0.00,  # Sem preço definido
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-OBS-08',
        'exam_name': 'Obstétrico Translucência Nucal (Até 12 Semanas)',
        'category': 'Ultrassonografia Obstétrica',
        'price_funeraria': 320.00,
        'price_particular': 500.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-SUP-01',
        'exam_name': 'Órgãos Estruturas Superficiais (Parede Abdominal e Região Inguinal)',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-MUS-01',
        'exam_name': 'Órgãos e Músculos',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-PEL-01',
        'exam_name': 'Pélvico',
        'category': 'Ultrassonografia',
        'price_funeraria': 180.00,
        'price_particular': 360.00,
        'price_unimed': 0.00,
        'preparation_required': True,
        'preparation_instructions': 'Bexiga cheia (tomar 3 copos de Água 1 hora antes do exame)'
    },
    {
        'exam_id': 'US-PEL-02',
        'exam_name': 'Pélvico Transvaginal Controle para Ovulação',
        'category': 'Ultrassonografia',
        'price_funeraria': 380.00,
        'price_particular': 760.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-PRO-01',
        'exam_name': 'Próstata',
        'category': 'Ultrassonografia',
        'price_funeraria': 170.00,
        'price_particular': 340.00,
        'price_unimed': 0.00,
        'preparation_required': True,
        'preparation_instructions': 'Bexiga cheia (tomar 3 copos de Água 1 hora antes do exame)'
    },
    {
        'exam_id': 'US-PRO-02',
        'exam_name': 'Próstata Trans-Retal',
        'category': 'Ultrassonografia',
        'price_funeraria': 290.00,
        'price_particular': 580.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-RET-01',
        'exam_name': 'Retroperitoneo',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-RIN-01',
        'exam_name': 'Rins',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': True,
        'preparation_instructions': 'Bexiga cheia (tomar 3 copos de Água 1 hora antes do exame)'
    },
    {
        'exam_id': 'US-SUP-02',
        'exam_name': 'Supra Renais',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-TIR-01',
        'exam_name': 'Tireóide',
        'category': 'Ultrassonografia',
        'price_funeraria': 240.00,
        'price_particular': 480.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    },
    {
        'exam_id': 'US-TOR-01',
        'exam_name': 'Tórax',
        'category': 'Ultrassonografia',
        'price_funeraria': 170.00,
        'price_particular': 340.00,
        'price_unimed': 0.00,
        'preparation_required': False,
        'preparation_instructions': None
    }
]

def get_exams_data():
    """Retorna a lista de exames"""
    return EXAMS_DATA

def get_exam_by_id(exam_id):
    """Busca exame por ID"""
    for exam in EXAMS_DATA:
        if exam['exam_id'] == exam_id:
            return exam
    return None

def get_exams_by_category(category):
    """Busca exames por categoria"""
    return [exam for exam in EXAMS_DATA if exam['category'] == category]

def get_categories():
    """Retorna lista de categorias únicas"""
    categories = set()
    for exam in EXAMS_DATA:
        categories.add(exam['category'])
    return sorted(list(categories))

