import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional

class EmailService:
    def __init__(self):
        self.smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = int(os.getenv('SMTP_PORT', '587'))
        self.email_user = os.getenv('EMAIL_USER', 'contato@onindigital.com.br')
        self.email_password = os.getenv('EMAIL_PASSWORD', '')
        
    def send_email(self, to_email: str, subject: str, body: str, html_body: Optional[str] = None) -> bool:
        """Envia email"""
        try:
            # Se não tiver configuração de email, apenas loga
            if not self.email_password:
                print(f"📧 EMAIL SIMULADO:")
                print(f"Para: {to_email}")
                print(f"Assunto: {subject}")
                print(f"Corpo: {body}")
                print("=" * 50)
                return True
            
            msg = MIMEMultipart('alternative')
            msg['From'] = self.email_user
            msg['To'] = to_email
            msg['Subject'] = subject
            
            # Adiciona corpo em texto
            text_part = MIMEText(body, 'plain', 'utf-8')
            msg.attach(text_part)
            
            # Adiciona corpo em HTML se fornecido
            if html_body:
                html_part = MIMEText(html_body, 'html', 'utf-8')
                msg.attach(html_part)
            
            # Conecta e envia
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()
            server.login(self.email_user, self.email_password)
            
            text = msg.as_string()
            server.sendmail(self.email_user, to_email, text)
            server.quit()
            
            print(f"✅ Email enviado para {to_email}")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao enviar email: {e}")
            # Em caso de erro, simula o envio
            print(f"📧 EMAIL SIMULADO (erro no envio real):")
            print(f"Para: {to_email}")
            print(f"Assunto: {subject}")
            print(f"Corpo: {body}")
            print("=" * 50)
            return True  # Retorna True para não quebrar o fluxo

