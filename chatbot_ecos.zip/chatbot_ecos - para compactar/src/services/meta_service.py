import requests
import json
import hmac
import hashlib
from datetime import datetime
from flask import current_app
from src.models.multi_tenant import db, User, Appointment, Clinic
from src.utils.multi_tenant import MultiTenantManager

class MetaService:
    """Serviço para integração com Facebook e Instagram via Meta for Developers"""
    
    def __init__(self, page_access_token=None, verify_token=None, app_secret=None):
        """
        Inicializa o serviço Meta
        
        Args:
            page_access_token: Token de acesso da página Facebook/Instagram
            verify_token: Token de verificação do webhook
            app_secret: Segredo da aplicação Meta
        """
        self.page_access_token = page_access_token or current_app.config.get('META_PAGE_ACCESS_TOKEN', '')
        self.verify_token = verify_token or current_app.config.get('META_VERIFY_TOKEN', '')
        self.app_secret = app_secret or current_app.config.get('META_APP_SECRET', '')
        
        self.graph_api_url = 'https://graph.facebook.com/v18.0'
        
        self.headers = {
            'Content-Type': 'application/json'
        }
    
    def verify_webhook_signature(self, payload, signature):
        """Verifica assinatura do webhook Meta"""
        try:
            if not self.app_secret:
                return True  # Skip verification if no secret configured
            
            expected_signature = hmac.new(
                self.app_secret.encode('utf-8'),
                payload,
                hashlib.sha256
            ).hexdigest()
            
            return hmac.compare_digest(f"sha256={expected_signature}", signature)
            
        except Exception as e:
            print(f"Erro ao verificar assinatura webhook: {e}")
            return False
    
    def send_facebook_message(self, recipient_id, message_text):
        """Envia mensagem via Facebook Messenger"""
        try:
            url = f"{self.graph_api_url}/me/messages"
            
            data = {
                "recipient": {"id": recipient_id},
                "message": {"text": message_text},
                "messaging_type": "RESPONSE"
            }
            
            params = {
                "access_token": self.page_access_token
            }
            
            response = requests.post(url, json=data, params=params, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao enviar mensagem Facebook: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar mensagem Facebook: {e}")
            return None
    
    def send_facebook_quick_replies(self, recipient_id, message_text, quick_replies):
        """Envia mensagem com quick replies no Facebook"""
        try:
            url = f"{self.graph_api_url}/me/messages"
            
            # Formata quick replies
            formatted_replies = []
            for reply in quick_replies[:13]:  # Facebook permite máximo 13 quick replies
                formatted_replies.append({
                    "content_type": "text",
                    "title": reply.get('text', 'Opção'),
                    "payload": reply.get('callback_data', reply.get('text', 'option'))
                })
            
            data = {
                "recipient": {"id": recipient_id},
                "message": {
                    "text": message_text,
                    "quick_replies": formatted_replies
                },
                "messaging_type": "RESPONSE"
            }
            
            params = {
                "access_token": self.page_access_token
            }
            
            response = requests.post(url, json=data, params=params, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao enviar quick replies Facebook: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar quick replies Facebook: {e}")
            return None
    
    def send_facebook_buttons(self, recipient_id, message_text, buttons):
        """Envia mensagem com botões no Facebook"""
        try:
            url = f"{self.graph_api_url}/me/messages"
            
            # Formata botões
            formatted_buttons = []
            for button in buttons[:3]:  # Facebook permite máximo 3 botões
                formatted_buttons.append({
                    "type": "postback",
                    "title": button.get('text', 'Opção'),
                    "payload": button.get('callback_data', button.get('text', 'option'))
                })
            
            data = {
                "recipient": {"id": recipient_id},
                "message": {
                    "attachment": {
                        "type": "template",
                        "payload": {
                            "template_type": "button",
                            "text": message_text,
                            "buttons": formatted_buttons
                        }
                    }
                },
                "messaging_type": "RESPONSE"
            }
            
            params = {
                "access_token": self.page_access_token
            }
            
            response = requests.post(url, json=data, params=params, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao enviar botões Facebook: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar botões Facebook: {e}")
            return None
    
    def send_facebook_image(self, recipient_id, image_url, caption=None):
        """Envia imagem via Facebook Messenger"""
        try:
            url = f"{self.graph_api_url}/me/messages"
            
            message_data = {
                "attachment": {
                    "type": "image",
                    "payload": {
                        "url": image_url,
                        "is_reusable": True
                    }
                }
            }
            
            data = {
                "recipient": {"id": recipient_id},
                "message": message_data,
                "messaging_type": "RESPONSE"
            }
            
            params = {
                "access_token": self.page_access_token
            }
            
            response = requests.post(url, json=data, params=params, headers=self.headers)
            
            if response.status_code == 200:
                result = response.json()
                
                # Se há caption, envia como mensagem separada
                if caption:
                    self.send_facebook_message(recipient_id, caption)
                
                return result
            else:
                print(f"Erro ao enviar imagem Facebook: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar imagem Facebook: {e}")
            return None
    
    def send_instagram_message(self, recipient_id, message_text):
        """Envia mensagem via Instagram Direct"""
        try:
            url = f"{self.graph_api_url}/me/messages"
            
            data = {
                "recipient": {"id": recipient_id},
                "message": {"text": message_text}
            }
            
            params = {
                "access_token": self.page_access_token
            }
            
            response = requests.post(url, json=data, params=params, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao enviar mensagem Instagram: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar mensagem Instagram: {e}")
            return None
    
    def send_instagram_quick_replies(self, recipient_id, message_text, quick_replies):
        """Envia mensagem com quick replies no Instagram"""
        try:
            url = f"{self.graph_api_url}/me/messages"
            
            # Formata quick replies
            formatted_replies = []
            for reply in quick_replies[:13]:  # Instagram permite máximo 13 quick replies
                formatted_replies.append({
                    "content_type": "text",
                    "title": reply.get('text', 'Opção'),
                    "payload": reply.get('callback_data', reply.get('text', 'option'))
                })
            
            data = {
                "recipient": {"id": recipient_id},
                "message": {
                    "text": message_text,
                    "quick_replies": formatted_replies
                }
            }
            
            params = {
                "access_token": self.page_access_token
            }
            
            response = requests.post(url, json=data, params=params, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao enviar quick replies Instagram: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar quick replies Instagram: {e}")
            return None
    
    def send_instagram_image(self, recipient_id, image_url, caption=None):
        """Envia imagem via Instagram Direct"""
        try:
            url = f"{self.graph_api_url}/me/messages"
            
            message_data = {
                "attachment": {
                    "type": "image",
                    "payload": {
                        "url": image_url,
                        "is_reusable": True
                    }
                }
            }
            
            data = {
                "recipient": {"id": recipient_id},
                "message": message_data
            }
            
            params = {
                "access_token": self.page_access_token
            }
            
            response = requests.post(url, json=data, params=params, headers=self.headers)
            
            if response.status_code == 200:
                result = response.json()
                
                # Se há caption, envia como mensagem separada
                if caption:
                    self.send_instagram_message(recipient_id, caption)
                
                return result
            else:
                print(f"Erro ao enviar imagem Instagram: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar imagem Instagram: {e}")
            return None
    
    def get_user_profile(self, user_id, platform='facebook'):
        """Obtém perfil do usuário"""
        try:
            if platform == 'facebook':
                url = f"{self.graph_api_url}/{user_id}"
                params = {
                    "fields": "first_name,last_name,profile_pic",
                    "access_token": self.page_access_token
                }
            else:  # Instagram
                url = f"{self.graph_api_url}/{user_id}"
                params = {
                    "fields": "name,profile_pic",
                    "access_token": self.page_access_token
                }
            
            response = requests.get(url, params=params)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao obter perfil {platform}: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao obter perfil {platform}: {e}")
            return None
    
    def process_facebook_webhook(self, webhook_data):
        """Processa webhook do Facebook"""
        try:
            entries = webhook_data.get('entry', [])
            
            for entry in entries:
                messaging = entry.get('messaging', [])
                
                for message_event in messaging:
                    sender_id = message_event.get('sender', {}).get('id')
                    recipient_id = message_event.get('recipient', {}).get('id')
                    timestamp = message_event.get('timestamp')
                    
                    # Mensagem de texto
                    if 'message' in message_event:
                        message = message_event['message']
                        
                        # Quick reply response
                        if 'quick_reply' in message:
                            return {
                                'platform': 'facebook',
                                'user_id': sender_id,
                                'message_id': message.get('mid'),
                                'text': message.get('text'),
                                'quick_reply_payload': message['quick_reply'].get('payload'),
                                'timestamp': datetime.fromtimestamp(timestamp / 1000) if timestamp else datetime.utcnow(),
                                'raw_data': webhook_data
                            }
                        
                        # Mensagem com anexo
                        elif 'attachments' in message:
                            attachment = message['attachments'][0]
                            return {
                                'platform': 'facebook',
                                'user_id': sender_id,
                                'message_id': message.get('mid'),
                                'text': message.get('text'),
                                'attachment': {
                                    'type': attachment.get('type'),
                                    'url': attachment.get('payload', {}).get('url')
                                },
                                'timestamp': datetime.fromtimestamp(timestamp / 1000) if timestamp else datetime.utcnow(),
                                'raw_data': webhook_data
                            }
                        
                        # Mensagem de texto simples
                        else:
                            return {
                                'platform': 'facebook',
                                'user_id': sender_id,
                                'message_id': message.get('mid'),
                                'text': message.get('text'),
                                'timestamp': datetime.fromtimestamp(timestamp / 1000) if timestamp else datetime.utcnow(),
                                'raw_data': webhook_data
                            }
                    
                    # Postback (botão pressionado)
                    elif 'postback' in message_event:
                        postback = message_event['postback']
                        return {
                            'platform': 'facebook',
                            'user_id': sender_id,
                            'postback_payload': postback.get('payload'),
                            'postback_title': postback.get('title'),
                            'timestamp': datetime.fromtimestamp(timestamp / 1000) if timestamp else datetime.utcnow(),
                            'raw_data': webhook_data
                        }
            
            return None
            
        except Exception as e:
            print(f"Erro ao processar webhook Facebook: {e}")
            return None
    
    def process_instagram_webhook(self, webhook_data):
        """Processa webhook do Instagram"""
        try:
            entries = webhook_data.get('entry', [])
            
            for entry in entries:
                messaging = entry.get('messaging', [])
                
                for message_event in messaging:
                    sender_id = message_event.get('sender', {}).get('id')
                    recipient_id = message_event.get('recipient', {}).get('id')
                    timestamp = message_event.get('timestamp')
                    
                    # Mensagem de texto
                    if 'message' in message_event:
                        message = message_event['message']
                        
                        # Quick reply response
                        if 'quick_reply' in message:
                            return {
                                'platform': 'instagram',
                                'user_id': sender_id,
                                'message_id': message.get('mid'),
                                'text': message.get('text'),
                                'quick_reply_payload': message['quick_reply'].get('payload'),
                                'timestamp': datetime.fromtimestamp(timestamp / 1000) if timestamp else datetime.utcnow(),
                                'raw_data': webhook_data
                            }
                        
                        # Mensagem com anexo
                        elif 'attachments' in message:
                            attachment = message['attachments'][0]
                            return {
                                'platform': 'instagram',
                                'user_id': sender_id,
                                'message_id': message.get('mid'),
                                'text': message.get('text'),
                                'attachment': {
                                    'type': attachment.get('type'),
                                    'url': attachment.get('payload', {}).get('url')
                                },
                                'timestamp': datetime.fromtimestamp(timestamp / 1000) if timestamp else datetime.utcnow(),
                                'raw_data': webhook_data
                            }
                        
                        # Mensagem de texto simples
                        else:
                            return {
                                'platform': 'instagram',
                                'user_id': sender_id,
                                'message_id': message.get('mid'),
                                'text': message.get('text'),
                                'timestamp': datetime.fromtimestamp(timestamp / 1000) if timestamp else datetime.utcnow(),
                                'raw_data': webhook_data
                            }
            
            return None
            
        except Exception as e:
            print(f"Erro ao processar webhook Instagram: {e}")
            return None
    
    def set_facebook_get_started_button(self, payload="get_started"):
        """Configura botão "Começar" do Facebook"""
        try:
            url = f"{self.graph_api_url}/me/messenger_profile"
            
            data = {
                "get_started": {
                    "payload": payload
                }
            }
            
            params = {
                "access_token": self.page_access_token
            }
            
            response = requests.post(url, json=data, params=params, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao configurar botão começar: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao configurar botão começar: {e}")
            return None
    
    def set_facebook_persistent_menu(self, menu_items):
        """Configura menu persistente do Facebook"""
        try:
            url = f"{self.graph_api_url}/me/messenger_profile"
            
            data = {
                "persistent_menu": [
                    {
                        "locale": "default",
                        "composer_input_disabled": False,
                        "call_to_actions": menu_items
                    }
                ]
            }
            
            params = {
                "access_token": self.page_access_token
            }
            
            response = requests.post(url, json=data, params=params, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao configurar menu persistente: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao configurar menu persistente: {e}")
            return None
    
    @staticmethod
    def get_clinic_meta_service(clinic_slug=None):
        """Obtém serviço Meta configurado para uma clínica específica"""
        try:
            if clinic_slug:
                clinic = Clinic.query.filter_by(slug=clinic_slug, active=True).first()
            else:
                clinic = MultiTenantManager.get_current_clinic()
            
            if not clinic:
                return None
            
            # Configurações específicas da clínica
            page_access_token = clinic.facebook_token or current_app.config.get('META_PAGE_ACCESS_TOKEN')
            verify_token = clinic.facebook_verify_token or current_app.config.get('META_VERIFY_TOKEN')
            app_secret = clinic.facebook_app_secret or current_app.config.get('META_APP_SECRET')
            
            if not page_access_token:
                return None
            
            return MetaService(
                page_access_token=page_access_token,
                verify_token=verify_token,
                app_secret=app_secret
            )
            
        except Exception as e:
            print(f"Erro ao obter serviço Meta da clínica: {e}")
            return None
