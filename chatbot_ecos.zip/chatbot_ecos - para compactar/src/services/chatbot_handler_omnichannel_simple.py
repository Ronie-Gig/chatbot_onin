import json
import re
from datetime import datetime, timedelta
from flask import current_app
from src.models.multi_tenant import db, User, Exam, Appointment, Clinic, ChatLog
from src.services.telegram_service import TelegramService
from src.services.whatsapp_service import WhatsAppService
from src.services.meta_service import MetaService
from src.utils.multi_tenant import MultiTenantManager
from src.utils.validators import validate_cpf, validate_phone, validate_email

class OmnichannelChatbotHandler:
    """Handler de chatbot adaptado para múltiplas plataformas"""
    
    def __init__(self):
        self.platform_services = {}
    
    def get_platform_service(self, platform, clinic_slug=None):
        """Obtém serviço da plataforma específica"""
        try:
            if platform == 'telegram':
                return TelegramService.get_clinic_telegram_service(clinic_slug)
            elif platform == 'whatsapp':
                return WhatsAppService.get_clinic_whatsapp_service(clinic_slug)
            elif platform in ['facebook', 'instagram']:
                return MetaService.get_clinic_meta_service(clinic_slug)
            return None
        except Exception as e:
            print(f"Erro ao obter serviço da plataforma {platform}: {e}")
            return None
    
    def process_omnichannel_message(self, message_data):
        """Processa mensagem de qualquer plataforma"""
        try:
            platform = message_data.get('platform')
            clinic = MultiTenantManager.get_current_clinic()
            
            if not clinic:
                return None
            
            # Obtém ou cria usuário
            user = self._get_or_create_user(message_data, clinic.id)
            
            if not user:
                return None
            
            # Processa baseado no tipo de mensagem
            response = None
            
            # Mensagem de texto
            if message_data.get('text'):
                response = self._process_text_message(user, message_data)
            
            # Resposta de botão/quick reply
            elif message_data.get('button_response') or message_data.get('quick_reply_payload') or message_data.get('postback_payload'):
                response = self._process_button_response(user, message_data)
            
            # Comando especial (ex: /start)
            elif message_data.get('text', '').startswith('/'):
                response = self._process_command(user, message_data)
            
            # Resposta padrão
            else:
                response = self._create_menu_response()
            
            # Envia resposta
            if response:
                self._send_platform_response(user, response, message_data)
            
            return response
            
        except Exception as e:
            print(f"Erro ao processar mensagem omnichannel: {e}")
            return None
    
    def _get_or_create_user(self, message_data, clinic_id):
        """Obtém ou cria usuário baseado na plataforma"""
        try:
            platform = message_data.get('platform', '').upper()
            
            # Identifica ID do usuário baseado na plataforma
            user_id = None
            if platform == 'TELEGRAM':
                user_id = str(message_data.get('chat_id') or message_data.get('user_id'))
            elif platform == 'WHATSAPP':
                user_id = str(message_data.get('phone_number', '').replace('@s.whatsapp.net', ''))
            elif platform in ['FACEBOOK', 'INSTAGRAM']:
                user_id = str(message_data.get('user_id'))
            
            if not user_id:
                return None
            
            # Busca usuário existente
            user = User.query.filter_by(
                clinic_id=clinic_id,
                platform_user_id=user_id,
                platform=platform
            ).first()
            
            if not user:
                # Cria novo usuário
                user = User(
                    clinic_id=clinic_id,
                    platform_user_id=user_id,
                    platform=platform,
                    current_state='MENU',
                    created_at=datetime.utcnow()
                )
                
                db.session.add(user)
                db.session.commit()
            
            return user
            
        except Exception as e:
            print(f"Erro ao obter/criar usuário: {e}")
            return None
    
    def _process_text_message(self, user, message_data):
        """Processa mensagem de texto"""
        try:
            text = message_data.get('text', '').strip()
            
            # Estados do fluxo de conversação
            if user.current_state == 'MENU':
                return self._create_menu_response()
            else:
                return self._create_menu_response()
                
        except Exception as e:
            print(f"Erro ao processar mensagem de texto: {e}")
            return self._create_error_response()
    
    def _process_button_response(self, user, message_data):
        """Processa resposta de botão/callback"""
        try:
            # Obtém callback data baseado na plataforma
            callback_data = None
            
            if message_data.get('button_response'):
                callback_data = message_data['button_response']
            elif message_data.get('quick_reply_payload'):
                callback_data = message_data['quick_reply_payload']
            elif message_data.get('postback_payload'):
                callback_data = message_data['postback_payload']
            
            if not callback_data:
                return self._create_menu_response()
            
            # Processa callback básico
            if callback_data == 'agendar_exame':
                return self._create_menu_response()
            elif callback_data == 'consultar_precos':
                return self._create_menu_response()
            else:
                return self._create_menu_response()
                
        except Exception as e:
            print(f"Erro ao processar resposta de botão: {e}")
            return self._create_error_response()
    
    def _process_command(self, user, message_data):
        """Processa comandos especiais"""
        try:
            command = message_data.get('text', '').lower()
            
            if command in ['/start', '/menu', '/inicio']:
                user.current_state = 'MENU'
                db.session.commit()
                return self._create_welcome_response(user)
            else:
                return self._create_menu_response()
                
        except Exception as e:
            print(f"Erro ao processar comando: {e}")
            return self._create_error_response()
    
    def _send_platform_response(self, user, response, original_message):
        """Envia resposta adaptada para cada plataforma"""
        try:
            platform = user.platform.lower()
            # Simula envio sem realmente enviar
            print(f"Enviando resposta para {platform}: {response.get('text', '')[:50]}...")
            return True
            
        except Exception as e:
            print(f"Erro ao enviar resposta da plataforma: {e}")
            return False
    
    # Métodos auxiliares para criar respostas
    def _create_welcome_response(self, user):
        """Cria resposta de boas-vindas"""
        clinic = MultiTenantManager.get_current_clinic()
        clinic_name = clinic.name if clinic else "Clínica"
        
        return {
            'text': f"🏥 Olá! Bem-vindo(a) ao {clinic_name}!\n\n"
                   f"Sou seu assistente virtual e estou aqui para ajudar com:\n\n"
                   f"📅 Agendamento de exames\n"
                   f"💰 Consulta de preços\n"
                   f"📋 Informações sobre procedimentos\n\n"
                   f"Como posso ajudá-lo(a) hoje?",
            'buttons': [
                {'text': '📅 Agendar Exame', 'callback_data': 'agendar_exame'},
                {'text': '💰 Consultar Preços', 'callback_data': 'consultar_precos'}
            ]
        }
    
    def _create_menu_response(self):
        """Cria resposta do menu principal"""
        return {
            'text': "🏠 Menu Principal\n\nEscolha uma das opções abaixo:",
            'buttons': [
                {'text': '📅 Agendar Exame', 'callback_data': 'agendar_exame'},
                {'text': '💰 Consultar Preços', 'callback_data': 'consultar_precos'}
            ]
        }
    
    def _create_error_response(self):
        """Cria resposta de erro"""
        return {
            'text': "❌ Ops! Ocorreu um erro. Vamos tentar novamente?\n\n"
                   "Use /start para voltar ao menu principal.",
            'buttons': [
                {'text': '🏠 Menu Principal', 'callback_data': 'back_menu'}
            ]
        }
    
    def _create_help_response(self):
        """Cria resposta de ajuda"""
        return {
            'text': "🆘 Central de Ajuda\n\n"
                   "Comandos disponíveis:\n"
                   "• /start - Menu principal\n"
                   "• /help - Esta ajuda\n"
                   "• /status - Meus agendamentos\n\n"
                   "Para agendar exames, use o botão abaixo:",
            'buttons': [
                {'text': '📅 Agendar Exame', 'callback_data': 'agendar_exame'},
                {'text': '🏠 Menu Principal', 'callback_data': 'back_menu'}
            ]
        }
