import requests
from datetime import datetime
from flask import current_app
from src.models.multi_tenant import db, User, Appointment, Clinic
from src.utils.multi_tenant import MultiTenantManager

class NotificationService:
    """Serviço para envio de notificações aos usuários"""
    
    @staticmethod
    def send_telegram_message(user_id, message, bot_token, reply_markup=None):
        """Envia mensagem via Telegram"""
        try:
            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            
            data = {
                'chat_id': user_id,
                'text': message,
                'parse_mode': 'HTML'
            }
            
            if reply_markup:
                data['reply_markup'] = reply_markup
            
            response = requests.post(url, json=data)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao enviar mensagem Telegram: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar mensagem Telegram: {e}")
            return None
    
    @staticmethod
    def notify_image_approved(user_id, file_id, approved_by):
        """Notifica usuário sobre aprovação da imagem"""
        try:
            user = User.query.filter_by(
                telegram_id=str(user_id),
                photo_file_id=file_id
            ).first()
            
            if not user or not user.clinic:
                return False
            
            # Busca agendamentos relacionados
            appointments = Appointment.query.filter_by(
                user_id=user.id,
                photo_file_id=file_id
            ).all()
            
            if not appointments:
                return False
            
            # Monta mensagem de aprovação
            clinic = user.clinic
            message = f"""
🎉 <b>Pedido Médico Aprovado!</b>

Olá {user.name or 'paciente'}!

Sua solicitação de exames foi <b>aprovada</b> pela equipe da {clinic.name}.

📋 <b>Detalhes do agendamento:</b>
"""
            
            for appointment in appointments:
                exams = appointment.get_exams()
                exam_names = [exam.get('exam_name', 'Exame') for exam in exams]
                
                message += f"""
• <b>Convênio:</b> {appointment.covenant_type}
• <b>Exames:</b> {', '.join(exam_names)}
• <b>Total:</b> R$ {appointment.total_price:.2f}
"""
            
            message += f"""
📞 <b>Próximos passos:</b>
Entre em contato conosco para agendar seu exame:
• Telefone: {clinic.phone_call}
• WhatsApp: {clinic.phone_whatsapp}

📍 <b>Endereço:</b>
{clinic.address}

🕒 <b>Horário de funcionamento:</b>
{clinic.business_hours}

Obrigado por escolher a {clinic.name}!
"""
            
            # Envia notificação
            return NotificationService.send_telegram_message(
                user_id, 
                message, 
                clinic.telegram_token
            )
            
        except Exception as e:
            print(f"Erro ao notificar aprovação: {e}")
            return False
    
    @staticmethod
    def notify_image_rejected(user_id, file_id, rejected_by, reason=None):
        """Notifica usuário sobre rejeição da imagem"""
        try:
            user = User.query.filter_by(
                telegram_id=str(user_id),
                photo_file_id=file_id
            ).first()
            
            if not user or not user.clinic:
                return False
            
            clinic = user.clinic
            
            # Monta mensagem de rejeição
            message = f"""
❌ <b>Pedido Médico Não Aprovado</b>

Olá {user.name or 'paciente'}!

Infelizmente, sua solicitação de exames não foi aprovada pela equipe da {clinic.name}.
"""
            
            if reason:
                message += f"""
📝 <b>Motivo:</b> {reason}
"""
            
            message += f"""
🔄 <b>O que fazer agora:</b>
• Envie uma nova foto do seu pedido médico mais clara
• Certifique-se de que todas as informações estão legíveis
• Entre em contato conosco se tiver dúvidas

📞 <b>Contato:</b>
• Telefone: {clinic.phone_call}
• WhatsApp: {clinic.phone_whatsapp}

Para enviar uma nova foto, digite /start e siga as instruções.

Estamos aqui para ajudar! 😊
"""
            
            # Envia notificação
            return NotificationService.send_telegram_message(
                user_id, 
                message, 
                clinic.telegram_token
            )
            
        except Exception as e:
            print(f"Erro ao notificar rejeição: {e}")
            return False
    
    @staticmethod
    def notify_appointment_confirmed(appointment_id):
        """Notifica usuário sobre confirmação do agendamento"""
        try:
            appointment = Appointment.query.get(appointment_id)
            if not appointment or not appointment.user:
                return False
            
            user = appointment.user
            clinic = appointment.clinic
            
            if not user.telegram_id or not clinic.telegram_token:
                return False
            
            exams = appointment.get_exams()
            exam_names = [exam.get('exam_name', 'Exame') for exam in exams]
            
            message = f"""
✅ <b>Agendamento Confirmado!</b>

Olá {user.name or 'paciente'}!

Seu agendamento foi confirmado com sucesso!

📋 <b>Detalhes:</b>
• <b>Convênio:</b> {appointment.covenant_type}
• <b>Exames:</b> {', '.join(exam_names)}
• <b>Total:</b> R$ {appointment.total_price:.2f}
• <b>Data da solicitação:</b> {appointment.created_at.strftime('%d/%m/%Y às %H:%M')}

📞 <b>Próximos passos:</b>
Nossa equipe entrará em contato para agendar a data e horário do seu exame.

📍 <b>Local:</b>
{clinic.name}
{clinic.address}

🕒 <b>Horário de funcionamento:</b>
{clinic.business_hours}

📞 <b>Contato:</b>
• Telefone: {clinic.phone_call}
• WhatsApp: {clinic.phone_whatsapp}

Obrigado por escolher nossos serviços! 🏥
"""
            
            return NotificationService.send_telegram_message(
                user.telegram_id,
                message,
                clinic.telegram_token
            )
            
        except Exception as e:
            print(f"Erro ao notificar confirmação: {e}")
            return False
    
    @staticmethod
    def notify_appointment_cancelled(appointment_id, reason=None):
        """Notifica usuário sobre cancelamento do agendamento"""
        try:
            appointment = Appointment.query.get(appointment_id)
            if not appointment or not appointment.user:
                return False
            
            user = appointment.user
            clinic = appointment.clinic
            
            if not user.telegram_id or not clinic.telegram_token:
                return False
            
            message = f"""
❌ <b>Agendamento Cancelado</b>

Olá {user.name or 'paciente'}!

Seu agendamento foi cancelado.
"""
            
            if reason:
                message += f"""
📝 <b>Motivo:</b> {reason}
"""
            
            message += f"""
🔄 <b>Nova solicitação:</b>
Se desejar, você pode fazer uma nova solicitação digitando /start

📞 <b>Dúvidas:</b>
Entre em contato conosco:
• Telefone: {clinic.phone_call}
• WhatsApp: {clinic.phone_whatsapp}

Estamos à disposição para esclarecer qualquer dúvida.
"""
            
            return NotificationService.send_telegram_message(
                user.telegram_id,
                message,
                clinic.telegram_token
            )
            
        except Exception as e:
            print(f"Erro ao notificar cancelamento: {e}")
            return False
    
    @staticmethod
    def send_admin_notification(clinic_id, message, notification_type='INFO'):
        """Envia notificação para administradores da clínica"""
        try:
            # Busca administradores da clínica
            admins = AdminUser.query.filter_by(
                clinic_id=clinic_id,
                active=True
            ).all()
            
            clinic = Clinic.query.get(clinic_id)
            if not clinic or not clinic.telegram_token:
                return False
            
            notification_message = f"""
🔔 <b>Notificação - {clinic.name}</b>

<b>Tipo:</b> {notification_type}
<b>Data:</b> {datetime.utcnow().strftime('%d/%m/%Y às %H:%M')}

<b>Mensagem:</b>
{message}
"""
            
            # Envia para cada admin (se tiver telegram_id configurado)
            sent_count = 0
            for admin in admins:
                if hasattr(admin, 'telegram_id') and admin.telegram_id:
                    result = NotificationService.send_telegram_message(
                        admin.telegram_id,
                        notification_message,
                        clinic.telegram_token
                    )
                    if result:
                        sent_count += 1
            
            return sent_count > 0
            
        except Exception as e:
            print(f"Erro ao enviar notificação admin: {e}")
            return False
    
    @staticmethod
    def notify_new_appointment(appointment_id):
        """Notifica administradores sobre novo agendamento"""
        try:
            appointment = Appointment.query.get(appointment_id)
            if not appointment:
                return False
            
            user = appointment.user
            exams = appointment.get_exams()
            exam_names = [exam.get('exam_name', 'Exame') for exam in exams]
            
            message = f"""
📅 <b>Novo Agendamento Recebido!</b>

<b>Paciente:</b> {user.name or 'Nome não informado'}
<b>CPF:</b> {user.cpf or 'Não informado'}
<b>Convênio:</b> {appointment.covenant_type}
<b>Total:</b> R$ {appointment.total_price:.2f}

<b>Exames solicitados:</b>
{chr(10).join([f'• {name}' for name in exam_names])}

<b>Status da imagem:</b> {'✅ Aprovada' if user.photo_approved else '⏳ Pendente de aprovação'}

<b>Data:</b> {appointment.created_at.strftime('%d/%m/%Y às %H:%M')}

Acesse o dashboard para mais detalhes.
"""
            
            return NotificationService.send_admin_notification(
                appointment.clinic_id,
                message,
                'NOVO_AGENDAMENTO'
            )
            
        except Exception as e:
            print(f"Erro ao notificar novo agendamento: {e}")
            return False
    
    @staticmethod
    def notify_image_pending_approval(user_id, file_id):
        """Notifica administradores sobre nova imagem pendente"""
        try:
            user = User.query.filter_by(
                telegram_id=str(user_id),
                photo_file_id=file_id
            ).first()
            
            if not user:
                return False
            
            message = f"""
📸 <b>Nova Imagem Pendente de Aprovação</b>

<b>Paciente:</b> {user.name or 'Nome não informado'}
<b>CPF:</b> {user.cpf or 'Não informado'}
<b>Telegram ID:</b> {user.telegram_id}

<b>Data do envio:</b> {datetime.utcnow().strftime('%d/%m/%Y às %H:%M')}

Acesse o dashboard para visualizar e aprovar a imagem.
"""
            
            return NotificationService.send_admin_notification(
                user.clinic_id,
                message,
                'IMAGEM_PENDENTE'
            )
            
        except Exception as e:
            print(f"Erro ao notificar imagem pendente: {e}")
            return False
