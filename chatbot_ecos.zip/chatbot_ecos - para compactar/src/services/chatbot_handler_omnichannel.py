import json
import re
from datetime import datetime, timedelta
from flask import current_app
from src.models.multi_tenant import db, User, Exam, Appointment, Clinic, ChatLog
from src.services.telegram_service import TelegramService
from src.services.whatsapp_service import WhatsAppService
from src.services.meta_service import MetaService
from src.utils.multi_tenant import MultiTenantManager
from src.utils.validators import validate_cpf, validate_phone, validate_email

class OmnichannelChatbotHandler:
    """Handler de chatbot adaptado para múltiplas plataformas"""
    
    def __init__(self):
        self.platform_services = {}
    
    def get_platform_service(self, platform, clinic_slug=None):
        """Obtém serviço da plataforma específica"""
        try:
            if platform == 'telegram':
                return TelegramService.get_clinic_telegram_service(clinic_slug)
            elif platform == 'whatsapp':
                return WhatsAppService.get_clinic_whatsapp_service(clinic_slug)
            elif platform in ['facebook', 'instagram']:
                return MetaService.get_clinic_meta_service(clinic_slug)
            return None
        except Exception as e:
            print(f"Erro ao obter serviço da plataforma {platform}: {e}")
            return None
    
    def process_omnichannel_message(self, message_data):
        """Processa mensagem de qualquer plataforma"""
        try:
            platform = message_data.get('platform')
            clinic = MultiTenantManager.get_current_clinic()
            
            if not clinic:
                return None
            
            # Obtém ou cria usuário
            user = self._get_or_create_user(message_data, clinic.id)
            
            if not user:
                return None
            
            # Processa baseado no tipo de mensagem
            response = None
            
            # Mensagem de texto
            if message_data.get('text'):
                response = self._process_text_message(user, message_data)
            
            # Resposta de botão/quick reply
            elif message_data.get('button_response') or message_data.get('quick_reply_payload') or message_data.get('postback_payload'):
                response = self._process_button_response(user, message_data)
            
            # Resposta de lista
            elif message_data.get('list_response'):
                response = self._process_list_response(user, message_data)
            
            # Mídia (imagem, documento)
            elif message_data.get('media') or message_data.get('attachment'):
                response = self._process_media_message(user, message_data)
            
            # Comando especial (ex: /start)
            elif message_data.get('text', '').startswith('/'):
                response = self._process_command(user, message_data)
            
            # Resposta padrão
            else:
                response = self._process_default_message(user, message_data)
            
            # Envia resposta
            if response:
                self._send_platform_response(user, response, message_data)
            
            return response
            
        except Exception as e:
            print(f"Erro ao processar mensagem omnichannel: {e}")
            return None
    
    def _get_or_create_user(self, message_data, clinic_id):
        """Obtém ou cria usuário baseado na plataforma"""
        try:
            platform = message_data.get('platform', '').upper()
            
            # Identifica ID do usuário baseado na plataforma
            user_id = None
            if platform == 'TELEGRAM':
                user_id = str(message_data.get('chat_id') or message_data.get('user_id'))
            elif platform == 'WHATSAPP':
                user_id = str(message_data.get('phone_number', '').replace('@s.whatsapp.net', ''))
            elif platform in ['FACEBOOK', 'INSTAGRAM']:
                user_id = str(message_data.get('user_id'))
            
            if not user_id:
                return None
            
            # Busca usuário existente
            user = User.query.filter_by(
                clinic_id=clinic_id,
                platform_user_id=user_id,
                platform=platform
            ).first()
            
            if not user:
                # Cria novo usuário
                user = User(
                    clinic_id=clinic_id,
                    platform_user_id=user_id,
                    platform=platform,
                    current_state='MENU',
                    created_at=datetime.utcnow()
                )
                
                # Obtém informações do perfil se disponível
                profile_info = self._get_user_profile_info(message_data)
                if profile_info:
                    user.name = profile_info.get('name')
                    user.profile_photo_url = profile_info.get('profile_photo')
                
                db.session.add(user)
                db.session.commit()\n            \n            return user\n            \n        except Exception as e:\n            print(f\"Erro ao obter/criar usuário: {e}\")\n            return None\n    \n    def _get_user_profile_info(self, message_data):\n        \"\"\"Obtém informações do perfil do usuário\"\"\"\n        try:\n            platform = message_data.get('platform')\n            \n            if platform == 'telegram':\n                # Telegram já vem com informações no webhook\n                return {\n                    'name': message_data.get('first_name', '') + ' ' + message_data.get('last_name', ''),\n                    'username': message_data.get('username'),\n                    'profile_photo': None  # Telegram não fornece foto no webhook\n                }\n            \n            elif platform == 'whatsapp':\n                # WhatsApp - pode obter via Evolution API\n                phone_number = message_data.get('phone_number')\n                if phone_number:\n                    service = self.get_platform_service('whatsapp')\n                    if service:\n                        profile = service.get_profile_picture(phone_number)\n                        return {\n                            'name': phone_number,  # WhatsApp não fornece nome real\n                            'profile_photo': profile.get('profilePictureUrl') if profile else None\n                        }\n            \n            elif platform in ['facebook', 'instagram']:\n                # Facebook/Instagram - pode obter via Graph API\n                user_id = message_data.get('user_id')\n                if user_id:\n                    service = self.get_platform_service(platform)\n                    if service:\n                        profile = service.get_user_profile(user_id, platform)\n                        if profile:\n                            name = ''\n                            if platform == 'facebook':\n                                name = f\"{profile.get('first_name', '')} {profile.get('last_name', '')}\".strip()\n                            else:\n                                name = profile.get('name', '')\n                            \n                            return {\n                                'name': name,\n                                'profile_photo': profile.get('profile_pic')\n                            }\n            \n            return None\n            \n        except Exception as e:\n            print(f\"Erro ao obter informações do perfil: {e}\")\n            return None\n    \n    def _process_text_message(self, user, message_data):\n        \"\"\"Processa mensagem de texto\"\"\"\n        try:\n            text = message_data.get('text', '').strip()\n            \n            # Estados do fluxo de conversação\n            if user.current_state == 'MENU':\n                return self._handle_menu_selection(user, text)\n            \n            elif user.current_state == 'AWAITING_NAME':\n                return self._handle_name_input(user, text)\n            \n            elif user.current_state == 'AWAITING_CPF':\n                return self._handle_cpf_input(user, text)\n            \n            elif user.current_state == 'AWAITING_PHONE':\n                return self._handle_phone_input(user, text)\n            \n            elif user.current_state == 'AWAITING_EMAIL':\n                return self._handle_email_input(user, text)\n            \n            elif user.current_state == 'AWAITING_BIRTH_DATE':\n                return self._handle_birth_date_input(user, text)\n            \n            elif user.current_state == 'AWAITING_EXAM_PHOTO':\n                return self._handle_exam_photo_text(user, text)\n            \n            else:\n                return self._handle_default_text(user, text)\n                \n        except Exception as e:\n            print(f\"Erro ao processar mensagem de texto: {e}\")\n            return self._create_error_response()\n    \n    def _process_button_response(self, user, message_data):\n        \"\"\"Processa resposta de botão/callback\"\"\"\n        try:\n            # Obtém callback data baseado na plataforma\n            callback_data = None\n            \n            if message_data.get('button_response'):\n                callback_data = message_data['button_response']\n            elif message_data.get('quick_reply_payload'):\n                callback_data = message_data['quick_reply_payload']\n            elif message_data.get('postback_payload'):\n                callback_data = message_data['postback_payload']\n            \n            if not callback_data:\n                return self._create_menu_response()\n            \n            # Remove prefixos se necessário\n            if callback_data.startswith('btn_'):\n                callback_data = '_'.join(callback_data.split('_')[2:])  # Remove btn_X_\n            \n            # Processa callback\n            if callback_data == 'agendar_exame':\n                return self._handle_schedule_exam(user)\n            \n            elif callback_data == 'consultar_precos':\n                return self._handle_price_inquiry(user)\n            \n            elif callback_data.startswith('covenant_'):\n                covenant_id = callback_data.replace('covenant_', '')\n                return self._handle_covenant_selection(user, covenant_id)\n            \n            elif callback_data.startswith('category_'):\n                category_id = callback_data.replace('category_', '')\n                return self._handle_category_selection(user, category_id)\n            \n            elif callback_data.startswith('exam_'):\n                exam_id = callback_data.replace('exam_', '')\n                return self._handle_exam_selection(user, exam_id)\n            \n            elif callback_data == 'back_categories':\n                return self._handle_back_to_categories(user)\n            \n            elif callback_data == 'back_menu':\n                return self._handle_back_to_menu(user)\n            \n            elif callback_data == 'confirm_appointment':\n                return self._handle_confirm_appointment(user)\n            \n            elif callback_data == 'cancel_appointment':\n                return self._handle_cancel_appointment(user)\n            \n            else:\n                return self._create_menu_response()\n                \n        except Exception as e:\n            print(f\"Erro ao processar resposta de botão: {e}\")\n            return self._create_error_response()\n    \n    def _process_media_message(self, user, message_data):\n        \"\"\"Processa mensagem com mídia\"\"\"\n        try:\n            if user.current_state == 'AWAITING_EXAM_PHOTO':\n                return self._handle_exam_photo_upload(user, message_data)\n            else:\n                return {\n                    'text': \"📷 Foto recebida! Para enviar fotos de exames, primeiro inicie o processo de agendamento.\",\n                    'buttons': [\n                        {'text': '📅 Agendar Exame', 'callback_data': 'agendar_exame'},\n                        {'text': '🏠 Menu Principal', 'callback_data': 'back_menu'}\n                    ]\n                }\n                \n        except Exception as e:\n            print(f\"Erro ao processar mídia: {e}\")\n            return self._create_error_response()\n    \n    def _process_command(self, user, message_data):\n        \"\"\"Processa comandos especiais\"\"\"\n        try:\n            command = message_data.get('text', '').lower()\n            \n            if command in ['/start', '/menu', '/inicio']:\n                user.current_state = 'MENU'\n                db.session.commit()\n                return self._create_welcome_response(user)\n            \n            elif command in ['/help', '/ajuda']:\n                return self._create_help_response()\n            \n            elif command in ['/status', '/meus_agendamentos']:\n                return self._handle_appointment_status(user)\n            \n            else:\n                return self._create_menu_response()\n                \n        except Exception as e:\n            print(f\"Erro ao processar comando: {e}\")\n            return self._create_error_response()\n    \n    def _send_platform_response(self, user, response, original_message):\n        \"\"\"Envia resposta adaptada para cada plataforma\"\"\"\n        try:\n            platform = user.platform.lower()\n            clinic = MultiTenantManager.get_current_clinic()\n            service = self.get_platform_service(platform, clinic.slug if clinic else None)\n            \n            if not service:\n                return False\n            \n            user_id = user.platform_user_id\n            \n            # Adapta resposta para cada plataforma\n            if platform == 'telegram':\n                return self._send_telegram_response(service, user_id, response)\n            \n            elif platform == 'whatsapp':\n                return self._send_whatsapp_response(service, user_id, response)\n            \n            elif platform == 'facebook':\n                return self._send_facebook_response(service, user_id, response)\n            \n            elif platform == 'instagram':\n                return self._send_instagram_response(service, user_id, response)\n            \n            return False\n            \n        except Exception as e:\n            print(f\"Erro ao enviar resposta da plataforma: {e}\")\n            return False\n    \n    def _send_telegram_response(self, service, chat_id, response):\n        \"\"\"Envia resposta para Telegram\"\"\"\n        try:\n            text = response.get('text', '')\n            \n            # Mensagem com botões inline\n            if response.get('buttons'):\n                buttons = []\n                for button in response['buttons']:\n                    buttons.append([{\n                        'text': button['text'],\n                        'callback_data': button['callback_data']\n                    }])\n                \n                return service.send_message_with_keyboard(\n                    chat_id=chat_id,\n                    text=text,\n                    reply_markup={'inline_keyboard': buttons}\n                )\n            \n            # Mensagem com imagem\n            elif response.get('image_url'):\n                return service.send_photo(\n                    chat_id=chat_id,\n                    photo=response['image_url'],\n                    caption=text\n                )\n            \n            # Mensagem de texto simples\n            else:\n                return service.send_message(chat_id=chat_id, text=text)\n                \n        except Exception as e:\n            print(f\"Erro ao enviar resposta Telegram: {e}\")\n            return False\n    \n    def _send_whatsapp_response(self, service, phone_number, response):\n        \"\"\"Envia resposta para WhatsApp\"\"\"\n        try:\n            text = response.get('text', '')\n            \n            # Mensagem com botões (máximo 3)\n            if response.get('buttons'):\n                buttons = response['buttons'][:3]  # WhatsApp permite máximo 3 botões\n                \n                if len(buttons) <= 3:\n                    return service.send_button_message(\n                        phone_number=phone_number,\n                        text=text,\n                        buttons=buttons\n                    )\n                else:\n                    # Se mais de 3 botões, usa lista\n                    sections = [{\n                        \"title\": \"Opções\",\n                        \"rows\": [\n                            {\n                                \"id\": button['callback_data'],\n                                \"title\": button['text'][:24],  # WhatsApp limita título\n                                \"description\": button['text']\n                            } for button in buttons\n                        ]\n                    }]\n                    \n                    return service.send_list_message(\n                        phone_number=phone_number,\n                        text=text,\n                        title=\"Escolha uma opção\",\n                        sections=sections\n                    )\n            \n            # Mensagem com imagem\n            elif response.get('image_url'):\n                return service.send_image_message(\n                    phone_number=phone_number,\n                    image_url=response['image_url'],\n                    caption=text\n                )\n            \n            # Mensagem de texto simples\n            else:\n                return service.send_text_message(\n                    phone_number=phone_number,\n                    message=text\n                )\n                \n        except Exception as e:\n            print(f\"Erro ao enviar resposta WhatsApp: {e}\")\n            return False\n    \n    def _send_facebook_response(self, service, user_id, response):\n        \"\"\"Envia resposta para Facebook\"\"\"\n        try:\n            text = response.get('text', '')\n            \n            # Mensagem com botões (máximo 3)\n            if response.get('buttons'):\n                buttons = response['buttons'][:3]  # Facebook permite máximo 3 botões\n                \n                if len(buttons) <= 3:\n                    return service.send_facebook_buttons(\n                        recipient_id=user_id,\n                        message_text=text,\n                        buttons=buttons\n                    )\n                else:\n                    # Se mais de 3 botões, usa quick replies (máximo 13)\n                    quick_replies = response['buttons'][:13]\n                    return service.send_facebook_quick_replies(\n                        recipient_id=user_id,\n                        message_text=text,\n                        quick_replies=quick_replies\n                    )\n            \n            # Mensagem com imagem\n            elif response.get('image_url'):\n                return service.send_facebook_image(\n                    recipient_id=user_id,\n                    image_url=response['image_url'],\n                    caption=text\n                )\n            \n            # Mensagem de texto simples\n            else:\n                return service.send_facebook_message(\n                    recipient_id=user_id,\n                    message_text=text\n                )\n                \n        except Exception as e:\n            print(f\"Erro ao enviar resposta Facebook: {e}\")\n            return False\n    \n    def _send_instagram_response(self, service, user_id, response):\n        \"\"\"Envia resposta para Instagram\"\"\"\n        try:\n            text = response.get('text', '')\n            \n            # Instagram tem limitações - principalmente quick replies\n            if response.get('buttons'):\n                quick_replies = response['buttons'][:13]  # Instagram permite máximo 13\n                return service.send_instagram_quick_replies(\n                    recipient_id=user_id,\n                    message_text=text,\n                    quick_replies=quick_replies\n                )\n            \n            # Mensagem com imagem\n            elif response.get('image_url'):\n                return service.send_instagram_image(\n                    recipient_id=user_id,\n                    image_url=response['image_url'],\n                    caption=text\n                )\n            \n            # Mensagem de texto simples\n            else:\n                return service.send_instagram_message(\n                    recipient_id=user_id,\n                    message_text=text\n                )\n                \n        except Exception as e:\n            print(f\"Erro ao enviar resposta Instagram: {e}\")\n            return False\n    \n    # Métodos auxiliares para criar respostas\n    def _create_welcome_response(self, user):\n        \"\"\"Cria resposta de boas-vindas\"\"\"\n        clinic = MultiTenantManager.get_current_clinic()\n        clinic_name = clinic.name if clinic else \"Clínica\"\n        \n        return {\n            'text': f\"🏥 Olá! Bem-vindo(a) ao {clinic_name}!\\n\\n\"\n                   f\"Sou seu assistente virtual e estou aqui para ajudar com:\\n\\n\"\n                   f\"📅 Agendamento de exames\\n\"\n                   f\"💰 Consulta de preços\\n\"\n                   f\"📋 Informações sobre procedimentos\\n\\n\"\n                   f\"Como posso ajudá-lo(a) hoje?\",\n            'buttons': [\n                {'text': '📅 Agendar Exame', 'callback_data': 'agendar_exame'},\n                {'text': '💰 Consultar Preços', 'callback_data': 'consultar_precos'}\n            ]\n        }\n    \n    def _create_menu_response(self):\n        \"\"\"Cria resposta do menu principal\"\"\"\n        return {\n            'text': \"🏠 Menu Principal\\n\\nEscolha uma das opções abaixo:\",\n            'buttons': [\n                {'text': '📅 Agendar Exame', 'callback_data': 'agendar_exame'},\n                {'text': '💰 Consultar Preços', 'callback_data': 'consultar_precos'}\n            ]\n        }\n    \n    def _create_error_response(self):\n        \"\"\"Cria resposta de erro\"\"\"\n        return {\n            'text': \"❌ Ops! Ocorreu um erro. Vamos tentar novamente?\\n\\n\"\n                   \"Use /start para voltar ao menu principal.\",\n            'buttons': [\n                {'text': '🏠 Menu Principal', 'callback_data': 'back_menu'}\n            ]\n        }\n    \n    def _create_help_response(self):\n        \"\"\"Cria resposta de ajuda\"\"\"\n        return {\n            'text': \"🆘 Central de Ajuda\\n\\n\"\n                   \"Comandos disponíveis:\\n\"\n                   \"• /start - Menu principal\\n\"\n                   \"• /help - Esta ajuda\\n\"\n                   \"• /status - Meus agendamentos\\n\\n\"\n                   \"Para agendar exames, use o botão abaixo:\",\n            'buttons': [\n                {'text': '📅 Agendar Exame', 'callback_data': 'agendar_exame'},\n                {'text': '🏠 Menu Principal', 'callback_data': 'back_menu'}\n            ]\n        }\n    \n    # Métodos de manipulação de estado (reutilizados do ChatbotHandler original)\n    def _handle_menu_selection(self, user, text):\n        \"\"\"Manipula seleção do menu principal\"\"\"\n        # Implementar lógica similar ao ChatbotHandler original\n        return self._create_menu_response()\n    \n    def _handle_schedule_exam(self, user):\n        \"\"\"Inicia processo de agendamento\"\"\"\n        # Implementar lógica de agendamento\n        return self._create_menu_response()\n    \n    def _handle_price_inquiry(self, user):\n        \"\"\"Manipula consulta de preços\"\"\"\n        # Implementar lógica de consulta de preços\n        return self._create_menu_response()\n    \n    # ... outros métodos de manipulação de estado ..."
