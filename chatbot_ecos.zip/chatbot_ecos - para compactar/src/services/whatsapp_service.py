import requests
import json
import base64
from datetime import datetime
from flask import current_app
from src.models.multi_tenant import db, User, Appointment, Clinic
from src.utils.multi_tenant import MultiTenantManager

class WhatsAppService:
    """Serviço para integração com WhatsApp via Evolution API"""
    
    def __init__(self, base_url=None, api_key=None, instance_name=None):
        """
        Inicializa o serviço WhatsApp
        
        Args:
            base_url: URL base da Evolution API
            api_key: Chave de API da Evolution API
            instance_name: Nome da instância WhatsApp
        """
        self.base_url = base_url or current_app.config.get('EVOLUTION_API_URL', 'http://localhost:8080')
        self.api_key = api_key or current_app.config.get('EVOLUTION_API_KEY', '')
        self.instance_name = instance_name or current_app.config.get('EVOLUTION_INSTANCE_NAME', 'chatbot')
        
        self.headers = {
            'Content-Type': 'application/json',
            'apikey': self.api_key
        }
    
    def create_instance(self, instance_name, webhook_url):
        """Cria uma nova instância WhatsApp"""
        try:
            url = f"{self.base_url}/instance/create"
            
            data = {
                "instanceName": instance_name,
                "token": self.api_key,
                "qrcode": True,
                "markMessagesRead": True,
                "delayMessage": 1000,
                "webhook": webhook_url,
                "webhook_by_events": True,
                "events": [
                    "APPLICATION_STARTUP",
                    "QRCODE_UPDATED",
                    "MESSAGES_UPSERT",
                    "MESSAGES_UPDATE",
                    "MESSAGES_DELETE",
                    "SEND_MESSAGE",
                    "CONTACTS_SET",
                    "CONTACTS_UPSERT",
                    "CONTACTS_UPDATE",
                    "PRESENCE_UPDATE",
                    "CHATS_SET",
                    "CHATS_UPSERT",
                    "CHATS_UPDATE",
                    "CHATS_DELETE",
                    "GROUPS_UPSERT",
                    "GROUP_UPDATE",
                    "GROUP_PARTICIPANTS_UPDATE",
                    "CONNECTION_UPDATE"
                ]
            }
            
            response = requests.post(url, json=data, headers=self.headers)
            
            if response.status_code == 201:
                return response.json()
            else:
                print(f"Erro ao criar instância: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao criar instância WhatsApp: {e}")
            return None
    
    def get_qr_code(self, instance_name):
        """Obtém QR Code para conectar WhatsApp"""
        try:
            url = f"{self.base_url}/instance/connect/{instance_name}"
            
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                data = response.json()
                return data.get('base64')
            else:
                print(f"Erro ao obter QR Code: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao obter QR Code: {e}")
            return None
    
    def get_instance_status(self, instance_name):
        """Verifica status da instância"""
        try:
            url = f"{self.base_url}/instance/connectionState/{instance_name}"
            
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao verificar status: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao verificar status da instância: {e}")
            return None
    
    def send_text_message(self, phone_number, message, instance_name=None):
        """Envia mensagem de texto"""
        try:
            instance = instance_name or self.instance_name
            url = f"{self.base_url}/message/sendText/{instance}"
            
            # Formata número de telefone
            if not phone_number.endswith('@s.whatsapp.net'):
                # Remove caracteres especiais e adiciona código do país se necessário
                clean_number = ''.join(filter(str.isdigit, phone_number))
                if len(clean_number) == 11 and clean_number.startswith('0'):
                    clean_number = '55' + clean_number[1:]  # Brasil
                elif len(clean_number) == 10:
                    clean_number = '55' + clean_number  # Brasil
                elif len(clean_number) == 11 and not clean_number.startswith('55'):
                    clean_number = '55' + clean_number  # Brasil
                
                phone_number = f"{clean_number}@s.whatsapp.net"
            
            data = {
                "number": phone_number,
                "options": {
                    "delay": 1200,
                    "presence": "composing"
                },
                "textMessage": {
                    "text": message
                }
            }
            
            response = requests.post(url, json=data, headers=self.headers)
            
            if response.status_code == 201:
                return response.json()
            else:
                print(f"Erro ao enviar mensagem: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar mensagem WhatsApp: {e}")
            return None
    
    def send_image_message(self, phone_number, image_url, caption=None, instance_name=None):
        """Envia mensagem com imagem"""
        try:
            instance = instance_name or self.instance_name
            url = f"{self.base_url}/message/sendMedia/{instance}"
            
            # Formata número de telefone
            if not phone_number.endswith('@s.whatsapp.net'):
                clean_number = ''.join(filter(str.isdigit, phone_number))
                if len(clean_number) == 11 and clean_number.startswith('0'):
                    clean_number = '55' + clean_number[1:]
                elif len(clean_number) == 10:
                    clean_number = '55' + clean_number
                elif len(clean_number) == 11 and not clean_number.startswith('55'):
                    clean_number = '55' + clean_number
                
                phone_number = f"{clean_number}@s.whatsapp.net"
            
            data = {
                "number": phone_number,
                "options": {
                    "delay": 1200,
                    "presence": "composing"
                },
                "mediaMessage": {
                    "mediatype": "image",
                    "media": image_url,
                    "caption": caption or ""
                }
            }
            
            response = requests.post(url, json=data, headers=self.headers)
            
            if response.status_code == 201:
                return response.json()
            else:
                print(f"Erro ao enviar imagem: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar imagem WhatsApp: {e}")
            return None
    
    def send_button_message(self, phone_number, text, buttons, instance_name=None):
        """Envia mensagem com botões"""
        try:
            instance = instance_name or self.instance_name
            url = f"{self.base_url}/message/sendButtons/{instance}"
            
            # Formata número de telefone
            if not phone_number.endswith('@s.whatsapp.net'):
                clean_number = ''.join(filter(str.isdigit, phone_number))
                if len(clean_number) == 11 and clean_number.startswith('0'):
                    clean_number = '55' + clean_number[1:]
                elif len(clean_number) == 10:
                    clean_number = '55' + clean_number
                elif len(clean_number) == 11 and not clean_number.startswith('55'):
                    clean_number = '55' + clean_number
                
                phone_number = f"{clean_number}@s.whatsapp.net"
            
            # Formata botões para Evolution API
            formatted_buttons = []
            for i, button in enumerate(buttons[:3]):  # WhatsApp permite máximo 3 botões
                formatted_buttons.append({
                    "buttonId": f"btn_{i}_{button.get('callback_data', str(i))}",
                    "buttonText": {
                        "displayText": button.get('text', f'Opção {i+1}')
                    },
                    "type": 1
                })
            
            data = {
                "number": phone_number,
                "options": {
                    "delay": 1200,
                    "presence": "composing"
                },
                "buttonMessage": {
                    "text": text,
                    "buttons": formatted_buttons,
                    "headerType": 1
                }
            }
            
            response = requests.post(url, json=data, headers=self.headers)
            
            if response.status_code == 201:
                return response.json()
            else:
                print(f"Erro ao enviar botões: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar botões WhatsApp: {e}")
            return None
    
    def send_list_message(self, phone_number, text, title, sections, instance_name=None):
        """Envia mensagem com lista de opções"""
        try:
            instance = instance_name or self.instance_name
            url = f"{self.base_url}/message/sendList/{instance}"
            
            # Formata número de telefone
            if not phone_number.endswith('@s.whatsapp.net'):
                clean_number = ''.join(filter(str.isdigit, phone_number))
                if len(clean_number) == 11 and clean_number.startswith('0'):
                    clean_number = '55' + clean_number[1:]
                elif len(clean_number) == 10:
                    clean_number = '55' + clean_number
                elif len(clean_number) == 11 and not clean_number.startswith('55'):
                    clean_number = '55' + clean_number
                
                phone_number = f"{clean_number}@s.whatsapp.net"
            
            data = {
                "number": phone_number,
                "options": {
                    "delay": 1200,
                    "presence": "composing"
                },
                "listMessage": {
                    "text": text,
                    "buttonText": "Ver opções",
                    "title": title,
                    "description": text,
                    "sections": sections
                }
            }
            
            response = requests.post(url, json=data, headers=self.headers)
            
            if response.status_code == 201:
                return response.json()
            else:
                print(f"Erro ao enviar lista: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao enviar lista WhatsApp: {e}")
            return None
    
    def download_media(self, message_id, instance_name=None):
        """Baixa mídia de uma mensagem"""
        try:
            instance = instance_name or self.instance_name
            url = f"{self.base_url}/chat/getBase64FromMediaMessage/{instance}"
            
            data = {
                "message": {
                    "key": {
                        "id": message_id
                    }
                },
                "convertToMp4": False
            }
            
            response = requests.post(url, json=data, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao baixar mídia: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao baixar mídia WhatsApp: {e}")
            return None
    
    def get_profile_picture(self, phone_number, instance_name=None):
        """Obtém foto de perfil do usuário"""
        try:
            instance = instance_name or self.instance_name
            url = f"{self.base_url}/chat/whatsappProfile/{instance}"
            
            # Formata número de telefone
            if not phone_number.endswith('@s.whatsapp.net'):
                clean_number = ''.join(filter(str.isdigit, phone_number))
                phone_number = f"{clean_number}@s.whatsapp.net"
            
            data = {
                "number": phone_number
            }
            
            response = requests.post(url, json=data, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Erro ao obter foto de perfil: {response.text}")
                return None
                
        except Exception as e:
            print(f"Erro ao obter foto de perfil: {e}")
            return None
    
    def process_webhook_message(self, webhook_data):
        """Processa mensagem recebida via webhook"""
        try:
            event = webhook_data.get('event')
            instance = webhook_data.get('instance')
            data = webhook_data.get('data', {})
            
            if event == 'messages.upsert':
                message = data.get('message', {})
                key = message.get('key', {})
                
                # Ignora mensagens enviadas pelo bot
                if key.get('fromMe'):
                    return None
                
                # Extrai informações da mensagem
                phone_number = key.get('remoteJid', '').replace('@s.whatsapp.net', '')
                message_id = key.get('id')
                
                # Extrai conteúdo da mensagem
                message_content = message.get('message', {})
                text_message = None
                media_message = None
                button_response = None
                list_response = None
                
                if 'conversation' in message_content:
                    text_message = message_content['conversation']
                elif 'extendedTextMessage' in message_content:
                    text_message = message_content['extendedTextMessage'].get('text')
                elif 'imageMessage' in message_content:
                    media_message = {
                        'type': 'image',
                        'caption': message_content['imageMessage'].get('caption'),
                        'mimetype': message_content['imageMessage'].get('mimetype'),
                        'url': message_content['imageMessage'].get('url')
                    }
                elif 'documentMessage' in message_content:
                    media_message = {
                        'type': 'document',
                        'filename': message_content['documentMessage'].get('fileName'),
                        'mimetype': message_content['documentMessage'].get('mimetype'),
                        'url': message_content['documentMessage'].get('url')
                    }
                elif 'buttonsResponseMessage' in message_content:
                    button_response = message_content['buttonsResponseMessage'].get('selectedButtonId')
                elif 'listResponseMessage' in message_content:
                    list_response = message_content['listResponseMessage'].get('singleSelectReply', {}).get('selectedRowId')
                
                return {
                    'platform': 'whatsapp',
                    'instance': instance,
                    'phone_number': phone_number,
                    'message_id': message_id,
                    'text': text_message,
                    'media': media_message,
                    'button_response': button_response,
                    'list_response': list_response,
                    'timestamp': datetime.utcnow(),
                    'raw_data': webhook_data
                }
            
            return None
            
        except Exception as e:
            print(f"Erro ao processar webhook WhatsApp: {e}")
            return None
    
    def format_phone_number(self, phone_number):
        """Formata número de telefone para WhatsApp"""
        try:
            # Remove caracteres especiais
            clean_number = ''.join(filter(str.isdigit, phone_number))
            
            # Adiciona código do país se necessário (Brasil)
            if len(clean_number) == 11 and clean_number.startswith('0'):
                clean_number = '55' + clean_number[1:]
            elif len(clean_number) == 10:
                clean_number = '55' + clean_number
            elif len(clean_number) == 11 and not clean_number.startswith('55'):
                clean_number = '55' + clean_number
            
            return clean_number
            
        except Exception as e:
            print(f"Erro ao formatar número: {e}")
            return phone_number
    
    def validate_phone_number(self, phone_number, instance_name=None):
        """Valida se número existe no WhatsApp"""
        try:
            instance = instance_name or self.instance_name
            url = f"{self.base_url}/chat/whatsappNumbers/{instance}"
            
            formatted_number = self.format_phone_number(phone_number)
            
            data = {
                "numbers": [formatted_number]
            }
            
            response = requests.post(url, json=data, headers=self.headers)
            
            if response.status_code == 200:
                result = response.json()
                return len(result) > 0 and result[0].get('exists', False)
            else:
                print(f"Erro ao validar número: {response.text}")
                return False
                
        except Exception as e:
            print(f"Erro ao validar número WhatsApp: {e}")
            return False
    
    @staticmethod
    def get_clinic_whatsapp_service(clinic_slug=None):
        """Obtém serviço WhatsApp configurado para uma clínica específica"""
        try:
            if clinic_slug:
                clinic = Clinic.query.filter_by(slug=clinic_slug, active=True).first()
            else:
                clinic = MultiTenantManager.get_current_clinic()
            
            if not clinic:
                return None
            
            # Configurações específicas da clínica
            base_url = clinic.whatsapp_api_url or current_app.config.get('EVOLUTION_API_URL')
            api_key = clinic.whatsapp_token or current_app.config.get('EVOLUTION_API_KEY')
            instance_name = f"{clinic.slug}_whatsapp"
            
            if not base_url or not api_key:
                return None
            
            return WhatsAppService(
                base_url=base_url,
                api_key=api_key,
                instance_name=instance_name
            )
            
        except Exception as e:
            print(f"Erro ao obter serviço WhatsApp da clínica: {e}")
            return None
