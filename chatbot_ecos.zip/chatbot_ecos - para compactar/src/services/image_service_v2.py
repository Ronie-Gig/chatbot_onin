import os
import requests
from datetime import datetime
from flask import current_app, url_for
from src.models.multi_tenant import db, User, Appointment
from src.utils.multi_tenant import MultiTenantManager
from src.services.notification_service import NotificationService

class ImageService:
    """Serviço para manipulação de imagens dos pedidos médicos com notificações"""
    
    @staticmethod
    def get_telegram_file_url(file_id, bot_token):
        """Obtém URL do arquivo no Telegram"""
        try:
            # Busca informações do arquivo
            file_info_url = f"https://api.telegram.org/bot{bot_token}/getFile"
            response = requests.get(file_info_url, params={'file_id': file_id})
            
            if response.status_code == 200:
                file_data = response.json()
                if file_data.get('ok'):
                    file_path = file_data['result']['file_path']
                    file_url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
                    return file_url
            
            return None
            
        except Exception as e:
            print(f"Erro ao obter URL do arquivo Telegram: {e}")
            return None
    
    @staticmethod
    def download_telegram_image(file_id, bot_token, save_path=None):
        """Baixa imagem do Telegram"""
        try:
            file_url = ImageService.get_telegram_file_url(file_id, bot_token)
            if not file_url:
                return None
            
            # Baixa a imagem
            response = requests.get(file_url)
            if response.status_code == 200:
                if save_path:
                    # Salva no disco
                    os.makedirs(os.path.dirname(save_path), exist_ok=True)
                    with open(save_path, 'wb') as f:
                        f.write(response.content)
                    return save_path
                else:
                    # Retorna conteúdo em bytes
                    return response.content
            
            return None
            
        except Exception as e:
            print(f"Erro ao baixar imagem do Telegram: {e}")
            return None
    
    @staticmethod
    def get_image_proxy_url(file_id, platform='telegram'):
        """Gera URL proxy para visualizar imagem sem baixar"""
        clinic = MultiTenantManager.get_current_clinic()
        if not clinic:
            return None
        
        return url_for('dashboard.view_image', 
                      file_id=file_id, 
                      platform=platform,
                      clinic_slug=clinic.slug)
    
    @staticmethod
    def serve_telegram_image(file_id, bot_token):
        """Serve imagem do Telegram via proxy"""
        try:
            file_url = ImageService.get_telegram_file_url(file_id, bot_token)
            if not file_url:
                return None, None
            
            # Baixa a imagem
            response = requests.get(file_url)
            if response.status_code == 200:
                # Determina tipo de conteúdo
                content_type = response.headers.get('content-type', 'image/jpeg')
                return response.content, content_type
            
            return None, None
            
        except Exception as e:
            print(f"Erro ao servir imagem do Telegram: {e}")
            return None, None
    
    @staticmethod
    def get_appointment_images(appointment_id):
        """Obtém todas as imagens de um agendamento"""
        try:
            appointment = Appointment.query.get(appointment_id)
            if not appointment:
                return []
            
            images = []
            
            # Imagem principal do agendamento
            if appointment.photo_file_id:
                clinic = appointment.clinic
                image_url = ImageService.get_image_proxy_url(
                    appointment.photo_file_id, 
                    'telegram'
                )
                
                images.append({
                    'file_id': appointment.photo_file_id,
                    'url': image_url,
                    'type': 'main',
                    'description': 'Pedido médico principal',
                    'approved': appointment.user.photo_approved if appointment.user else False
                })
            
            # Imagens do usuário (se diferentes)
            if appointment.user and appointment.user.photo_file_id:
                if appointment.user.photo_file_id != appointment.photo_file_id:
                    image_url = ImageService.get_image_proxy_url(
                        appointment.user.photo_file_id,
                        'telegram'
                    )
                    
                    images.append({
                        'file_id': appointment.user.photo_file_id,
                        'url': image_url,
                        'type': 'user',
                        'description': 'Foto do usuário',
                        'approved': appointment.user.photo_approved
                    })
            
            return images
            
        except Exception as e:
            print(f"Erro ao obter imagens do agendamento: {e}")
            return []
    
    @staticmethod
    def approve_image(file_id, approved_by):
        """Aprova uma imagem e envia notificações"""
        try:
            # Busca usuário pela foto
            user = User.query.filter_by(photo_file_id=file_id).first()
            if not user:
                return False
            
            # Salva telegram_id antes de atualizar
            telegram_id = user.telegram_id
            
            # Atualiza status da foto
            user.photo_approved = True
            
            # Atualiza agendamentos relacionados
            appointments = Appointment.query.filter_by(
                user_id=user.id,
                photo_file_id=file_id
            ).all()
            
            confirmed_appointments = []
            for appointment in appointments:
                if appointment.status == 'PENDING':
                    appointment.status = 'CONFIRMED'
                    appointment.confirmed_at = datetime.utcnow()
                    confirmed_appointments.append(appointment)
            
            # Log da aprovação
            from src.models.multi_tenant import ChatLog
            log = ChatLog(
                clinic_id=user.clinic_id,
                user_id=user.id,
                platform='SYSTEM',
                message_type='APPROVAL',
                message_content=f'{{"action": "approve", "file_id": "{file_id}", "approved_by": "{approved_by}"}}',
                state_at_time=user.current_state,
                response_sent=f'Imagem aprovada por {approved_by}'
            )
            
            db.session.add(log)
            db.session.commit()
            
            # Envia notificação ao usuário
            if telegram_id:
                NotificationService.notify_image_approved(
                    telegram_id, 
                    file_id, 
                    approved_by
                )
            
            # Notifica confirmação dos agendamentos
            for appointment in confirmed_appointments:
                NotificationService.notify_appointment_confirmed(appointment.id)
            
            return True
            
        except Exception as e:
            print(f"Erro ao aprovar imagem: {e}")
            db.session.rollback()
            return False
    
    @staticmethod
    def reject_image(file_id, rejected_by, reason=None):
        """Rejeita uma imagem e envia notificações"""
        try:
            # Busca usuário pela foto
            user = User.query.filter_by(photo_file_id=file_id).first()
            if not user:
                return False
            
            # Salva telegram_id antes de atualizar
            telegram_id = user.telegram_id
            
            # Atualiza status da foto
            user.photo_approved = False
            
            # Atualiza agendamentos relacionados
            appointments = Appointment.query.filter_by(
                user_id=user.id,
                photo_file_id=file_id
            ).all()
            
            cancelled_appointments = []
            for appointment in appointments:
                if appointment.status in ['PENDING', 'CONFIRMED']:
                    appointment.status = 'CANCELLED'
                    cancelled_appointments.append(appointment)
            
            # Log da rejeição
            from src.models.multi_tenant import ChatLog
            reason_text = reason or 'Não especificado'
            log = ChatLog(
                clinic_id=user.clinic_id,
                user_id=user.id,
                platform='SYSTEM',
                message_type='REJECTION',
                message_content=f'{{"action": "reject", "file_id": "{file_id}", "rejected_by": "{rejected_by}", "reason": "{reason_text}"}}',
                state_at_time=user.current_state,
                response_sent=f'Imagem rejeitada por {rejected_by}: {reason or "Motivo não especificado"}'
            )
            
            db.session.add(log)
            db.session.commit()
            
            # Envia notificação ao usuário
            if telegram_id:
                NotificationService.notify_image_rejected(
                    telegram_id, 
                    file_id, 
                    rejected_by, 
                    reason
                )
            
            # Notifica cancelamento dos agendamentos
            for appointment in cancelled_appointments:
                NotificationService.notify_appointment_cancelled(
                    appointment.id, 
                    f"Imagem rejeitada: {reason or 'Motivo não especificado'}"
                )
            
            return True
            
        except Exception as e:
            print(f"Erro ao rejeitar imagem: {e}")
            db.session.rollback()
            return False
    
    @staticmethod
    def get_pending_images():
        """Obtém todas as imagens pendentes de aprovação"""
        try:
            clinic = MultiTenantManager.get_current_clinic()
            if not clinic:
                return []
            
            # Busca usuários com fotos não aprovadas
            users_with_photos = User.query.filter(
                User.clinic_id == clinic.id,
                User.photo_file_id.isnot(None),
                User.photo_approved == False
            ).all()
            
            pending_images = []
            
            for user in users_with_photos:
                # Busca agendamentos relacionados
                appointments = Appointment.query.filter_by(
                    user_id=user.id,
                    status='PENDING'
                ).all()
                
                if appointments:
                    image_url = ImageService.get_image_proxy_url(
                        user.photo_file_id,
                        'telegram'
                    )
                    
                    pending_images.append({
                        'file_id': user.photo_file_id,
                        'url': image_url,
                        'user': {
                            'id': user.id,
                            'name': user.name or 'Nome não informado',
                            'cpf': user.cpf or 'CPF não informado',
                            'telegram_id': user.telegram_id
                        },
                        'appointments': [{
                            'id': apt.id,
                            'exams': apt.get_exams(),
                            'total_price': apt.total_price,
                            'covenant_type': apt.covenant_type,
                            'created_at': apt.created_at.strftime('%d/%m/%Y %H:%M')
                        } for apt in appointments],
                        'created_at': user.created_at.strftime('%d/%m/%Y %H:%M')
                    })
            
            return pending_images
            
        except Exception as e:
            print(f"Erro ao obter imagens pendentes: {e}")
            return []
    
    @staticmethod
    def get_image_stats():
        """Obtém estatísticas das imagens"""
        try:
            clinic = MultiTenantManager.get_current_clinic()
            if not clinic:
                return {}
            
            # Conta imagens por status
            total_images = User.query.filter(
                User.clinic_id == clinic.id,
                User.photo_file_id.isnot(None)
            ).count()
            
            approved_images = User.query.filter(
                User.clinic_id == clinic.id,
                User.photo_file_id.isnot(None),
                User.photo_approved == True
            ).count()
            
            pending_images = User.query.filter(
                User.clinic_id == clinic.id,
                User.photo_file_id.isnot(None),
                User.photo_approved == False
            ).count()
            
            return {
                'total': total_images,
                'approved': approved_images,
                'pending': pending_images,
                'approval_rate': round((approved_images / total_images * 100) if total_images > 0 else 0, 1)
            }
            
        except Exception as e:
            print(f"Erro ao obter estatísticas de imagens: {e}")
            return {
                'total': 0,
                'approved': 0,
                'pending': 0,
                'approval_rate': 0
            }
    
    @staticmethod
    def process_new_image(user_id, file_id, platform='telegram'):
        """Processa nova imagem recebida"""
        try:
            # Busca usuário
            user = User.query.filter_by(telegram_id=str(user_id)).first()
            if not user:
                return False
            
            # Atualiza foto do usuário
            user.photo_file_id = file_id
            user.photo_approved = False  # Pendente de aprovação
            
            db.session.commit()
            
            # Notifica administradores sobre nova imagem pendente
            NotificationService.notify_image_pending_approval(user_id, file_id)
            
            return True
            
        except Exception as e:
            print(f"Erro ao processar nova imagem: {e}")
            db.session.rollback()
            return False
    
    @staticmethod
    def bulk_approve_images(file_ids, approved_by):
        """Aprova múltiplas imagens em lote"""
        try:
            approved_count = 0
            
            for file_id in file_ids:
                if ImageService.approve_image(file_id, approved_by):
                    approved_count += 1
            
            return approved_count
            
        except Exception as e:
            print(f"Erro na aprovação em lote: {e}")
            return 0
    
    @staticmethod
    def bulk_reject_images(file_ids, rejected_by, reason=None):
        """Rejeita múltiplas imagens em lote"""
        try:
            rejected_count = 0
            
            for file_id in file_ids:
                if ImageService.reject_image(file_id, rejected_by, reason):
                    rejected_count += 1
            
            return rejected_count
            
        except Exception as e:
            print(f"Erro na rejeição em lote: {e}")
            return 0
