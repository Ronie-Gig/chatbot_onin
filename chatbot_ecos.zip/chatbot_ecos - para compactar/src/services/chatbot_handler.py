import json
import re
import os
from datetime import datetime
from src.models.chatbot import db, User, Exam, Appointment, ClinicInfo, SystemConfig
from src.services.telegram_service import TelegramService
from src.utils.validators import validate_cpf, format_cpf
from src.services.email_service import EmailService

class ChatbotHandler:
    def __init__(self):
        self.telegram = TelegramService()
        self.email = EmailService()
    
    def process_message(self, platform, user_data, message_data):
        """Processa mensagem recebida de qualquer plataforma"""
        try:
            # Identifica ou cria usuário
            user = self._get_or_create_user(platform, user_data)
            
            # Atualiza última interação
            user.last_interaction = datetime.utcnow()
            
            # Processa baseado no tipo de mensagem
            if message_data.get('type') == 'text':
                response = self._process_text_message(user, message_data['text'])
            elif message_data.get('type') == 'photo':
                response = self._process_photo_message(user, message_data)
            elif message_data.get('type') == 'callback':
                response = self._process_callback_message(user, message_data['data'])
            else:
                response = self._get_default_response()
            
            # Salva no banco
            db.session.commit()
            
            return {'status': 'success', 'response': response}
            
        except Exception as e:
            db.session.rollback()
            print(f"Erro ao processar mensagem: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def _get_or_create_user(self, platform, user_data):
        """Obtém usuário existente ou cria novo"""
        user = None
        
        if platform == 'TELEGRAM':
            user = User.query.filter_by(telegram_id=str(user_data['id'])).first()
            if not user:
                user = User(
                    telegram_id=str(user_data['id']),
                    current_state='START',
                    session_start=datetime.utcnow()
                )
                db.session.add(user)
        elif platform == 'WHATSAPP':
            user = User.query.filter_by(whatsapp_id=str(user_data['id'])).first()
            if not user:
                user = User(
                    whatsapp_id=str(user_data['id']),
                    current_state='START',
                    session_start=datetime.utcnow()
                )
                db.session.add(user)
        elif platform == 'FACEBOOK':
            user = User.query.filter_by(facebook_id=str(user_data['id'])).first()
            if not user:
                user = User(
                    facebook_id=str(user_data['id']),
                    current_state='START',
                    session_start=datetime.utcnow()
                )
                db.session.add(user)
        
        # Verifica se a sessão expirou (mais de 24 horas)
        if user and user.last_interaction:
            time_diff = datetime.utcnow() - user.last_interaction
            if time_diff.total_seconds() > 86400:  # 24 horas
                # Reset da sessão
                user.current_state = 'START'
                user.clear_exams()
                user.session_start = datetime.utcnow()
        
        return user
    
    def _process_text_message(self, user, text):
        """Processa mensagens de texto baseado no estado atual"""
        text = text.strip()
        
        # Comandos especiais
        if text.lower() in ['/start', 'iniciar', 'começar']:
            return self._handle_start(user)
        elif text.lower() in ['/menu', 'menu', 'voltar']:
            return self._handle_main_menu(user)
        
        # Processa baseado no estado atual
        if user.current_state == 'START':
            return self._handle_start(user)
        elif user.current_state == 'MAIN_MENU':
            return self._handle_main_menu_selection(user, text)
        elif user.current_state == 'COVENANT_SELECTION':
            return self._handle_covenant_selection(user, text)
        elif user.current_state == 'EXAM_SELECTION':
            return self._handle_exam_selection(user, text)
        elif user.current_state == 'PERSONAL_DATA':
            return self._handle_personal_data(user, text)
        elif user.current_state == 'CPF_INPUT':
            return self._handle_cpf_input(user, text)
        elif user.current_state == 'BIRTH_DATE_INPUT':
            return self._handle_birth_date_input(user, text)
        elif user.current_state == 'PHOTO_UPLOAD':
            return self._handle_photo_request(user)
        elif user.current_state == 'PHOTO_CONFIRMATION':
            return self._handle_photo_confirmation(user, text)
        elif user.current_state == 'SATISFACTION':
            return self._handle_satisfaction(user, text)
        else:
            return self._handle_main_menu(user)
    
    def _handle_start(self, user):
        """Manipula comando /start"""
        user.current_state = 'MAIN_MENU'
        
        # Busca mensagem de boas-vindas personalizada
        welcome_config = SystemConfig.query.filter_by(key='WELCOME_MESSAGE').first()
        if welcome_config:
            welcome_text = welcome_config.value
        else:
            welcome_text = "🏥 Olá! Bem-vindo à ECOS - Radiologia e Diagnóstico!\n\nSou seu assistente virtual e estou aqui para ajudar com:\n• 📅 Agendamento de exames\n• 💰 Orçamentos personalizados\n• 📍 Informações da clínica\n• 👨‍⚕️ Falar com atendente\n\nComo posso ajudar você hoje?"
        
        keyboard = [
            [{'text': '📅 Agendar Exames', 'callback_data': 'schedule'}],
            [{'text': '💰 Solicitar Orçamento', 'callback_data': 'budget'}],
            [{'text': '📍 Informações da Clínica', 'callback_data': 'info'}],
            [{'text': '👨‍⚕️ Falar com Atendente', 'callback_data': 'attendant'}]
        ]
        
        return {
            'text': welcome_text,
            'keyboard': keyboard
        }
    
    def _handle_main_menu(self, user):
        """Exibe menu principal"""
        user.current_state = 'MAIN_MENU'
        
        keyboard = [
            [{'text': '📅 Agendar Exames', 'callback_data': 'schedule'}],
            [{'text': '💰 Solicitar Orçamento', 'callback_data': 'budget'}],
            [{'text': '📍 Informações da Clínica', 'callback_data': 'info'}],
            [{'text': '👨‍⚕️ Falar com Atendente', 'callback_data': 'attendant'}]
        ]
        
        return {
            'text': "🏥 **Menu Principal**\n\nEscolha uma das opções abaixo:",
            'keyboard': keyboard
        }
    
    def _handle_main_menu_selection(self, user, text):
        """Processa seleção do menu principal"""
        text_lower = text.lower()
        if 'agendar' in text_lower or 'agendamento' in text_lower:
            return self._process_callback_message(user, 'schedule')
        elif 'orçamento' in text_lower or 'orcamento' in text_lower:
            return self._process_callback_message(user, 'budget')
        elif 'informações' in text_lower or 'informacoes' in text_lower or 'clínica' in text_lower:
            return self._process_callback_message(user, 'info')
        elif 'atendente' in text_lower or 'falar' in text_lower:
            return self._process_callback_message(user, 'attendant')
        else:
            return self._handle_main_menu(user)
    
    def _process_callback_message(self, user, callback_data):
        """Processa callbacks de botões"""
        if callback_data == 'schedule':
            return self._start_scheduling(user)
        elif callback_data == 'budget':
            return self._start_budget(user)
        elif callback_data == 'info':
            return self._show_clinic_info(user)
        elif callback_data == 'attendant':
            return self._transfer_to_attendant(user)
        elif callback_data.startswith('covenant_'):
            covenant = callback_data.replace('covenant_', '')
            return self._handle_covenant_selection(user, covenant)
        elif callback_data.startswith('category_'):
            category = callback_data.replace('category_', '')
            return self._show_exams_by_category(user, category)
        elif callback_data.startswith('exam_'):
            exam_id = callback_data.replace('exam_', '')
            return self._handle_exam_selection_by_id(user, exam_id)
        elif callback_data == 'finish_selection':
            return self._finish_exam_selection(user)
        elif callback_data == 'continue_data':
            return self._request_personal_data(user)
        elif callback_data == 'photo_ok':
            return self._handle_photo_confirmation(user, 'sim')
        elif callback_data == 'photo_retry':
            return self._handle_photo_confirmation(user, 'não')
        elif callback_data == 'back_categories':
            return self._show_exam_categories(user)
        elif callback_data == 'menu':
            user.current_state = 'START'
            return self._handle_main_menu(user)
        else:
            return self._handle_main_menu(user)
    
    def _start_scheduling(self, user):
        """Inicia processo de agendamento"""
        user.current_state = 'COVENANT_SELECTION'
        user.clear_exams()  # Limpa seleções anteriores
        
        keyboard = [
            [{'text': '🏥 Particular', 'callback_data': 'covenant_particular'}],
            [{'text': '⚰️ Funerária', 'callback_data': 'covenant_funeraria'}],
            [{'text': '🏥 Unimed', 'callback_data': 'covenant_unimed'}],
            [{'text': '🔙 Voltar ao Menu', 'callback_data': 'menu'}]
        ]
        
        return {
            'text': "💳 **Tipo de Convênio**\n\nPor favor, selecione seu tipo de convênio:",
            'keyboard': keyboard
        }
    
    def _start_budget(self, user):
        """Inicia processo de orçamento"""
        user.current_state = 'COVENANT_SELECTION'
        user.clear_exams()
        
        keyboard = [
            [{'text': '🏥 Particular', 'callback_data': 'covenant_particular'}],
            [{'text': '⚰️ Funerária', 'callback_data': 'covenant_funeraria'}],
            [{'text': '🔙 Voltar ao Menu', 'callback_data': 'menu'}]
        ]
        
        return {
            'text': "💰 **Orçamento de Exames**\n\nPara qual tipo de convênio você gostaria do orçamento?\n\n*Nota: Exames Unimed são cobertos pelo plano, não necessitam orçamento.*",
            'keyboard': keyboard
        }
    
    def _handle_covenant_selection(self, user, covenant):
        """Processa seleção de convênio"""
        covenant_upper = covenant.upper()
        if covenant_upper in ['PARTICULAR', 'FUNERARIA', 'UNIMED']:
            user.covenant_type = covenant_upper
            user.current_state = 'EXAM_SELECTION'
            
            return self._show_exam_categories(user)
        else:
            return {
                'text': "❌ Opção inválida. Por favor, selecione um convênio válido.",
                'keyboard': []
            }
    
    def _show_exam_categories(self, user):
        """Mostra categorias de exames disponíveis"""
        categories = db.session.query(Exam.category).filter_by(active=True).distinct().all()
        categories = [cat[0] for cat in categories]
        
        keyboard = []
        for category in categories:
            keyboard.append([{'text': f"📋 {category}", 'callback_data': f'category_{category}'}])
        
        keyboard.append([{'text': '✅ Finalizar Seleção', 'callback_data': 'finish_selection'}])
        keyboard.append([{'text': '🔙 Voltar ao Menu', 'callback_data': 'menu'}])
        
        selected_exams = user.get_selected_exams()
        selected_text = ""
        if selected_exams:
            selected_text = f"\n\n**Exames selecionados:** {len(selected_exams)}"
        
        return {
            'text': f"🔬 **Seleção de Exames**\n\nEscolha a categoria do exame que deseja:{selected_text}",
            'keyboard': keyboard
        }
    
    def _show_exams_by_category(self, user, category):
        """Mostra exames de uma categoria específica"""
        exams = Exam.query.filter_by(category=category, active=True).all()
        
        keyboard = []
        for exam in exams:
            price = exam.get_price(user.covenant_type)
            if user.covenant_type == 'UNIMED':
                price_text = "Coberto pelo plano"
            else:
                price_text = f"R$ {price:.2f}"
            
            keyboard.append([{
                'text': f"{exam.exam_name} - {price_text}",
                'callback_data': f'exam_{exam.exam_id}'
            }])
        
        keyboard.append([{'text': '🔙 Voltar às Categorias', 'callback_data': 'back_categories'}])
        
        return {
            'text': f"🔬 **{category}**\n\nSelecione o exame desejado:",
            'keyboard': keyboard
        }
    
    def _handle_exam_selection_by_id(self, user, exam_id):
        """Processa seleção de exame por ID"""
        exam = Exam.query.filter_by(exam_id=exam_id, active=True).first()
        
        if not exam:
            return {
                'text': "❌ Exame não encontrado.",
                'keyboard': []
            }
        
        # Verifica se já foi selecionado
        selected_exams = user.get_selected_exams()
        for selected in selected_exams:
            if selected['exam_id'] == exam_id:
                return {
                    'text': f"⚠️ O exame **{exam.exam_name}** já foi selecionado.",
                    'keyboard': []
                }
        
        # Adiciona exame
        price = exam.get_price(user.covenant_type)
        exam_data = {
            'exam_id': exam.exam_id,
            'exam_name': exam.exam_name,
            'category': exam.category,
            'price': price,
            'preparation_required': exam.preparation_required,
            'preparation_instructions': exam.preparation_instructions
        }
        
        user.add_exam(exam_data)
        user.total_price += price
        
        if user.covenant_type == 'UNIMED':
            price_text = "Coberto pelo plano"
        else:
            price_text = f"R$ {price:.2f}"
        
        return {
            'text': f"✅ **{exam.exam_name}** adicionado!\n\nValor: {price_text}\n\nDeseja adicionar mais exames?",
            'keyboard': [
                [{'text': '➕ Adicionar Mais Exames', 'callback_data': 'back_categories'}],
                [{'text': '✅ Finalizar Seleção', 'callback_data': 'finish_selection'}]
            ]
        }
    
    def _finish_exam_selection(self, user):
        """Finaliza seleção de exames"""
        selected_exams = user.get_selected_exams()
        
        if not selected_exams:
            return {
                'text': "❌ Nenhum exame foi selecionado. Por favor, selecione pelo menos um exame.",
                'keyboard': []
            }
        
        # Monta resumo
        exam_list = "\n".join([f"• {exam['exam_name']}" for exam in selected_exams])
        
        if user.covenant_type == 'UNIMED':
            total_text = "Exames cobertos pelo seu plano Unimed"
        else:
            total_text = f"**Total:** R$ {user.total_price:.2f}"
        
        summary_text = f"""
📋 **Resumo da Seleção**

**Exames selecionados:**
{exam_list}

**Convênio:** {user.covenant_type}
{total_text}

Para continuar, precisamos de alguns dados pessoais.
"""
        
        keyboard = [
            [{'text': '✅ Continuar', 'callback_data': 'continue_data'}],
            [{'text': '🔙 Voltar ao Menu', 'callback_data': 'menu'}]
        ]
        
        return {
            'text': summary_text,
            'keyboard': keyboard
        }
    
    def _request_personal_data(self, user):
        """Solicita dados pessoais"""
        user.current_state = 'PERSONAL_DATA'
        
        return {
            'text': "👤 **Dados Pessoais**\n\nPor favor, digite seu nome completo:",
            'keyboard': []
        }
    
    def _handle_personal_data(self, user, name):
        """Processa nome do usuário"""
        user.name = name.strip()
        user.current_state = 'CPF_INPUT'
        
        return {
            'text': "📄 **CPF**\n\nPor favor, digite seu CPF (apenas números ou com pontuação):",
            'keyboard': []
        }
    
    def _handle_cpf_input(self, user, cpf_text):
        """Processa entrada de CPF"""
        cpf_clean = re.sub(r'[^0-9]', '', cpf_text)
        
        if validate_cpf(cpf_clean):
            user.cpf = format_cpf(cpf_clean)
            user.current_state = 'BIRTH_DATE_INPUT'
            
            return {
                'text': "📅 **Data de Nascimento**\n\nPor favor, digite sua data de nascimento no formato DD/MM/AAAA:",
                'keyboard': []
            }
        else:
            return {
                'text': "❌ CPF inválido. Por favor, digite um CPF válido (apenas números ou com pontuação):",
                'keyboard': []
            }
    
    def _handle_birth_date_input(self, user, date_text):
        """Processa entrada de data de nascimento"""
        # Validação simples de data
        date_pattern = r'^\d{2}/\d{2}/\d{4}$'
        if re.match(date_pattern, date_text):
            try:
                # Tenta converter para validar
                day, month, year = date_text.split('/')
                datetime(int(year), int(month), int(day))
                
                user.birth_date = date_text
                user.current_state = 'PHOTO_UPLOAD'
                
                return self._request_medical_prescription_photo(user)
            except ValueError:
                pass
        
        return {
            'text': "❌ Data inválida. Por favor, digite a data no formato DD/MM/AAAA (ex: 15/03/1990):",
            'keyboard': []
        }
    
    def _request_medical_prescription_photo(self, user):
        """Solicita foto do pedido médico"""
        instructions = """
📸 **Por favor, envie uma foto do seu pedido médico.**

⚠️ **Importante:**
• Certifique-se de que a foto está nítida
• Todos os dados devem estar legíveis
• Evite reflexos ou sombras

Após enviar, você poderá confirmar se a imagem está adequada.
"""
        
        return {
            'text': instructions,
            'keyboard': []
        }
    
    def _handle_photo_request(self, user):
        """Resposta quando usuário envia texto mas esperamos foto"""
        return {
            'text': "📸 Por favor, envie a **foto** do seu pedido médico. Use o botão de anexar foto do seu aplicativo.",
            'keyboard': []
        }
    
    def _process_photo_message(self, user, photo_data):
        """Processa foto enviada"""
        if user.current_state == 'PHOTO_UPLOAD':
            user.photo_file_id = photo_data.get('file_id', 'photo_received')
            user.current_state = 'PHOTO_CONFIRMATION'
            
            keyboard = [
                [{'text': '✅ Foto está nítida', 'callback_data': 'photo_ok'}],
                [{'text': '🔄 Enviar outra foto', 'callback_data': 'photo_retry'}]
            ]
            
            return {
                'text': "📸 **Foto recebida!**\n\nA imagem do pedido médico está nítida e legível?",
                'keyboard': keyboard
            }
        else:
            return {
                'text': "❌ Não esperava uma foto neste momento. Use /menu para voltar ao menu principal.",
                'keyboard': []
            }
    
    def _handle_photo_confirmation(self, user, confirmation):
        """Processa confirmação da foto"""
        if confirmation.lower() in ['sim', 'ok', 'yes', 'photo_ok']:
            user.photo_approved = True
            return self._finalize_appointment(user)
        else:
            user.current_state = 'PHOTO_UPLOAD'
            return self._request_medical_prescription_photo(user)
    
    def _finalize_appointment(self, user):
        """Finaliza agendamento/orçamento"""
        try:
            # Cria appointment
            selected_exams = user.get_selected_exams()
            
            appointment = Appointment(
                user_id=user.id,
                exams=json.dumps(selected_exams),
                total_price=user.total_price,
                covenant_type=user.covenant_type,
                photo_file_id=user.photo_file_id,
                status='PENDING'
            )
            
            # Prepara instruções de preparo
            preparation_instructions = []
            for exam_data in selected_exams:
                if exam_data.get('preparation_instructions'):
                    prep_text = f"• **{exam_data['exam_name']}:** {exam_data['preparation_instructions']}"
                    if prep_text not in preparation_instructions:
                        preparation_instructions.append(prep_text)
            
            if preparation_instructions:
                appointment.preparation_instructions = "\n".join(preparation_instructions)
            
            db.session.add(appointment)
            
            # Envia email de notificação
            self._send_appointment_notification(user, appointment)
            
            # Resposta para o usuário
            if user.covenant_type == 'UNIMED':
                price_text = "Exames cobertos pelo seu plano Unimed"
            else:
                price_text = f"**Valor total:** R$ {user.total_price:.2f}"
            
            response_text = f"""
✅ **Solicitação enviada com sucesso!**

📋 **Resumo:**
• **Exames:** {len(selected_exams)} selecionado(s)
• **Convênio:** {user.covenant_type}
• {price_text}

📞 **Próximos passos:**
Nossa equipe entrará em contato em breve para confirmar os horários disponíveis.

⏰ **Horário de contato:**
Segunda a Sexta: 7h às 18h | Sábado: 7h às 12h

📱 **Contato direto:** (14) 98171-3057 (apenas mensagens)
"""
            
            if preparation_instructions:
                response_text += f"\n\n🔬 **Instruções de preparo:**\n{appointment.preparation_instructions}"
            
            # Reset user state
            user.current_state = 'SATISFACTION'
            
            keyboard = [
                [{'text': '⭐ Avaliar Atendimento', 'callback_data': 'satisfaction'}],
                [{'text': '🔙 Voltar ao Menu', 'callback_data': 'menu'}]
            ]
            
            return {
                'text': response_text,
                'keyboard': keyboard
            }
            
        except Exception as e:
            print(f"Erro ao finalizar agendamento: {e}")
            return {
                'text': "❌ Erro interno. Tente novamente ou entre em contato conosco.",
                'keyboard': []
            }
    
    def _send_appointment_notification(self, user, appointment):
        """Envia notificação por email"""
        try:
            selected_exams = appointment.get_exams()
            
            subject = f"Novo Agendamento - {user.name or 'Cliente'}"
            
            exams_list = "\n".join([f"• {exam['exam_name']}" for exam in selected_exams])
            
            body = f"""
Novo agendamento recebido via chatbot:

Cliente: {user.name or 'N/A'}
CPF: {user.cpf or 'N/A'}
Data de Nascimento: {user.birth_date or 'N/A'}
Convênio: {appointment.covenant_type}

Exames solicitados:
{exams_list}

Valor total: R$ {appointment.total_price:.2f}

Data da solicitação: {appointment.created_at.strftime('%d/%m/%Y %H:%M')}

Acesse o dashboard para agendar os horários.
"""
            
            self.email.send_email(
                to_email="contato@onindigital.com.br",
                subject=subject,
                body=body
            )
            
        except Exception as e:
            print(f"Erro ao enviar email: {e}")
    
    def _show_clinic_info(self, user):
        """Mostra informações da clínica"""
        clinic = ClinicInfo.query.first()
        
        if clinic:
            info_text = f"""
🏥 **{clinic.name}**

📝 {clinic.description}

📍 **Endereço:**
{clinic.address}

📞 **Contatos:**
• Para ligações: {clinic.phone_call}
• Para mensagens: {clinic.phone_whatsapp}
• Email: {clinic.email}

🕐 **Horário de funcionamento:**
{clinic.business_hours}
"""
        else:
            info_text = """
🏥 **ECOS - Radiologia e Diagnóstico**

📍 **Endereço:**
Rua São Paulo, 407 - Lençóis Paulista - CEP 18.682-049

📞 **Contatos:**
• Para ligações: (14) 3436-2300
• Para mensagens: (14) 98171-3057

🕐 **Horário de funcionamento:**
Segunda a Sexta: 7h às 18h | Sábado: 7h às 12h
"""
        
        keyboard = [
            [{'text': '🔙 Voltar ao Menu', 'callback_data': 'menu'}]
        ]
        
        return {
            'text': info_text,
            'keyboard': keyboard
        }
    
    def _transfer_to_attendant(self, user):
        """Transfere para atendente humano"""
        clinic = ClinicInfo.query.first()
        
        if clinic:
            phone_whatsapp = clinic.phone_whatsapp
            phone_call = clinic.phone_call
        else:
            phone_whatsapp = "(14) 98171-3057"
            phone_call = "(14) 3436-2300"
        
        text = f"""
👨‍⚕️ **Transferindo para Atendente**

Você será direcionado para um de nossos atendentes especializados.

📞 **Contatos diretos:**
• **Para mensagens:** {phone_whatsapp}
• **Para ligações:** {phone_call}

⏰ **Horário de atendimento:**
Segunda a Sexta: 7h às 18h
Sábado: 7h às 12h

💬 **Ou continue aqui mesmo!**
Nosso chatbot pode ajudar com agendamentos e orçamentos 24h por dia.
"""
        
        keyboard = [
            [{'text': '🔙 Voltar ao Menu', 'callback_data': 'menu'}]
        ]
        
        return {
            'text': text,
            'keyboard': keyboard
        }
    
    def _handle_satisfaction(self, user, rating):
        """Processa avaliação de satisfação"""
        try:
            rating_num = int(rating)
            if 1 <= rating_num <= 5:
                user.satisfaction_rating = rating_num
                user.current_state = 'START'
                
                return {
                    'text': f"⭐ Obrigado pela avaliação: {rating_num} estrelas!\n\nSua opinião é muito importante para nós.",
                    'keyboard': [
                        [{'text': '🔙 Voltar ao Menu', 'callback_data': 'menu'}]
                    ]
                }
        except ValueError:
            pass
        
        return {
            'text': "⭐ **Avalie nosso atendimento**\n\nDe 1 a 5 estrelas, como você avalia nosso atendimento?",
            'keyboard': [
                [{'text': '⭐', 'callback_data': '1'}, {'text': '⭐⭐', 'callback_data': '2'}],
                [{'text': '⭐⭐⭐', 'callback_data': '3'}, {'text': '⭐⭐⭐⭐', 'callback_data': '4'}],
                [{'text': '⭐⭐⭐⭐⭐', 'callback_data': '5'}]
            ]
        }
    
    def _get_default_response(self):
        """Resposta padrão para mensagens não reconhecidas"""
        return {
            'text': "❓ Não entendi sua mensagem. Use /menu para ver as opções disponíveis.",
            'keyboard': []
        }


    def cleanup_expired_sessions(self):
        """Limpa sessões expiradas (mais de 24 horas)"""
        try:
            from datetime import timedelta
            
            # Data limite (24 horas atrás)
            cutoff_time = datetime.utcnow() - timedelta(hours=24)
            
            # Busca usuários com sessões expiradas
            expired_users = User.query.filter(
                User.last_interaction < cutoff_time,
                User.current_state != 'START'
            ).all()
            
            # Reset das sessões expiradas
            for user in expired_users:
                user.current_state = 'START'
                user.clear_exams()
                user.session_start = datetime.utcnow()
            
            db.session.commit()
            
            return len(expired_users)
            
        except Exception as e:
            db.session.rollback()
            print(f"Erro ao limpar sessões expiradas: {e}")
            return 0
    
    def get_session_stats(self):
        """Retorna estatísticas das sessões ativas"""
        try:
            from datetime import timedelta
            
            # Sessões ativas (últimas 24 horas)
            active_cutoff = datetime.utcnow() - timedelta(hours=24)
            active_sessions = User.query.filter(
                User.last_interaction >= active_cutoff
            ).count()
            
            # Sessões por estado
            state_stats = db.session.query(
                User.current_state,
                db.func.count(User.id).label('count')
            ).filter(
                User.last_interaction >= active_cutoff
            ).group_by(User.current_state).all()
            
            return {
                'active_sessions': active_sessions,
                'states': {state: count for state, count in state_stats}
            }
            
        except Exception as e:
            print(f"Erro ao obter estatísticas de sessão: {e}")
            return {'active_sessions': 0, 'states': {}}
