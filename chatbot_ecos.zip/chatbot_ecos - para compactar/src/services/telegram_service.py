import requests
import json
import os
from typing import Optional, List, Dict, Any

class TelegramService:
    def __init__(self, bot_token: Optional[str] = None):
        self.bot_token = bot_token or os.getenv('TELEGRAM_BOT_TOKEN')
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}"
        
    def send_message(self, chat_id: str, text: str, keyboard: Optional[List[List[Dict]]] = None) -> bool:
        """Envia mensagem para o Telegram"""
        try:
            url = f"{self.base_url}/sendMessage"
            
            data = {
                'chat_id': chat_id,
                'text': text,
                'parse_mode': 'Markdown'
            }
            
            if keyboard:
                reply_markup = {
                    'inline_keyboard': keyboard
                }
                data['reply_markup'] = json.dumps(reply_markup)
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                return True
            else:
                print(f"Erro ao enviar mensagem: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            print(f"Erro no TelegramService.send_message: {e}")
            return False
    
    def set_webhook(self, webhook_url: str) -> bool:
        """Configura webhook do Telegram"""
        try:
            url = f"{self.base_url}/setWebhook"
            data = {'url': webhook_url}
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                return result.get('ok', False)
            else:
                print(f"Erro ao configurar webhook: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            print(f"Erro no TelegramService.set_webhook: {e}")
            return False
    
    def get_webhook_info(self) -> Dict[str, Any]:
        """Obtém informações do webhook"""
        try:
            url = f"{self.base_url}/getWebhookInfo"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            else:
                return {'ok': False, 'error': f'HTTP {response.status_code}'}
                
        except Exception as e:
            print(f"Erro no TelegramService.get_webhook_info: {e}")
            return {'ok': False, 'error': str(e)}
    
    def get_me(self) -> Dict[str, Any]:
        """Obtém informações do bot"""
        try:
            url = f"{self.base_url}/getMe"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            else:
                return {'ok': False, 'error': f'HTTP {response.status_code}'}
                
        except Exception as e:
            print(f"Erro no TelegramService.get_me: {e}")
            return {'ok': False, 'error': str(e)}

