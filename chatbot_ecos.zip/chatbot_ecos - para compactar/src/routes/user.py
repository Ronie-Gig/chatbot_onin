from flask import Blueprint, request, jsonify
from src.models.chatbot import db, User, Exam, Appointment
from datetime import datetime
import json

user_bp = Blueprint('user', __name__)

@user_bp.route('/api/users', methods=['GET'])
def get_users():
    """Lista todos os usuários"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        platform = request.args.get('platform', 'all')
        
        query = User.query
        
        # Filtro por plataforma
        if platform == 'telegram':
            query = query.filter(User.telegram_id.isnot(None))
        elif platform == 'whatsapp':
            query = query.filter(User.whatsapp_id.isnot(None))
        elif platform == 'facebook':
            query = query.filter(User.facebook_id.isnot(None))
        
        users = query.order_by(User.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        users_data = []
        for user in users.items:
            # Determina plataforma principal
            platform = 'TELEGRAM' if user.telegram_id else 'WHATSAPP' if user.whatsapp_id else 'FACEBOOK' if user.facebook_id else 'UNKNOWN'
            
            # Conta agendamentos do usuário
            appointments_count = Appointment.query.filter_by(user_id=user.id).count()
            
            users_data.append({
                'id': user.id,
                'name': user.name,
                'cpf': user.cpf,
                'birth_date': user.birth_date,
                'platform': platform,
                'current_state': user.current_state,
                'last_interaction': user.last_interaction.isoformat() if user.last_interaction else None,
                'created_at': user.created_at.isoformat() if user.created_at else None,
                'appointments_count': appointments_count,
                'total_spent': user.total_price or 0
            })
        
        return jsonify({
            'success': True,
            'users': users_data,
            'pagination': {
                'page': users.page,
                'pages': users.pages,
                'per_page': users.per_page,
                'total': users.total,
                'has_next': users.has_next,
                'has_prev': users.has_prev
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@user_bp.route('/api/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    """Obtém dados detalhados de um usuário específico"""
    try:
        user = User.query.get_or_404(user_id)
        
        # Busca agendamentos do usuário
        appointments = Appointment.query.filter_by(user_id=user_id).order_by(
            Appointment.created_at.desc()
        ).all()
        
        appointments_data = []
        for appointment in appointments:
            exams = appointment.get_exams()
            appointments_data.append({
                'id': appointment.id,
                'created_at': appointment.created_at.isoformat(),
                'covenant_type': appointment.covenant_type,
                'status': appointment.status,
                'total_price': appointment.total_price,
                'exams_count': len(exams),
                'exams': exams,
                'scheduled_at': appointment.scheduled_at.isoformat() if appointment.scheduled_at else None,
                'scheduled_by': appointment.scheduled_by
            })
        
        # Determina plataforma
        platform = 'TELEGRAM' if user.telegram_id else 'WHATSAPP' if user.whatsapp_id else 'FACEBOOK' if user.facebook_id else 'UNKNOWN'
        
        user_data = {
            'id': user.id,
            'name': user.name,
            'cpf': user.cpf,
            'birth_date': user.birth_date,
            'platform': platform,
            'telegram_id': user.telegram_id,
            'whatsapp_id': user.whatsapp_id,
            'facebook_id': user.facebook_id,
            'current_state': user.current_state,
            'session_data': user.get_session_data(),
            'last_interaction': user.last_interaction.isoformat() if user.last_interaction else None,
            'created_at': user.created_at.isoformat() if user.created_at else None,
            'total_price': user.total_price or 0,
            'appointments': appointments_data
        }
        
        return jsonify({
            'success': True,
            'user': user_data
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@user_bp.route('/api/users/<int:user_id>/appointments', methods=['GET'])
def get_user_appointments(user_id):
    """Lista agendamentos de um usuário específico"""
    try:
        user = User.query.get_or_404(user_id)
        
        appointments = Appointment.query.filter_by(user_id=user_id).order_by(
            Appointment.created_at.desc()
        ).all()
        
        appointments_data = []
        for appointment in appointments:
            exams = appointment.get_exams()
            
            appointments_data.append({
                'id': appointment.id,
                'created_at': appointment.created_at.isoformat(),
                'covenant_type': appointment.covenant_type,
                'status': appointment.status,
                'total_price': appointment.total_price,
                'exams': exams,
                'preparation_instructions': appointment.preparation_instructions,
                'scheduled_at': appointment.scheduled_at.isoformat() if appointment.scheduled_at else None,
                'scheduled_by': appointment.scheduled_by,
                'scheduled_exams': appointment.get_scheduled_exams() if appointment.scheduled_exams else None
            })
        
        return jsonify({
            'success': True,
            'user_name': user.name,
            'appointments': appointments_data
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@user_bp.route('/api/users/stats', methods=['GET'])
def get_users_stats():
    """Obtém estatísticas gerais dos usuários"""
    try:
        # Total de usuários
        total_users = User.query.count()
        
        # Usuários por plataforma
        telegram_users = User.query.filter(User.telegram_id.isnot(None)).count()
        whatsapp_users = User.query.filter(User.whatsapp_id.isnot(None)).count()
        facebook_users = User.query.filter(User.facebook_id.isnot(None)).count()
        
        # Usuários ativos (últimos 30 dias)
        thirty_days_ago = datetime.now() - timedelta(days=30)
        active_users = User.query.filter(
            User.last_interaction >= thirty_days_ago
        ).count()
        
        # Novos usuários (últimos 7 dias)
        seven_days_ago = datetime.now() - timedelta(days=7)
        new_users = User.query.filter(
            User.created_at >= seven_days_ago
        ).count()
        
        # Estados mais comuns
        states_stats = db.session.query(
            User.current_state,
            db.func.count(User.id).label('count')
        ).group_by(User.current_state).order_by(
            db.func.count(User.id).desc()
        ).limit(5).all()
        
        return jsonify({
            'success': True,
            'stats': {
                'total_users': total_users,
                'active_users': active_users,
                'new_users': new_users,
                'platform_distribution': {
                    'telegram': telegram_users,
                    'whatsapp': whatsapp_users,
                    'facebook': facebook_users
                },
                'top_states': [
                    {'state': state, 'count': count}
                    for state, count in states_stats
                ]
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@user_bp.route('/api/users/search', methods=['GET'])
def search_users():
    """Busca usuários por nome, CPF ou ID"""
    try:
        query_param = request.args.get('q', '').strip()
        
        if not query_param:
            return jsonify({'success': False, 'error': 'Parâmetro de busca obrigatório'}), 400
        
        # Busca por nome, CPF ou ID
        users = User.query.filter(
            db.or_(
                User.name.ilike(f'%{query_param}%'),
                User.cpf.ilike(f'%{query_param}%'),
                User.id == query_param if query_param.isdigit() else False
            )
        ).order_by(User.created_at.desc()).limit(20).all()
        
        users_data = []
        for user in users:
            platform = 'TELEGRAM' if user.telegram_id else 'WHATSAPP' if user.whatsapp_id else 'FACEBOOK' if user.facebook_id else 'UNKNOWN'
            appointments_count = Appointment.query.filter_by(user_id=user.id).count()
            
            users_data.append({
                'id': user.id,
                'name': user.name,
                'cpf': user.cpf,
                'platform': platform,
                'last_interaction': user.last_interaction.isoformat() if user.last_interaction else None,
                'appointments_count': appointments_count
            })
        
        return jsonify({
            'success': True,
            'users': users_data,
            'query': query_param
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@user_bp.route('/api/health', methods=['GET'])
def health():
    """Endpoint de saúde da API"""
    try:
        # Testa conexão com banco
        user_count = User.query.count()
        
        return jsonify({
            'status': 'ok',
            'service': 'chatbot-ecos',
            'timestamp': datetime.now().isoformat(),
            'database': {
                'connected': True,
                'users': user_count
            },
            'version': '2.0.0'
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'service': 'chatbot-ecos',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@user_bp.route('/api/exams', methods=['GET'])
def get_exams():
    """Lista todos os exames disponíveis"""
    try:
        category = request.args.get('category', 'all')
        active_only = request.args.get('active', 'true').lower() == 'true'
        
        query = Exam.query
        
        if active_only:
            query = query.filter_by(active=True)
        
        if category != 'all':
            query = query.filter_by(category=category)
        
        exams = query.order_by(Exam.exam_name).all()
        
        exams_data = []
        for exam in exams:
            exams_data.append({
                'id': exam.id,
                'exam_id': exam.exam_id,
                'exam_name': exam.exam_name,
                'category': exam.category,
                'price_particular': exam.price_particular,
                'price_funeraria': exam.price_funeraria,
                'price_unimed': exam.price_unimed,
                'preparation_required': exam.preparation_required,
                'preparation_instructions': exam.preparation_instructions,
                'active': exam.active
            })
        
        # Lista de categorias disponíveis
        categories = db.session.query(Exam.category).distinct().all()
        categories_list = [cat[0] for cat in categories]
        
        return jsonify({
            'success': True,
            'exams': exams_data,
            'categories': categories_list,
            'total': len(exams_data)
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@user_bp.route('/api/exams/categories', methods=['GET'])
def get_exam_categories():
    """Lista todas as categorias de exames"""
    try:
        categories = db.session.query(
            Exam.category,
            db.func.count(Exam.id).label('count')
        ).filter_by(active=True).group_by(Exam.category).all()
        
        categories_data = [
            {'name': category, 'count': count}
            for category, count in categories
        ]
        
        return jsonify({
            'success': True,
            'categories': categories_data
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@user_bp.route('/api/appointments', methods=['GET'])
def get_appointments():
    """Lista todos os agendamentos"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status', 'all')
        covenant = request.args.get('covenant', 'all')
        
        query = Appointment.query
        
        # Filtros
        if status != 'all':
            query = query.filter_by(status=status.upper())
        
        if covenant != 'all':
            query = query.filter_by(covenant_type=covenant.upper())
        
        appointments = query.order_by(Appointment.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        appointments_data = []
        for appointment in appointments.items:
            user = User.query.get(appointment.user_id)
            exams = appointment.get_exams()
            
            appointments_data.append({
                'id': appointment.id,
                'user': {
                    'id': user.id if user else None,
                    'name': user.name if user else 'N/A',
                    'cpf': user.cpf if user else 'N/A'
                },
                'created_at': appointment.created_at.isoformat(),
                'covenant_type': appointment.covenant_type,
                'status': appointment.status,
                'total_price': appointment.total_price,
                'exams_count': len(exams),
                'exams': exams,
                'scheduled_at': appointment.scheduled_at.isoformat() if appointment.scheduled_at else None,
                'scheduled_by': appointment.scheduled_by
            })
        
        return jsonify({
            'success': True,
            'appointments': appointments_data,
            'pagination': {
                'page': appointments.page,
                'pages': appointments.pages,
                'per_page': appointments.per_page,
                'total': appointments.total,
                'has_next': appointments.has_next,
                'has_prev': appointments.has_prev
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@user_bp.route('/api/appointments/<int:appointment_id>', methods=['GET'])
def get_appointment(appointment_id):
    """Obtém detalhes de um agendamento específico"""
    try:
        appointment = Appointment.query.get_or_404(appointment_id)
        user = User.query.get(appointment.user_id)
        
        appointment_data = {
            'id': appointment.id,
            'user': {
                'id': user.id if user else None,
                'name': user.name if user else 'N/A',
                'cpf': user.cpf if user else 'N/A',
                'birth_date': user.birth_date if user else None
            },
            'created_at': appointment.created_at.isoformat(),
            'covenant_type': appointment.covenant_type,
            'status': appointment.status,
            'total_price': appointment.total_price,
            'exams': appointment.get_exams(),
            'preparation_instructions': appointment.preparation_instructions,
            'scheduled_at': appointment.scheduled_at.isoformat() if appointment.scheduled_at else None,
            'scheduled_by': appointment.scheduled_by,
            'scheduled_exams': appointment.get_scheduled_exams() if appointment.scheduled_exams else None
        }
        
        return jsonify({
            'success': True,
            'appointment': appointment_data
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

