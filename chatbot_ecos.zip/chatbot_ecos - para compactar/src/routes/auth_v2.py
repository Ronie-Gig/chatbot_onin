from flask import Blueprint, request, session, redirect, url_for, render_template_string, jsonify
from werkzeug.security import check_password_hash
from functools import wraps
from src.models.multi_tenant import db, AdminUser, Clinic
from src.utils.multi_tenant import MultiTenantManager

auth_bp = Blueprint('auth', __name__)

def login_required(f):
    """Decorator para rotas que requerem login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

def master_required(f):
    """Decorator para rotas que requerem permissão de master"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        
        user_type = session.get('user_type')
        if user_type not in ['MASTER', 'SUPER_ADMIN']:
            return "Acesso negado: Permissão de Master necessária", 403
        
        return f(*args, **kwargs)
    return decorated_function

def super_admin_required(f):
    """Decorator para rotas que requerem permissão de super admin"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        
        user_type = session.get('user_type')
        if user_type != 'SUPER_ADMIN':
            return "Acesso negado: Permissão de Super Admin necessária", 403
        
        return f(*args, **kwargs)
    return decorated_function

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Página de login com suporte multi-tenant"""
    if request.method == 'POST':
        try:
            username = request.form['username']
            password = request.form['password']
            
            # Busca usuário
            user = AdminUser.query.filter_by(
                username=username,
                active=True
            ).first()
            
            if user and check_password_hash(user.password_hash, password):
                # Verifica se é super admin
                if user.user_type == 'SUPER_ADMIN':
                    # Super admin pode acessar qualquer coisa
                    session['user_id'] = user.id
                    session['username'] = user.username
                    session['user_type'] = user.user_type
                    session['clinic_id'] = None
                    session['clinic_slug'] = None
                    
                    return redirect(url_for('super_admin.dashboard'))
                
                else:
                    # Usuário de clínica específica
                    if not user.clinic or not user.clinic.active:
                        return render_template_string(LOGIN_TEMPLATE, 
                            error="Clínica inativa ou não encontrada",
                            clinic=None
                        )
                    
                    # Define contexto da clínica
                    session['user_id'] = user.id
                    session['username'] = user.username
                    session['user_type'] = user.user_type
                    session['clinic_id'] = user.clinic_id
                    session['clinic_slug'] = user.clinic.slug
                    
                    # Define clínica no contexto multi-tenant
                    MultiTenantManager.set_current_clinic_slug(user.clinic.slug)
                    
                    return redirect(url_for('dashboard.index'))
            
            else:
                return render_template_string(LOGIN_TEMPLATE, 
                    error="Usuário ou senha inválidos",
                    clinic=MultiTenantManager.get_current_clinic()
                )
                
        except Exception as e:
            print(f"Erro no login: {e}")
            return render_template_string(LOGIN_TEMPLATE, 
                error="Erro interno no login",
                clinic=MultiTenantManager.get_current_clinic()
            )
    
    # GET - Mostra formulário de login
    clinic = MultiTenantManager.get_current_clinic()
    
    return render_template_string(LOGIN_TEMPLATE, 
        error=None,
        clinic=clinic
    )

@auth_bp.route('/logout')
def logout():
    """Logout do usuário"""
    session.clear()
    return redirect(url_for('auth.login'))

@auth_bp.route('/profile')
@login_required
def profile():
    """Perfil do usuário"""
    try:
        user = AdminUser.query.get(session['user_id'])
        if not user:
            return redirect(url_for('auth.logout'))
        
        clinic = MultiTenantManager.get_current_clinic()
        
        return render_template_string(PROFILE_TEMPLATE,
            user=user,
            clinic=clinic,
            current_user=session
        )
        
    except Exception as e:
        print(f"Erro no perfil: {e}")
        return f"Erro no perfil: {e}", 500

@auth_bp.route('/change-password', methods=['POST'])
@login_required
def change_password():
    """Alterar senha do usuário"""
    try:
        data = request.get_json()
        current_password = data.get('current_password')
        new_password = data.get('new_password')
        
        if not current_password or not new_password:
            return jsonify({'error': 'Senhas são obrigatórias'}), 400
        
        user = AdminUser.query.get(session['user_id'])
        if not user:
            return jsonify({'error': 'Usuário não encontrado'}), 404
        
        # Verifica senha atual
        if not check_password_hash(user.password_hash, current_password):
            return jsonify({'error': 'Senha atual incorreta'}), 400
        
        # Atualiza senha
        from werkzeug.security import generate_password_hash
        user.password_hash = generate_password_hash(new_password)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Senha alterada com sucesso'})
        
    except Exception as e:
        print(f"Erro ao alterar senha: {e}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Templates HTML

LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - {{ clinic.name if clinic else 'On In Digital Chatbot' }}</title>
    <style>
        :root {
            --primary-color: {{ clinic.primary_color if clinic else '#1627a3' }};
            --secondary-color: {{ clinic.secondary_color if clinic else '#15aae5' }};
            --gradient: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
            width: 100%;
            max-width: 400px;
            margin: 2rem;
        }
        
        .login-header {
            background: var(--gradient);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        
        .logo {
            width: 60px;
            height: 60px;
            margin: 0 auto 1rem;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        .login-header h1 {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }
        
        .login-header p {
            opacity: 0.9;
            font-size: 0.9rem;
        }
        
        .login-form {
            padding: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: #333;
        }
        
        .form-group input {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
        }
        
        .login-button {
            width: 100%;
            background: var(--gradient);
            color: white;
            padding: 0.75rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.2s;
        }
        
        .login-button:hover {
            transform: translateY(-2px);
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 0.75rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border: 1px solid #f5c6cb;
        }
        
        .footer {
            text-align: center;
            padding: 1rem 2rem 2rem;
            color: #666;
            font-size: 0.9rem;
        }
        
        .powered-by {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #eee;
        }
        
        .on-in-logo {
            width: 20px;
            height: 20px;
        }
        
        .credentials-help {
            background: #e7f3ff;
            border: 1px solid #b3d9ff;
            border-radius: 8px;
            padding: 1rem;
            margin-top: 1rem;
            font-size: 0.85rem;
        }
        
        .credentials-help h4 {
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .credentials-help ul {
            margin: 0;
            padding-left: 1.5rem;
        }
        
        .credentials-help li {
            margin-bottom: 0.25rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo">
                {% if clinic %}
                🏥
                {% else %}
                💻
                {% endif %}
            </div>
            <h1>{{ clinic.name if clinic else 'On In Digital' }}</h1>
            <p>{{ 'Sistema de Agendamentos' if clinic else 'Sistema Multi-tenant' }}</p>
        </div>
        
        <form class="login-form" method="POST">
            {% if error %}
            <div class="error-message">
                {{ error }}
            </div>
            {% endif %}
            
            <div class="form-group">
                <label for="username">Usuário:</label>
                <input type="text" id="username" name="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Senha:</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="login-button">
                Entrar
            </button>
            
            {% if not clinic %}
            <div class="credentials-help">
                <h4>Credenciais de Teste:</h4>
                <ul>
                    <li><strong>Super Admin:</strong> onindigital / onindigital2025@super</li>
                    <li><strong>Master ECOS:</strong> master / ecos2025@master</li>
                    <li><strong>Operadores:</strong> operador1, operador2, operador3 / ecos2025</li>
                </ul>
            </div>
            {% endif %}
        </form>
        
        <div class="footer">
            {% if clinic %}
            <p>&copy; 2025 {{ clinic.name }}. Todos os direitos reservados.</p>
            {% endif %}
            
            <div class="powered-by">
                <span>Powered by</span>
                <img src="/static/images/logo-on-inperfilinstagram.png" alt="On In Digital" class="on-in-logo">
                <strong>On In Digital</strong>
            </div>
        </div>
    </div>
</body>
</html>
"""

PROFILE_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil - {{ clinic.name if clinic else 'On In Digital' }}</title>
    <style>
        :root {
            --primary-color: {{ clinic.primary_color if clinic else '#1627a3' }};
            --secondary-color: {{ clinic.secondary_color if clinic else '#15aae5' }};
            --gradient: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        
        .header {
            background: var(--gradient);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        
        .back-link {
            display: inline-block;
            background: var(--primary-color);
            color: white;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 2rem;
        }
        
        .profile-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .profile-header {
            background: var(--gradient);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        
        .profile-avatar {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            margin: 0 auto 1rem;
        }
        
        .profile-content {
            padding: 2rem;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .info-label {
            font-weight: bold;
            color: #666;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .info-value {
            color: #333;
            font-size: 1.1rem;
        }
        
        .permissions-list {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 8px;
            margin-top: 1rem;
        }
        
        .permission-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        .permission-item:last-child {
            margin-bottom: 0;
        }
        
        .change-password-section {
            border-top: 1px solid #eee;
            padding-top: 2rem;
            margin-top: 2rem;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: #333;
        }
        
        .form-group input {
            width: 100%;
            max-width: 300px;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
        }
        
        .btn {
            background: var(--primary-color);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
        }
        
        .btn:hover {
            background: var(--secondary-color);
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>👤 Meu Perfil</h1>
        </div>
    </div>
    
    <div class="container">
        {% if current_user.user_type == 'SUPER_ADMIN' %}
        <a href="/super/dashboard" class="back-link">← Voltar ao Dashboard</a>
        {% else %}
        <a href="/admin" class="back-link">← Voltar ao Dashboard</a>
        {% endif %}
        
        <div class="profile-card">
            <div class="profile-header">
                <div class="profile-avatar">
                    👤
                </div>
                <h2>{{ user.full_name }}</h2>
                <p>{{ user.user_type }}</p>
            </div>
            
            <div class="profile-content">
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">Usuário:</span>
                        <span class="info-value">{{ user.username }}</span>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">Email:</span>
                        <span class="info-value">{{ user.email or 'Não informado' }}</span>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">Tipo:</span>
                        <span class="info-value">{{ user.user_type }}</span>
                    </div>
                    
                    {% if clinic %}
                    <div class="info-item">
                        <span class="info-label">Clínica:</span>
                        <span class="info-value">{{ clinic.name }}</span>
                    </div>
                    {% endif %}
                    
                    <div class="info-item">
                        <span class="info-label">Criado em:</span>
                        <span class="info-value">{{ user.created_at.strftime('%d/%m/%Y') }}</span>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">Status:</span>
                        <span class="info-value">{{ 'Ativo' if user.active else 'Inativo' }}</span>
                    </div>
                </div>
                
                {% if user.user_type != 'SUPER_ADMIN' %}
                <div class="permissions-list">
                    <h4>Permissões:</h4>
                    <div class="permission-item">
                        <span>{{ '✅' if user.can_manage_exams else '❌' }}</span>
                        <span>Gerenciar Exames</span>
                    </div>
                    <div class="permission-item">
                        <span>{{ '✅' if user.can_manage_users else '❌' }}</span>
                        <span>Gerenciar Usuários</span>
                    </div>
                    <div class="permission-item">
                        <span>{{ '✅' if user.can_view_reports else '❌' }}</span>
                        <span>Visualizar Relatórios</span>
                    </div>
                    <div class="permission-item">
                        <span>{{ '✅' if user.can_schedule else '❌' }}</span>
                        <span>Realizar Agendamentos</span>
                    </div>
                    {% if user.user_type == 'MASTER' %}
                    <div class="permission-item">
                        <span>{{ '✅' if user.can_manage_clinics else '❌' }}</span>
                        <span>Gerenciar Clínicas</span>
                    </div>
                    {% endif %}
                </div>
                {% endif %}
                
                <div class="change-password-section">
                    <h3>Alterar Senha</h3>
                    <form id="changePasswordForm">
                        <div class="form-group">
                            <label for="currentPassword">Senha Atual:</label>
                            <input type="password" id="currentPassword" name="current_password" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="newPassword">Nova Senha:</label>
                            <input type="password" id="newPassword" name="new_password" required>
                        </div>
                        
                        <button type="submit" class="btn">Alterar Senha</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('changePasswordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const currentPassword = document.getElementById('currentPassword').value;
            const newPassword = document.getElementById('newPassword').value;
            
            if (!currentPassword || !newPassword) {
                alert('Preencha todos os campos');
                return;
            }
            
            fetch('/auth/change-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    current_password: currentPassword,
                    new_password: newPassword
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Senha alterada com sucesso!');
                    document.getElementById('changePasswordForm').reset();
                } else {
                    alert('Erro: ' + data.error);
                }
            })
            .catch(error => {
                alert('Erro ao alterar senha: ' + error);
            });
        });
    </script>
</body>
</html>
"""
