from flask import Blueprint, render_template_string, session, request, jsonify, redirect, url_for
from datetime import datetime, timedelta
from src.models.multi_tenant import db, User, Exam, Appointment, AdminUser, Clinic, SystemConfig
from src.routes.auth_v2 import login_required, super_admin_required
from src.utils.multi_tenant import MultiTenantManager
from werkzeug.security import generate_password_hash
import json

super_admin_bp = Blueprint('super_admin', __name__, url_prefix='/super')

@super_admin_bp.route('/dashboard')
@login_required
@super_admin_required
def dashboard():
    """Dashboard do super administrador"""
    try:
        # Estatísticas globais
        total_clinics = Clinic.query.filter_by(active=True).count()
        total_users = User.query.count()
        total_appointments = Appointment.query.count()
        total_admins = AdminUser.query.count()
        
        # Clínicas ativas
        active_clinics = Clinic.query.filter_by(active=True).all()
        
        # Estatísticas por clínica
        clinic_stats = []
        for clinic in active_clinics:
            users_count = User.query.filter_by(clinic_id=clinic.id).count()
            appointments_count = Appointment.query.filter_by(clinic_id=clinic.id).count()
            pending_appointments = Appointment.query.filter_by(
                clinic_id=clinic.id, 
                status='PENDING'
            ).count()
            
            clinic_stats.append({
                'clinic': clinic,
                'users': users_count,
                'appointments': appointments_count,
                'pending': pending_appointments
            })
        
        # Atividade recente
        recent_appointments = Appointment.query.order_by(
            Appointment.created_at.desc()
        ).limit(10).all()
        
        return render_template_string(SUPER_ADMIN_DASHBOARD_TEMPLATE,
            total_clinics=total_clinics,
            total_users=total_users,
            total_appointments=total_appointments,
            total_admins=total_admins,
            clinic_stats=clinic_stats,
            recent_appointments=recent_appointments,
            current_user=session
        )
        
    except Exception as e:
        print(f"Erro no dashboard super admin: {e}")
        return f"Erro no dashboard: {e}", 500

@super_admin_bp.route('/clinics')
@login_required
@super_admin_required
def clinics():
    """Gestão de clínicas"""
    try:
        clinics = Clinic.query.all()
        
        return render_template_string(CLINICS_MANAGEMENT_TEMPLATE,
            clinics=clinics,
            current_user=session
        )
        
    except Exception as e:
        print(f"Erro na gestão de clínicas: {e}")
        return f"Erro na gestão de clínicas: {e}", 500

@super_admin_bp.route('/clinics/create', methods=['GET', 'POST'])
@login_required
@super_admin_required
def create_clinic():
    """Criar nova clínica"""
    if request.method == 'POST':
        try:
            data = request.form
            
            # Verifica se slug já existe
            existing = Clinic.query.filter_by(slug=data['slug']).first()
            if existing:
                return jsonify({'error': 'Slug já existe'}), 400
            
            # Cria nova clínica
            clinic = Clinic(
                name=data['name'],
                slug=data['slug'],
                description=data.get('description', ''),
                address=data.get('address', ''),
                phone_call=data.get('phone_call', ''),
                phone_whatsapp=data.get('phone_whatsapp', ''),
                email=data.get('email', ''),
                business_hours=data.get('business_hours', ''),
                primary_color=data.get('primary_color', '#1627a3'),
                secondary_color=data.get('secondary_color', '#15aae5'),
                telegram_token=data.get('telegram_token', ''),
                whatsapp_token=data.get('whatsapp_token', ''),
                facebook_token=data.get('facebook_token', ''),
                active=True,
                plan=data.get('plan', 'BASIC')
            )
            
            db.session.add(clinic)
            db.session.flush()  # Para obter o ID
            
            # Cria usuário master para a clínica
            master_password = data.get('master_password', 'master123')
            master_user = AdminUser(
                clinic_id=clinic.id,
                username='master',
                password_hash=generate_password_hash(master_password),
                full_name=f'Master {clinic.name}',
                email=data.get('email', ''),
                user_type='MASTER',
                can_manage_exams=True,
                can_manage_users=True,
                can_view_reports=True,
                can_schedule=True,
                can_manage_clinics=False,
                active=True
            )
            
            db.session.add(master_user)
            db.session.commit()
            
            return redirect(url_for('super_admin.clinics'))
            
        except Exception as e:
            print(f"Erro ao criar clínica: {e}")
            db.session.rollback()
            return jsonify({'error': str(e)}), 500
    
    return render_template_string(CREATE_CLINIC_TEMPLATE,
        current_user=session
    )

@super_admin_bp.route('/clinics/<int:clinic_id>/edit', methods=['GET', 'POST'])
@login_required
@super_admin_required
def edit_clinic(clinic_id):
    """Editar clínica"""
    clinic = Clinic.query.get_or_404(clinic_id)
    
    if request.method == 'POST':
        try:
            data = request.form
            
            # Atualiza dados da clínica
            clinic.name = data['name']
            clinic.description = data.get('description', '')
            clinic.address = data.get('address', '')
            clinic.phone_call = data.get('phone_call', '')
            clinic.phone_whatsapp = data.get('phone_whatsapp', '')
            clinic.email = data.get('email', '')
            clinic.business_hours = data.get('business_hours', '')
            clinic.primary_color = data.get('primary_color', '#1627a3')
            clinic.secondary_color = data.get('secondary_color', '#15aae5')
            clinic.telegram_token = data.get('telegram_token', '')
            clinic.whatsapp_token = data.get('whatsapp_token', '')
            clinic.facebook_token = data.get('facebook_token', '')
            clinic.plan = data.get('plan', 'BASIC')
            clinic.active = 'active' in data
            
            db.session.commit()
            
            return redirect(url_for('super_admin.clinics'))
            
        except Exception as e:
            print(f"Erro ao editar clínica: {e}")
            db.session.rollback()
            return jsonify({'error': str(e)}), 500
    
    return render_template_string(EDIT_CLINIC_TEMPLATE,
        clinic=clinic,
        current_user=session
    )

@super_admin_bp.route('/clinics/<int:clinic_id>/toggle', methods=['POST'])
@login_required
@super_admin_required
def toggle_clinic(clinic_id):
    """Ativar/desativar clínica"""
    try:
        clinic = Clinic.query.get_or_404(clinic_id)
        clinic.active = not clinic.active
        db.session.commit()
        
        return jsonify({
            'success': True,
            'active': clinic.active
        })
        
    except Exception as e:
        print(f"Erro ao alterar status da clínica: {e}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@super_admin_bp.route('/system/config')
@login_required
@super_admin_required
def system_config():
    """Configurações do sistema"""
    try:
        configs = SystemConfig.query.filter_by(clinic_id=None).all()
        
        return render_template_string(SYSTEM_CONFIG_TEMPLATE,
            configs=configs,
            current_user=session
        )
        
    except Exception as e:
        print(f"Erro nas configurações do sistema: {e}")
        return f"Erro nas configurações: {e}", 500

@super_admin_bp.route('/system/config/update', methods=['POST'])
@login_required
@super_admin_required
def update_system_config():
    """Atualizar configurações do sistema"""
    try:
        data = request.get_json()
        
        for key, value in data.items():
            config = SystemConfig.query.filter_by(
                clinic_id=None,
                key=key
            ).first()
            
            if config:
                config.value = str(value)
            else:
                config = SystemConfig(
                    clinic_id=None,
                    key=key,
                    value=str(value),
                    description=f'Configuração {key}'
                )
                db.session.add(config)
        
        db.session.commit()
        
        return jsonify({'success': True})
        
    except Exception as e:
        print(f"Erro ao atualizar configurações: {e}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@super_admin_bp.route('/reports/global')
@login_required
@super_admin_required
def global_reports():
    """Relatórios globais"""
    try:
        # Estatísticas por período
        today = datetime.utcnow().date()
        week_ago = today - timedelta(days=7)
        month_ago = today - timedelta(days=30)
        
        # Agendamentos por período
        appointments_today = Appointment.query.filter(
            db.func.date(Appointment.created_at) == today
        ).count()
        
        appointments_week = Appointment.query.filter(
            Appointment.created_at >= week_ago
        ).count()
        
        appointments_month = Appointment.query.filter(
            Appointment.created_at >= month_ago
        ).count()
        
        # Usuários por período
        users_today = User.query.filter(
            db.func.date(User.created_at) == today
        ).count()
        
        users_week = User.query.filter(
            User.created_at >= week_ago
        ).count()
        
        users_month = User.query.filter(
            User.created_at >= month_ago
        ).count()
        
        # Top clínicas por agendamentos
        top_clinics = db.session.query(
            Clinic.name,
            db.func.count(Appointment.id).label('appointments_count')
        ).join(
            Appointment, Appointment.clinic_id == Clinic.id
        ).group_by(
            Clinic.id, Clinic.name
        ).order_by(
            db.func.count(Appointment.id).desc()
        ).limit(10).all()
        
        return render_template_string(GLOBAL_REPORTS_TEMPLATE,
            appointments_today=appointments_today,
            appointments_week=appointments_week,
            appointments_month=appointments_month,
            users_today=users_today,
            users_week=users_week,
            users_month=users_month,
            top_clinics=top_clinics,
            current_user=session
        )
        
    except Exception as e:
        print(f"Erro nos relatórios globais: {e}")
        return f"Erro nos relatórios: {e}", 500

# Templates HTML para Super Admin

SUPER_ADMIN_DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin - On In Digital</title>
    <style>
        :root {
            --primary-color: #1627a3;
            --secondary-color: #15aae5;
            --gradient: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .header {
            background: var(--gradient);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .logo-section {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .logo-section img {
            width: 40px;
            height: 40px;
        }
        
        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary-color);
        }
        
        .stat-card h3 {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .stat-card .number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .nav-menu {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        
        .nav-link {
            background: var(--primary-color);
            color: white;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
            font-weight: bold;
        }
        
        .nav-link:hover {
            background: var(--secondary-color);
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header {
            background: var(--gradient);
            color: white;
            padding: 1rem 1.5rem;
            font-weight: bold;
        }
        
        .card-content {
            padding: 1.5rem;
        }
        
        .clinic-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid #eee;
        }
        
        .clinic-item:last-child {
            border-bottom: none;
        }
        
        .clinic-info h4 {
            color: var(--primary-color);
            margin-bottom: 0.25rem;
        }
        
        .clinic-info p {
            color: #666;
            font-size: 0.9rem;
        }
        
        .clinic-stats {
            text-align: right;
            font-size: 0.9rem;
        }
        
        .clinic-stats .number {
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .footer {
            text-align: center;
            padding: 2rem;
            color: white;
            margin-top: 3rem;
        }
        
        .powered-by {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 1rem;
        }
        
        .on-in-logo {
            width: 24px;
            height: 24px;
        }
        
        @media (max-width: 768px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
            
            .header-content {
                flex-direction: column;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <div class="logo-section">
                <img src="/static/images/logo-on-inperfilinstagraminvertido.png" alt="On In Digital">
                <div>
                    <h1>On In Digital</h1>
                    <p>Super Administrador</p>
                </div>
            </div>
            <div class="user-info">
                <span>Olá, {{ current_user.username }}!</span>
                <a href="/auth/logout" style="color: white; text-decoration: none; margin-left: 1rem;">Sair</a>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Clínicas Ativas</h3>
                <div class="number">{{ total_clinics }}</div>
            </div>
            
            <div class="stat-card">
                <h3>Total de Usuários</h3>
                <div class="number">{{ total_users }}</div>
            </div>
            
            <div class="stat-card">
                <h3>Total de Agendamentos</h3>
                <div class="number">{{ total_appointments }}</div>
            </div>
            
            <div class="stat-card">
                <h3>Administradores</h3>
                <div class="number">{{ total_admins }}</div>
            </div>
        </div>
        
        <div class="nav-menu">
            <a href="/super/clinics" class="nav-link">🏥 Gerenciar Clínicas</a>
            <a href="/super/system/config" class="nav-link">⚙️ Configurações</a>
            <a href="/super/reports/global" class="nav-link">📊 Relatórios Globais</a>
        </div>
        
        <div class="content-grid">
            <div class="card">
                <div class="card-header">
                    🏥 Clínicas por Performance
                </div>
                <div class="card-content">
                    {% for stat in clinic_stats %}
                    <div class="clinic-item">
                        <div class="clinic-info">
                            <h4>{{ stat.clinic.name }}</h4>
                            <p>{{ stat.clinic.slug }}.onindigital.com.br</p>
                        </div>
                        <div class="clinic-stats">
                            <div><span class="number">{{ stat.users }}</span> usuários</div>
                            <div><span class="number">{{ stat.appointments }}</span> agendamentos</div>
                            <div><span class="number">{{ stat.pending }}</span> pendentes</div>
                        </div>
                    </div>
                    {% endfor %}
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    📅 Atividade Recente
                </div>
                <div class="card-content">
                    {% for appointment in recent_appointments %}
                    <div class="clinic-item">
                        <div class="clinic-info">
                            <h4>{{ appointment.clinic.name }}</h4>
                            <p>{{ appointment.user.name or 'Nome não informado' }}</p>
                        </div>
                        <div class="clinic-stats">
                            <div>R$ {{ "%.2f"|format(appointment.total_price) }}</div>
                            <div>{{ appointment.created_at.strftime('%d/%m %H:%M') }}</div>
                        </div>
                    </div>
                    {% endfor %}
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer">
        <div class="powered-by">
            <img src="/static/images/logo-on-inperfilinstagraminvertido.png" alt="On In Digital" class="on-in-logo">
            <strong>On In Digital - Sistema Multi-tenant</strong>
        </div>
        <p>&copy; 2025 On In Digital. Todos os direitos reservados.</p>
    </div>
</body>
</html>
"""

CLINICS_MANAGEMENT_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Clínicas - On In Digital</title>
    <style>
        /* Estilos similares ao dashboard principal */
        :root {
            --primary-color: #1627a3;
            --secondary-color: #15aae5;
            --gradient: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .header {
            background: var(--gradient);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        
        .actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        
        .back-link {
            background: var(--primary-color);
            color: white;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
        }
        
        .btn-create {
            background: #28a745;
            color: white;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
        
        .clinics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
            gap: 2rem;
        }
        
        .clinic-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .clinic-header {
            background: var(--gradient);
            color: white;
            padding: 1rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .clinic-content {
            padding: 1.5rem;
        }
        
        .clinic-info {
            margin-bottom: 1rem;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        
        .info-label {
            font-weight: bold;
            color: #666;
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .status-active {
            background: #d4edda;
            color: #155724;
        }
        
        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }
        
        .clinic-actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
        }
        
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        
        .btn-edit {
            background: #007bff;
            color: white;
        }
        
        .btn-toggle {
            background: #ffc107;
            color: #212529;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>🏥 Gerenciar Clínicas</h1>
        </div>
    </div>
    
    <div class="container">
        <div class="actions">
            <a href="/super/dashboard" class="back-link">← Voltar ao Dashboard</a>
            <a href="/super/clinics/create" class="btn-create">+ Nova Clínica</a>
        </div>
        
        <div class="clinics-grid">
            {% for clinic in clinics %}
            <div class="clinic-card">
                <div class="clinic-header">
                    <h3>{{ clinic.name }}</h3>
                    <span class="status-badge status-{{ 'active' if clinic.active else 'inactive' }}">
                        {{ 'Ativa' if clinic.active else 'Inativa' }}
                    </span>
                </div>
                
                <div class="clinic-content">
                    <div class="clinic-info">
                        <div class="info-item">
                            <span class="info-label">Slug:</span>
                            <span>{{ clinic.slug }}</span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">URL:</span>
                            <span>{{ clinic.slug }}.onindigital.com.br</span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Plano:</span>
                            <span>{{ clinic.plan }}</span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Telefone:</span>
                            <span>{{ clinic.phone_call or 'Não informado' }}</span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">WhatsApp:</span>
                            <span>{{ clinic.phone_whatsapp or 'Não informado' }}</span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Criada em:</span>
                            <span>{{ clinic.created_at.strftime('%d/%m/%Y') }}</span>
                        </div>
                    </div>
                    
                    <div class="clinic-actions">
                        <a href="/super/clinics/{{ clinic.id }}/edit" class="btn btn-edit">✏️ Editar</a>
                        <button class="btn btn-toggle" onclick="toggleClinic({{ clinic.id }})">
                            {{ '🔒 Desativar' if clinic.active else '✅ Ativar' }}
                        </button>
                        <a href="/admin?clinic={{ clinic.slug }}" class="btn btn-edit" target="_blank">👁️ Visualizar</a>
                    </div>
                </div>
            </div>
            {% endfor %}
        </div>
    </div>
    
    <script>
        function toggleClinic(clinicId) {
            if (confirm('Tem certeza que deseja alterar o status desta clínica?')) {
                fetch(`/super/clinics/${clinicId}/toggle`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert('Erro ao alterar status: ' + data.error);
                    }
                })
                .catch(error => {
                    alert('Erro ao alterar status: ' + error);
                });
            }
        }
    </script>
</body>
</html>
"""

CREATE_CLINIC_TEMPLATE = """
<!-- Template para criar clínica será implementado se necessário -->
"""

EDIT_CLINIC_TEMPLATE = """
<!-- Template para editar clínica será implementado se necessário -->
"""

SYSTEM_CONFIG_TEMPLATE = """
<!-- Template para configurações do sistema será implementado se necessário -->
"""

GLOBAL_REPORTS_TEMPLATE = """
<!-- Template para relatórios globais será implementado se necessário -->
"""
