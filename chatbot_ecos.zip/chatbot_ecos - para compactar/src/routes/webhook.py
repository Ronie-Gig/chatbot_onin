from flask import Blueprint, request, jsonify
from src.services.chatbot_handler import ChatbotHandler
from src.services.telegram_service import TelegramService
import os

webhook_bp = Blueprint('webhook', __name__)

# Inicializa handler do chatbot
chatbot_handler = ChatbotHandler()

@webhook_bp.route('/webhook/telegram', methods=['POST'])
def telegram_webhook():
    """Recebe webhooks do Telegram"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'status': 'error', 'message': 'No data received'}), 400
        
        # Processa mensagem
        if 'message' in data:
            message = data['message']
            user_data = {
                'id': message['from']['id'],
                'first_name': message['from'].get('first_name', ''),
                'last_name': message['from'].get('last_name', ''),
                'username': message['from'].get('username', '')
            }
            
            # Determina tipo de mensagem
            if 'text' in message:
                message_data = {
                    'type': 'text',
                    'text': message['text']
                }
            elif 'photo' in message:
                message_data = {
                    'type': 'photo',
                    'file_id': message['photo'][-1]['file_id']  # Pega a maior resolução
                }
            else:
                message_data = {
                    'type': 'other',
                    'content': str(message)
                }
            
            # Processa via handler
            result = chatbot_handler.process_message('TELEGRAM', user_data, message_data)
            
            if result['status'] == 'success':
                # Envia resposta via Telegram
                response = result['response']
                telegram_service = TelegramService()
                
                success = telegram_service.send_message(
                    chat_id=str(user_data['id']),
                    text=response['text'],
                    keyboard=response.get('keyboard')
                )
                
                if success:
                    return jsonify({'status': 'success'})
                else:
                    return jsonify({'status': 'error', 'message': 'Failed to send response'}), 500
            else:
                return jsonify({'status': 'error', 'message': result['message']}), 500
        
        # Processa callback query (botões inline)
        elif 'callback_query' in data:
            callback = data['callback_query']
            user_data = {
                'id': callback['from']['id'],
                'first_name': callback['from'].get('first_name', ''),
                'last_name': callback['from'].get('last_name', ''),
                'username': callback['from'].get('username', '')
            }
            
            message_data = {
                'type': 'callback',
                'data': callback['data']
            }
            
            # Processa via handler
            result = chatbot_handler.process_message('TELEGRAM', user_data, message_data)
            
            if result['status'] == 'success':
                # Envia resposta via Telegram
                response = result['response']
                telegram_service = TelegramService()
                
                success = telegram_service.send_message(
                    chat_id=str(user_data['id']),
                    text=response['text'],
                    keyboard=response.get('keyboard')
                )
                
                if success:
                    return jsonify({'status': 'success'})
                else:
                    return jsonify({'status': 'error', 'message': 'Failed to send response'}), 500
            else:
                return jsonify({'status': 'error', 'message': result['message']}), 500
        
        return jsonify({'status': 'success', 'message': 'Webhook processed'})
        
    except Exception as e:
        print(f"Erro no webhook do Telegram: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500

@webhook_bp.route('/webhook/whatsapp', methods=['POST'])
def whatsapp_webhook():
    """Recebe webhooks do WhatsApp Business API"""
    try:
        data = request.get_json()
        
        # Implementação futura para WhatsApp
        # Por enquanto, apenas retorna sucesso
        
        return jsonify({'status': 'success', 'message': 'WhatsApp webhook received'})
        
    except Exception as e:
        print(f"Erro no webhook do WhatsApp: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500

@webhook_bp.route('/webhook/facebook', methods=['POST'])
def facebook_webhook():
    """Recebe webhooks do Facebook Messenger"""
    try:
        data = request.get_json()
        
        # Implementação futura para Facebook
        # Por enquanto, apenas retorna sucesso
        
        return jsonify({'status': 'success', 'message': 'Facebook webhook received'})
        
    except Exception as e:
        print(f"Erro no webhook do Facebook: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500

@webhook_bp.route('/webhook/test', methods=['GET'])
def test_webhook():
    """Testa se os webhooks estão funcionando"""
    return jsonify({
        'status': 'ok',
        'message': 'Webhooks are working',
        'endpoints': {
            'telegram': '/webhook/telegram',
            'whatsapp': '/webhook/whatsapp',
            'facebook': '/webhook/facebook'
        },
        'telegram_configured': bool(os.getenv('TELEGRAM_BOT_TOKEN'))
    })

@webhook_bp.route('/setup/telegram', methods=['POST'])
def setup_telegram():
    """Configura webhook do Telegram"""
    try:
        data = request.get_json()
        webhook_url = data.get('webhook_url')
        
        if not webhook_url:
            return jsonify({'status': 'error', 'message': 'webhook_url is required'}), 400
        
        telegram_service = TelegramService()
        success = telegram_service.set_webhook(webhook_url)
        
        if success:
            return jsonify({'status': 'success', 'message': 'Webhook configured successfully'})
        else:
            return jsonify({'status': 'error', 'message': 'Failed to configure webhook'}), 500
            
    except Exception as e:
        print(f"Erro ao configurar webhook: {e}")
        return jsonify({'status': 'error', 'message': 'Failed to configure webhook'}), 500

