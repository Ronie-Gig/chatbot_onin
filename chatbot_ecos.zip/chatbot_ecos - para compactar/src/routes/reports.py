from flask import Blueprint, render_template_string, request, jsonify, send_file
from datetime import datetime, timedelta
from src.models.chatbot import db, User, Exam, Appointment, AdminUser
from src.routes.auth import login_required, master_required
import json
import io
import csv
from collections import defaultdict

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/admin/reports')
@master_required
def reports_dashboard():
    """Dashboard de relatórios (apenas master)"""
    # Período padrão: últimos 30 dias
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    
    # Estatísticas gerais
    stats = _get_general_stats(start_date, end_date)
    
    # Gráficos de dados
    charts_data = _get_charts_data(start_date, end_date)
    
    return render_template_string(REPORTS_DASHBOARD_TEMPLATE,
        stats=stats,
        charts_data=charts_data,
        start_date=start_date.strftime('%Y-%m-%d'),
        end_date=end_date.strftime('%Y-%m-%d')
    )

@reports_bp.route('/admin/reports/data')
@master_required
def reports_data():
    """API para dados de relatórios"""
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    if start_date:
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
    else:
        start_date = datetime.now() - timedelta(days=30)
    
    if end_date:
        end_date = datetime.strptime(end_date, '%Y-%m-%d')
    else:
        end_date = datetime.now()
    
    # Ajusta para incluir o dia inteiro
    end_date = end_date.replace(hour=23, minute=59, second=59)
    
    stats = _get_general_stats(start_date, end_date)
    charts_data = _get_charts_data(start_date, end_date)
    
    return jsonify({
        'stats': stats,
        'charts': charts_data
    })

@reports_bp.route('/admin/reports/export/appointments')
@master_required
def export_appointments():
    """Exportar agendamentos para CSV"""
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    if start_date:
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
    else:
        start_date = datetime.now() - timedelta(days=30)
    
    if end_date:
        end_date = datetime.strptime(end_date, '%Y-%m-%d')
        end_date = end_date.replace(hour=23, minute=59, second=59)
    else:
        end_date = datetime.now()
    
    # Busca agendamentos no período
    appointments = Appointment.query.filter(
        Appointment.created_at >= start_date,
        Appointment.created_at <= end_date
    ).all()
    
    # Cria CSV em memória
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Cabeçalho
    writer.writerow([
        'Data/Hora',
        'Cliente',
        'CPF',
        'Convênio',
        'Exames',
        'Valor Total',
        'Status',
        'Data Agendamento',
        'Agendado Por'
    ])
    
    # Dados
    for appointment in appointments:
        user = User.query.get(appointment.user_id)
        exams = appointment.get_exams()
        exam_names = ', '.join([exam['exam_name'] for exam in exams])
        
        writer.writerow([
            appointment.created_at.strftime('%d/%m/%Y %H:%M'),
            user.name if user else 'N/A',
            user.cpf if user else 'N/A',
            appointment.covenant_type,
            exam_names,
            f"R$ {appointment.total_price:.2f}" if appointment.total_price else 'N/A',
            'Confirmado' if appointment.status == 'CONFIRMED' else 'Pendente',
            appointment.scheduled_at.strftime('%d/%m/%Y %H:%M') if appointment.scheduled_at else 'N/A',
            appointment.scheduled_by or 'N/A'
        ])
    
    # Prepara arquivo para download
    output.seek(0)
    
    # Cria arquivo temporário
    filename = f"agendamentos_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}.csv"
    
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8-sig')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=filename
    )

@reports_bp.route('/admin/reports/export/exams')
@master_required
def export_exams_stats():
    """Exportar estatísticas de exames para CSV"""
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    if start_date:
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
    else:
        start_date = datetime.now() - timedelta(days=30)
    
    if end_date:
        end_date = datetime.strptime(end_date, '%Y-%m-%d')
        end_date = end_date.replace(hour=23, minute=59, second=59)
    else:
        end_date = datetime.now()
    
    # Busca estatísticas de exames
    exam_stats = _get_exam_statistics(start_date, end_date)
    
    # Cria CSV em memória
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Cabeçalho
    writer.writerow([
        'Exame',
        'Categoria',
        'Quantidade Solicitada',
        'Receita Total (Particular)',
        'Receita Total (Funerária)',
        'Receita Total Geral'
    ])
    
    # Dados
    for stat in exam_stats:
        writer.writerow([
            stat['exam_name'],
            stat['category'],
            stat['count'],
            f"R$ {stat['revenue_particular']:.2f}",
            f"R$ {stat['revenue_funeraria']:.2f}",
            f"R$ {stat['total_revenue']:.2f}"
        ])
    
    # Prepara arquivo para download
    output.seek(0)
    
    filename = f"estatisticas_exames_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}.csv"
    
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8-sig')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=filename
    )

@reports_bp.route('/admin/reports/daily')
@master_required
def daily_report():
    """Relatório diário"""
    date = request.args.get('date')
    if date:
        target_date = datetime.strptime(date, '%Y-%m-%d')
    else:
        target_date = datetime.now()
    
    # Define período do dia
    start_date = target_date.replace(hour=0, minute=0, second=0)
    end_date = target_date.replace(hour=23, minute=59, second=59)
    
    # Estatísticas do dia
    daily_stats = _get_daily_stats(start_date, end_date)
    
    # Agendamentos do dia
    appointments = Appointment.query.filter(
        Appointment.created_at >= start_date,
        Appointment.created_at <= end_date
    ).order_by(Appointment.created_at.desc()).all()
    
    return render_template_string(DAILY_REPORT_TEMPLATE,
        date=target_date,
        stats=daily_stats,
        appointments=appointments
    )

def _get_general_stats(start_date, end_date):
    """Obtém estatísticas gerais do período"""
    # Total de usuários
    total_users = User.query.filter(
        User.created_at >= start_date,
        User.created_at <= end_date
    ).count()
    
    # Total de agendamentos
    total_appointments = Appointment.query.filter(
        Appointment.created_at >= start_date,
        Appointment.created_at <= end_date
    ).count()
    
    # Agendamentos confirmados
    confirmed_appointments = Appointment.query.filter(
        Appointment.created_at >= start_date,
        Appointment.created_at <= end_date,
        Appointment.status == 'CONFIRMED'
    ).count()
    
    # Receita total
    total_revenue = db.session.query(
        db.func.sum(Appointment.total_price)
    ).filter(
        Appointment.created_at >= start_date,
        Appointment.created_at <= end_date,
        Appointment.total_price.isnot(None)
    ).scalar() or 0
    
    # Taxa de conversão
    conversion_rate = (confirmed_appointments / total_appointments * 100) if total_appointments > 0 else 0
    
    # Usuários por plataforma
    telegram_users = User.query.filter(
        User.created_at >= start_date,
        User.created_at <= end_date,
        User.telegram_id.isnot(None)
    ).count()
    
    whatsapp_users = User.query.filter(
        User.created_at >= start_date,
        User.created_at <= end_date,
        User.whatsapp_id.isnot(None)
    ).count()
    
    facebook_users = User.query.filter(
        User.created_at >= start_date,
        User.created_at <= end_date,
        User.facebook_id.isnot(None)
    ).count()
    
    return {
        'total_users': total_users,
        'total_appointments': total_appointments,
        'confirmed_appointments': confirmed_appointments,
        'pending_appointments': total_appointments - confirmed_appointments,
        'total_revenue': total_revenue,
        'conversion_rate': round(conversion_rate, 2),
        'telegram_users': telegram_users,
        'whatsapp_users': whatsapp_users,
        'facebook_users': facebook_users
    }

def _get_charts_data(start_date, end_date):
    """Obtém dados para gráficos"""
    # Agendamentos por dia
    appointments_by_day = db.session.query(
        db.func.date(Appointment.created_at).label('date'),
        db.func.count(Appointment.id).label('count')
    ).filter(
        Appointment.created_at >= start_date,
        Appointment.created_at <= end_date
    ).group_by(db.func.date(Appointment.created_at)).all()
    
    # Exames mais solicitados
    exam_stats = _get_exam_statistics(start_date, end_date)
    top_exams = sorted(exam_stats, key=lambda x: x['count'], reverse=True)[:10]
    
    # Agendamentos por convênio
    covenant_stats = db.session.query(
        Appointment.covenant_type,
        db.func.count(Appointment.id).label('count')
    ).filter(
        Appointment.created_at >= start_date,
        Appointment.created_at <= end_date
    ).group_by(Appointment.covenant_type).all()
    
    # Receita por dia
    revenue_by_day = db.session.query(
        db.func.date(Appointment.created_at).label('date'),
        db.func.sum(Appointment.total_price).label('revenue')
    ).filter(
        Appointment.created_at >= start_date,
        Appointment.created_at <= end_date,
        Appointment.total_price.isnot(None)
    ).group_by(db.func.date(Appointment.created_at)).all()
    
    return {
        'appointments_by_day': [
            {'date': str(item.date), 'count': item.count}
            for item in appointments_by_day
        ],
        'top_exams': [
            {'name': item['exam_name'], 'count': item['count']}
            for item in top_exams
        ],
        'covenant_stats': [
            {'covenant': item.covenant_type, 'count': item.count}
            for item in covenant_stats
        ],
        'revenue_by_day': [
            {'date': str(item.date), 'revenue': float(item.revenue or 0)}
            for item in revenue_by_day
        ]
    }

def _get_exam_statistics(start_date, end_date):
    """Obtém estatísticas detalhadas de exames"""
    appointments = Appointment.query.filter(
        Appointment.created_at >= start_date,
        Appointment.created_at <= end_date
    ).all()
    
    exam_stats = defaultdict(lambda: {
        'count': 0,
        'revenue_particular': 0,
        'revenue_funeraria': 0,
        'total_revenue': 0,
        'category': '',
        'exam_name': ''
    })
    
    for appointment in appointments:
        exams = appointment.get_exams()
        
        for exam in exams:
            exam_id = exam['exam_id']
            exam_name = exam['exam_name']
            category = exam.get('category', 'N/A')
            
            exam_stats[exam_id]['exam_name'] = exam_name
            exam_stats[exam_id]['category'] = category
            exam_stats[exam_id]['count'] += 1
            
            # Calcula receita baseada no convênio
            if appointment.covenant_type == 'PARTICULAR':
                revenue = exam.get('price', 0)
                exam_stats[exam_id]['revenue_particular'] += revenue
                exam_stats[exam_id]['total_revenue'] += revenue
            elif appointment.covenant_type == 'FUNERARIA':
                revenue = exam.get('price', 0)
                exam_stats[exam_id]['revenue_funeraria'] += revenue
                exam_stats[exam_id]['total_revenue'] += revenue
    
    return list(exam_stats.values())

def _get_daily_stats(start_date, end_date):
    """Obtém estatísticas de um dia específico"""
    stats = _get_general_stats(start_date, end_date)
    
    # Adiciona estatísticas específicas do dia
    # Horário de pico
    hourly_stats = db.session.query(
        db.func.extract('hour', Appointment.created_at).label('hour'),
        db.func.count(Appointment.id).label('count')
    ).filter(
        Appointment.created_at >= start_date,
        Appointment.created_at <= end_date
    ).group_by(db.func.extract('hour', Appointment.created_at)).all()
    
    peak_hour = max(hourly_stats, key=lambda x: x.count) if hourly_stats else None
    
    stats['peak_hour'] = f"{int(peak_hour.hour)}:00" if peak_hour else 'N/A'
    stats['hourly_distribution'] = [
        {'hour': int(item.hour), 'count': item.count}
        for item in hourly_stats
    ]
    
    return stats

# Templates HTML
REPORTS_DASHBOARD_TEMPLATE = '''
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - ECOS Chatbot</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5rem; }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .filters {
            background: white;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        .filters input, .filters button {
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .filters button {
            background: #667eea;
            color: white;
            cursor: pointer;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-card h3 {
            font-size: 2rem;
            color: #667eea;
            margin-bottom: 0.5rem;
        }
        .stat-card p {
            color: #666;
            font-weight: 600;
        }
        .charts-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }
        .chart-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 1.5rem;
        }
        .chart-card h4 {
            margin-bottom: 1rem;
            color: #333;
        }
        .chart-container {
            position: relative;
            height: 300px;
        }
        .export-section {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .export-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-success {
            background: #28a745;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>📊 Relatórios</h1>
        <a href="{{ url_for('dashboard.index') }}" class="btn btn-secondary">Voltar ao Dashboard</a>
    </div>
    
    <div class="container">
        <div class="filters">
            <label>Período:</label>
            <input type="date" id="start_date" value="{{ start_date }}">
            <label>até</label>
            <input type="date" id="end_date" value="{{ end_date }}">
            <button onclick="updateReports()">Atualizar</button>
        </div>
        
        <div class="stats-grid" id="stats-grid">
            <div class="stat-card">
                <h3>{{ stats.total_users }}</h3>
                <p>Novos Usuários</p>
            </div>
            <div class="stat-card">
                <h3>{{ stats.total_appointments }}</h3>
                <p>Total de Agendamentos</p>
            </div>
            <div class="stat-card">
                <h3>{{ stats.confirmed_appointments }}</h3>
                <p>Confirmados</p>
            </div>
            <div class="stat-card">
                <h3>R$ {{ "%.2f"|format(stats.total_revenue) }}</h3>
                <p>Receita Total</p>
            </div>
            <div class="stat-card">
                <h3>{{ stats.conversion_rate }}%</h3>
                <p>Taxa de Conversão</p>
            </div>
        </div>
        
        <div class="charts-grid">
            <div class="chart-card">
                <h4>Agendamentos por Dia</h4>
                <div class="chart-container">
                    <canvas id="appointmentsChart"></canvas>
                </div>
            </div>
            
            <div class="chart-card">
                <h4>Exames Mais Solicitados</h4>
                <div class="chart-container">
                    <canvas id="examsChart"></canvas>
                </div>
            </div>
            
            <div class="chart-card">
                <h4>Agendamentos por Convênio</h4>
                <div class="chart-container">
                    <canvas id="covenantChart"></canvas>
                </div>
            </div>
            
            <div class="chart-card">
                <h4>Receita por Dia</h4>
                <div class="chart-container">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>
        </div>
        
        <div class="export-section">
            <h4>📥 Exportar Dados</h4>
            <p>Baixe relatórios detalhados em formato CSV para análise externa.</p>
            <div class="export-buttons">
                <a href="#" onclick="exportAppointments()" class="btn btn-success">Exportar Agendamentos</a>
                <a href="#" onclick="exportExamsStats()" class="btn btn-success">Exportar Estatísticas de Exames</a>
                <a href="{{ url_for('reports.daily_report') }}" class="btn btn-primary">Relatório Diário</a>
            </div>
        </div>
    </div>
    
    <script>
        let chartsData = {{ charts_data|tojson }};
        
        // Gráfico de agendamentos por dia
        const appointmentsCtx = document.getElementById('appointmentsChart').getContext('2d');
        new Chart(appointmentsCtx, {
            type: 'line',
            data: {
                labels: chartsData.appointments_by_day.map(item => item.date),
                datasets: [{
                    label: 'Agendamentos',
                    data: chartsData.appointments_by_day.map(item => item.count),
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        
        // Gráfico de exames mais solicitados
        const examsCtx = document.getElementById('examsChart').getContext('2d');
        new Chart(examsCtx, {
            type: 'bar',
            data: {
                labels: chartsData.top_exams.map(item => item.name.substring(0, 20) + '...'),
                datasets: [{
                    label: 'Quantidade',
                    data: chartsData.top_exams.map(item => item.count),
                    backgroundColor: '#28a745'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // Gráfico de convênios
        const covenantCtx = document.getElementById('covenantChart').getContext('2d');
        new Chart(covenantCtx, {
            type: 'doughnut',
            data: {
                labels: chartsData.covenant_stats.map(item => item.covenant),
                datasets: [{
                    data: chartsData.covenant_stats.map(item => item.count),
                    backgroundColor: ['#667eea', '#28a745', '#ffc107']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        
        // Gráfico de receita por dia
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        new Chart(revenueCtx, {
            type: 'bar',
            data: {
                labels: chartsData.revenue_by_day.map(item => item.date),
                datasets: [{
                    label: 'Receita (R$)',
                    data: chartsData.revenue_by_day.map(item => item.revenue),
                    backgroundColor: '#ffc107'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        function updateReports() {
            const startDate = document.getElementById('start_date').value;
            const endDate = document.getElementById('end_date').value;
            
            fetch(`/admin/reports/data?start_date=${startDate}&end_date=${endDate}`)
                .then(response => response.json())
                .then(data => {
                    // Atualizar estatísticas
                    updateStats(data.stats);
                    // Atualizar gráficos
                    updateCharts(data.charts);
                });
        }
        
        function updateStats(stats) {
            const statsGrid = document.getElementById('stats-grid');
            statsGrid.innerHTML = `
                <div class="stat-card">
                    <h3>${stats.total_users}</h3>
                    <p>Novos Usuários</p>
                </div>
                <div class="stat-card">
                    <h3>${stats.total_appointments}</h3>
                    <p>Total de Agendamentos</p>
                </div>
                <div class="stat-card">
                    <h3>${stats.confirmed_appointments}</h3>
                    <p>Confirmados</p>
                </div>
                <div class="stat-card">
                    <h3>R$ ${stats.total_revenue.toFixed(2)}</h3>
                    <p>Receita Total</p>
                </div>
                <div class="stat-card">
                    <h3>${stats.conversion_rate}%</h3>
                    <p>Taxa de Conversão</p>
                </div>
            `;
        }
        
        function updateCharts(charts) {
            // Implementar atualização dos gráficos
            chartsData = charts;
            location.reload(); // Simplificado para demo
        }
        
        function exportAppointments() {
            const startDate = document.getElementById('start_date').value;
            const endDate = document.getElementById('end_date').value;
            window.open(`/admin/reports/export/appointments?start_date=${startDate}&end_date=${endDate}`);
        }
        
        function exportExamsStats() {
            const startDate = document.getElementById('start_date').value;
            const endDate = document.getElementById('end_date').value;
            window.open(`/admin/reports/export/exams?start_date=${startDate}&end_date=${endDate}`);
        }
    </script>
</body>
</html>
'''

DAILY_REPORT_TEMPLATE = '''
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório Diário - ECOS Chatbot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5rem; }
        .container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .date-selector {
            background: white;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-card h3 {
            font-size: 1.5rem;
            color: #667eea;
            margin-bottom: 0.5rem;
        }
        .appointments-list {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .appointments-header {
            background: #f8f9fa;
            padding: 1rem;
            font-weight: 600;
            border-bottom: 1px solid #e9ecef;
        }
        .appointment-item {
            padding: 1rem;
            border-bottom: 1px solid #e9ecef;
        }
        .appointment-item:last-child {
            border-bottom: none;
        }
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>📅 Relatório Diário - {{ date.strftime('%d/%m/%Y') }}</h1>
        <a href="{{ url_for('reports.reports_dashboard') }}" class="btn btn-secondary">Voltar aos Relatórios</a>
    </div>
    
    <div class="container">
        <div class="date-selector">
            <form method="GET">
                <label>Selecionar Data:</label>
                <input type="date" name="date" value="{{ date.strftime('%Y-%m-%d') }}" onchange="this.form.submit()">
            </form>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>{{ stats.total_users }}</h3>
                <p>Novos Usuários</p>
            </div>
            <div class="stat-card">
                <h3>{{ stats.total_appointments }}</h3>
                <p>Agendamentos</p>
            </div>
            <div class="stat-card">
                <h3>{{ stats.confirmed_appointments }}</h3>
                <p>Confirmados</p>
            </div>
            <div class="stat-card">
                <h3>R$ {{ "%.2f"|format(stats.total_revenue) }}</h3>
                <p>Receita</p>
            </div>
            <div class="stat-card">
                <h3>{{ stats.peak_hour }}</h3>
                <p>Horário de Pico</p>
            </div>
        </div>
        
        <div class="appointments-list">
            <div class="appointments-header">
                📋 Agendamentos do Dia ({{ appointments|length }})
            </div>
            {% for appointment in appointments %}
            <div class="appointment-item">
                <strong>{{ appointment.user.name or 'Cliente' }}</strong> - {{ appointment.covenant_type }}<br>
                <small>{{ appointment.created_at.strftime('%H:%M') }} | {{ appointment.get_exams()|length }} exame(s) | 
                Status: {{ 'Confirmado' if appointment.status == 'CONFIRMED' else 'Pendente' }}</small>
            </div>
            {% endfor %}
            
            {% if not appointments %}
            <div class="appointment-item">
                <em>Nenhum agendamento neste dia.</em>
            </div>
            {% endif %}
        </div>
    </div>
</body>
</html>
'''

