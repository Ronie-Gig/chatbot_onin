from flask import Blueprint, render_template_string, request, redirect, url_for, flash, jsonify, session
from datetime import datetime, timedelta
from src.models.chatbot import db, User, Exam, Appointment, AdminUser, ClinicInfo
from src.routes.auth import login_required, master_required
from werkzeug.security import generate_password_hash
import json

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/admin')
@login_required
def index():
    """Dashboard principal"""
    # Estatísticas gerais
    total_users = User.query.count()
    total_appointments = Appointment.query.count()
    pending_appointments = Appointment.query.filter_by(status='PENDING').count()
    confirmed_appointments = Appointment.query.filter_by(status='CONFIRMED').count()
    
    # Agendamentos recentes
    recent_appointments = Appointment.query.order_by(Appointment.created_at.desc()).limit(10).all()
    
    # Exames mais solicitados
    exam_stats = db.session.query(
        Exam.exam_name,
        db.func.count(Appointment.id).label('count')
    ).join(
        Appointment, 
        db.func.json_extract(Appointment.exams, '$[*].exam_name').contains(Exam.exam_name)
    ).group_by(Exam.exam_name).order_by(db.func.count(Appointment.id).desc()).limit(5).all()
    
    # Usuários por plataforma
    telegram_users = User.query.filter(User.telegram_id.isnot(None)).count()
    whatsapp_users = User.query.filter(User.whatsapp_id.isnot(None)).count()
    facebook_users = User.query.filter(User.facebook_id.isnot(None)).count()
    
    return render_template_string(DASHBOARD_TEMPLATE, 
        total_users=total_users,
        total_appointments=total_appointments,
        pending_appointments=pending_appointments,
        confirmed_appointments=confirmed_appointments,
        recent_appointments=recent_appointments,
        exam_stats=exam_stats,
        telegram_users=telegram_users,
        whatsapp_users=whatsapp_users,
        facebook_users=facebook_users,
        current_user=session
    )

@dashboard_bp.route('/admin/appointments')
@login_required
def appointments():
    """Lista de agendamentos"""
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', 'all')
    
    query = Appointment.query
    
    if status_filter != 'all':
        query = query.filter_by(status=status_filter.upper())
    
    appointments = query.order_by(Appointment.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template_string(APPOINTMENTS_TEMPLATE,
        appointments=appointments,
        status_filter=status_filter,
        current_user=session
    )

@dashboard_bp.route('/admin/appointment/<int:appointment_id>')
@login_required
def appointment_detail(appointment_id):
    """Detalhes do agendamento"""
    appointment = Appointment.query.get_or_404(appointment_id)
    user = User.query.get(appointment.user_id)
    
    return render_template_string(APPOINTMENT_DETAIL_TEMPLATE,
        appointment=appointment,
        user=user,
        current_user=session
    )

@dashboard_bp.route('/admin/appointment/<int:appointment_id>/schedule', methods=['POST'])
@login_required
def schedule_appointment(appointment_id):
    """Agenda horários para exames"""
    appointment = Appointment.query.get_or_404(appointment_id)
    
    try:
        # Recebe dados do formulário
        schedule_data = {}
        exams = appointment.get_exams()
        
        for i, exam in enumerate(exams):
            exam_id = exam['exam_id']
            date = request.form.get(f'date_{i}')
            time = request.form.get(f'time_{i}')
            
            if date and time:
                schedule_data[exam_id] = {
                    'exam_name': exam['exam_name'],
                    'date': date,
                    'time': time,
                    'datetime': f"{date} {time}"
                }
        
        # Salva agendamentos
        appointment.scheduled_exams = json.dumps(schedule_data)
        appointment.status = 'CONFIRMED'
        appointment.scheduled_at = datetime.utcnow()
        appointment.scheduled_by = session['username']
        
        db.session.commit()
        
        # Envia confirmação para o cliente
        _send_schedule_confirmation(appointment, schedule_data)
        
        flash('Agendamento confirmado com sucesso!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao agendar: {str(e)}', 'error')
    
    return redirect(url_for('dashboard.appointment_detail', appointment_id=appointment_id))

@dashboard_bp.route('/admin/exams')
@master_required
def exams():
    """Gestão de exames (apenas master)"""
    page = request.args.get('page', 1, type=int)
    category_filter = request.args.get('category', 'all')
    
    query = Exam.query
    
    if category_filter != 'all':
        query = query.filter_by(category=category_filter)
    
    exams = query.order_by(Exam.exam_name).paginate(
        page=page, per_page=20, error_out=False
    )
    
    categories = db.session.query(Exam.category).distinct().all()
    categories = [cat[0] for cat in categories]
    
    return render_template_string(EXAMS_TEMPLATE,
        exams=exams,
        categories=categories,
        category_filter=category_filter,
        current_user=session
    )

@dashboard_bp.route('/admin/exam/add', methods=['GET', 'POST'])
@master_required
def add_exam():
    """Adicionar novo exame"""
    if request.method == 'POST':
        try:
            exam = Exam(
                exam_id=request.form['exam_id'],
                exam_name=request.form['exam_name'],
                category=request.form['category'],
                price_particular=float(request.form['price_particular']),
                price_funeraria=float(request.form['price_funeraria']),
                price_unimed=0.00,
                preparation_required=bool(request.form.get('preparation_required')),
                preparation_instructions=request.form.get('preparation_instructions'),
                active=True
            )
            
            db.session.add(exam)
            db.session.commit()
            
            flash('Exame adicionado com sucesso!', 'success')
            return redirect(url_for('dashboard.exams'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao adicionar exame: {str(e)}', 'error')
    
    return render_template_string(EXAM_FORM_TEMPLATE, 
        exam=None, 
        action='Adicionar',
        current_user=session
    )

@dashboard_bp.route('/admin/exam/<int:exam_id>/edit', methods=['GET', 'POST'])
@master_required
def edit_exam(exam_id):
    """Editar exame existente"""
    exam = Exam.query.get_or_404(exam_id)
    
    if request.method == 'POST':
        try:
            exam.exam_name = request.form['exam_name']
            exam.category = request.form['category']
            exam.price_particular = float(request.form['price_particular'])
            exam.price_funeraria = float(request.form['price_funeraria'])
            exam.preparation_required = bool(request.form.get('preparation_required'))
            exam.preparation_instructions = request.form.get('preparation_instructions')
            
            db.session.commit()
            
            flash('Exame atualizado com sucesso!', 'success')
            return redirect(url_for('dashboard.exams'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao atualizar exame: {str(e)}', 'error')
    
    return render_template_string(EXAM_FORM_TEMPLATE, 
        exam=exam, 
        action='Editar',
        current_user=session
    )

@dashboard_bp.route('/admin/exam/<int:exam_id>/delete', methods=['POST'])
@master_required
def delete_exam(exam_id):
    """Deletar exame"""
    exam = Exam.query.get_or_404(exam_id)
    
    try:
        exam.active = False  # Soft delete
        db.session.commit()
        flash('Exame removido com sucesso!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao remover exame: {str(e)}', 'error')
    
    return redirect(url_for('dashboard.exams'))

@dashboard_bp.route('/admin/users')
@master_required
def admin_users():
    """Gestão de usuários administrativos"""
    users = AdminUser.query.all()
    
    return render_template_string(ADMIN_USERS_TEMPLATE,
        users=users,
        current_user=session
    )

@dashboard_bp.route('/admin/user/add', methods=['GET', 'POST'])
@master_required
def add_admin_user():
    """Adicionar usuário administrativo"""
    if request.method == 'POST':
        try:
            user = AdminUser(
                username=request.form['username'],
                password_hash=generate_password_hash(request.form['password']),
                full_name=request.form['full_name'],
                email=request.form['email'],
                user_type=request.form['user_type'],
                can_manage_exams=bool(request.form.get('can_manage_exams')),
                can_manage_users=bool(request.form.get('can_manage_users')),
                can_view_reports=bool(request.form.get('can_view_reports')),
                can_schedule=bool(request.form.get('can_schedule')),
                active=True
            )
            
            db.session.add(user)
            db.session.commit()
            
            flash('Usuário adicionado com sucesso!', 'success')
            return redirect(url_for('dashboard.admin_users'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao adicionar usuário: {str(e)}', 'error')
    
    return render_template_string(ADMIN_USER_FORM_TEMPLATE,
        user=None,
        action='Adicionar',
        current_user=session
    )

@dashboard_bp.route('/admin/user/<int:user_id>/edit', methods=['GET', 'POST'])
@master_required
def edit_admin_user(user_id):
    """Editar usuário administrativo"""
    user = AdminUser.query.get_or_404(user_id)
    
    if request.method == 'POST':
        try:
            user.full_name = request.form['full_name']
            user.email = request.form['email']
            user.user_type = request.form['user_type']
            user.can_manage_exams = bool(request.form.get('can_manage_exams'))
            user.can_manage_users = bool(request.form.get('can_manage_users'))
            user.can_view_reports = bool(request.form.get('can_view_reports'))
            user.can_schedule = bool(request.form.get('can_schedule'))
            user.active = bool(request.form.get('active'))
            
            # Atualiza senha se fornecida
            if request.form.get('password'):
                user.password_hash = generate_password_hash(request.form['password'])
            
            db.session.commit()
            
            flash('Usuário atualizado com sucesso!', 'success')
            return redirect(url_for('dashboard.admin_users'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao atualizar usuário: {str(e)}', 'error')
    
    return render_template_string(ADMIN_USER_FORM_TEMPLATE,
        user=user,
        action='Editar',
        current_user=session
    )

@dashboard_bp.route('/admin/settings')
@master_required
def settings():
    """Configurações do sistema"""
    clinic = ClinicInfo.query.first()
    
    return render_template_string(SETTINGS_TEMPLATE,
        clinic=clinic,
        current_user=session
    )

@dashboard_bp.route('/admin/settings/clinic', methods=['POST'])
@master_required
def update_clinic_info():
    """Atualizar informações da clínica"""
    clinic = ClinicInfo.query.first()
    
    if not clinic:
        clinic = ClinicInfo()
        db.session.add(clinic)
    
    try:
        clinic.name = request.form['name']
        clinic.description = request.form['description']
        clinic.address = request.form['address']
        clinic.phone_call = request.form['phone_call']
        clinic.phone_whatsapp = request.form['phone_whatsapp']
        clinic.email = request.form['email']
        clinic.business_hours = request.form['business_hours']
        
        db.session.commit()
        
        flash('Informações da clínica atualizadas com sucesso!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao atualizar informações: {str(e)}', 'error')
    
    return redirect(url_for('dashboard.settings'))

def _send_schedule_confirmation(appointment, schedule_data):
    """Envia confirmação de agendamento para o cliente"""
    try:
        from src.services.telegram_service import TelegramService
        from src.services.email_service import EmailService
        
        user = User.query.get(appointment.user_id)
        
        # Monta mensagem de confirmação
        message_lines = ["✅ **Agendamento Confirmado!**\n"]
        message_lines.append("📋 **Seus exames foram agendados:**\n")
        
        for exam_id, schedule in schedule_data.items():
            message_lines.append(f"• **{schedule['exam_name']}**")
            message_lines.append(f"  📅 {schedule['date']} às {schedule['time']}\n")
        
        message_lines.append("📍 **Local:** ECOS - Rua São Paulo, 407 - Lençóis Paulista")
        message_lines.append("📞 **Contato:** (14) 3436-2300")
        
        if appointment.preparation_instructions:
            message_lines.append(f"\n🔬 **Instruções de preparo:**\n{appointment.preparation_instructions}")
        
        message_text = "\n".join(message_lines)
        
        # Envia via Telegram se disponível
        if user.telegram_id:
            telegram = TelegramService()
            telegram.send_message(user.telegram_id, message_text)
        
        # Envia email de notificação
        email = EmailService()
        email.send_email(
            to_email="contato@onindigital.com.br",
            subject=f"Agendamento Confirmado - {user.name}",
            body=f"Agendamento confirmado para {user.name}\n\n{message_text}"
        )
        
    except Exception as e:
        print(f"Erro ao enviar confirmação: {e}")

# Templates HTML
DASHBOARD_TEMPLATE = '''
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - ECOS Chatbot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5rem; }
        .user-info { display: flex; align-items: center; gap: 1rem; }
        .nav {
            background: white;
            padding: 0 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .nav ul {
            list-style: none;
            display: flex;
            gap: 2rem;
        }
        .nav a {
            display: block;
            padding: 1rem 0;
            text-decoration: none;
            color: #333;
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
        }
        .nav a:hover, .nav a.active {
            color: #667eea;
            border-bottom-color: #667eea;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-card h3 {
            font-size: 2rem;
            color: #667eea;
            margin-bottom: 0.5rem;
        }
        .stat-card p {
            color: #666;
            font-weight: 600;
        }
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .card-header {
            background: #f8f9fa;
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #e9ecef;
            font-weight: 600;
        }
        .card-body {
            padding: 1.5rem;
        }
        .appointment-item {
            padding: 1rem;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .appointment-item:last-child {
            border-bottom: none;
        }
        .status {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .status.pending {
            background: #fff3cd;
            color: #856404;
        }
        .status.confirmed {
            background: #d4edda;
            color: #155724;
        }
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .alert {
            padding: 0.75rem 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🏥 ECOS - Dashboard</h1>
        <div class="user-info">
            <span>{{ current_user.username }}</span>
            <a href="{{ url_for('auth.logout') }}" class="btn btn-secondary">Sair</a>
        </div>
    </div>
    
    <nav class="nav">
        <ul>
            <li><a href="{{ url_for('dashboard.index') }}" class="active">Dashboard</a></li>
            <li><a href="{{ url_for('dashboard.appointments') }}">Agendamentos</a></li>
            {% if current_user.user_type == 'MASTER' %}
            <li><a href="{{ url_for('dashboard.exams') }}">Exames</a></li>
            <li><a href="{{ url_for('dashboard.admin_users') }}">Usuários</a></li>
            <li><a href="{{ url_for('dashboard.settings') }}">Configurações</a></li>
            {% endif %}
            <li><a href="{{ url_for('auth.change_password') }}">Alterar Senha</a></li>
        </ul>
    </nav>
    
    <div class="container">
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="alert alert-{{ 'error' if category == 'error' else 'success' }}">
                        {{ message }}
                    </div>
                {% endfor %}
            {% endif %}
        {% endwith %}
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>{{ total_users }}</h3>
                <p>Total de Usuários</p>
            </div>
            <div class="stat-card">
                <h3>{{ total_appointments }}</h3>
                <p>Total de Agendamentos</p>
            </div>
            <div class="stat-card">
                <h3>{{ pending_appointments }}</h3>
                <p>Pendentes</p>
            </div>
            <div class="stat-card">
                <h3>{{ confirmed_appointments }}</h3>
                <p>Confirmados</p>
            </div>
        </div>
        
        <div class="content-grid">
            <div class="card">
                <div class="card-header">
                    📅 Agendamentos Recentes
                </div>
                <div class="card-body">
                    {% for appointment in recent_appointments %}
                    <div class="appointment-item">
                        <div>
                            <strong>{{ appointment.user.name or 'Cliente' }}</strong><br>
                            <small>{{ appointment.created_at.strftime('%d/%m/%Y %H:%M') }}</small>
                        </div>
                        <div>
                            <span class="status {{ appointment.status.lower() }}">
                                {{ 'Pendente' if appointment.status == 'PENDING' else 'Confirmado' }}
                            </span>
                            <a href="{{ url_for('dashboard.appointment_detail', appointment_id=appointment.id) }}" class="btn btn-primary">Ver</a>
                        </div>
                    </div>
                    {% endfor %}
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    📊 Estatísticas
                </div>
                <div class="card-body">
                    <h4>Usuários por Plataforma</h4>
                    <p>📱 Telegram: {{ telegram_users }}</p>
                    <p>💬 WhatsApp: {{ whatsapp_users }}</p>
                    <p>📘 Facebook: {{ facebook_users }}</p>
                    
                    <h4 style="margin-top: 1.5rem;">Exames Mais Solicitados</h4>
                    {% for exam_name, count in exam_stats %}
                    <p>{{ exam_name }}: {{ count }}</p>
                    {% endfor %}
                </div>
            </div>
        </div>
    </div>
</body>
</html>
'''

APPOINTMENTS_TEMPLATE = '''
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamentos - ECOS Chatbot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5rem; }
        .user-info { display: flex; align-items: center; gap: 1rem; }
        .nav {
            background: white;
            padding: 0 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .nav ul {
            list-style: none;
            display: flex;
            gap: 2rem;
        }
        .nav a {
            display: block;
            padding: 1rem 0;
            text-decoration: none;
            color: #333;
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
        }
        .nav a:hover, .nav a.active {
            color: #667eea;
            border-bottom-color: #667eea;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .filters {
            background: white;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .filters select {
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-right: 1rem;
        }
        .table-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
        }
        .status {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .status.pending {
            background: #fff3cd;
            color: #856404;
        }
        .status.confirmed {
            background: #d4edda;
            color: #155724;
        }
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            cursor: pointer;
            margin-right: 0.5rem;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 2rem;
        }
        .pagination a {
            padding: 0.5rem 1rem;
            text-decoration: none;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #333;
        }
        .pagination a.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🏥 ECOS - Agendamentos</h1>
        <div class="user-info">
            <span>{{ current_user.username }}</span>
            <a href="{{ url_for('auth.logout') }}" class="btn btn-secondary">Sair</a>
        </div>
    </div>
    
    <nav class="nav">
        <ul>
            <li><a href="{{ url_for('dashboard.index') }}">Dashboard</a></li>
            <li><a href="{{ url_for('dashboard.appointments') }}" class="active">Agendamentos</a></li>
            {% if current_user.user_type == 'MASTER' %}
            <li><a href="{{ url_for('dashboard.exams') }}">Exames</a></li>
            <li><a href="{{ url_for('dashboard.admin_users') }}">Usuários</a></li>
            <li><a href="{{ url_for('dashboard.settings') }}">Configurações</a></li>
            {% endif %}
            <li><a href="{{ url_for('auth.change_password') }}">Alterar Senha</a></li>
        </ul>
    </nav>
    
    <div class="container">
        <div class="filters">
            <form method="GET">
                <select name="status" onchange="this.form.submit()">
                    <option value="all" {{ 'selected' if status_filter == 'all' else '' }}>Todos os Status</option>
                    <option value="pending" {{ 'selected' if status_filter == 'pending' else '' }}>Pendentes</option>
                    <option value="confirmed" {{ 'selected' if status_filter == 'confirmed' else '' }}>Confirmados</option>
                </select>
            </form>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Cliente</th>
                        <th>Data/Hora</th>
                        <th>Convênio</th>
                        <th>Exames</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    {% for appointment in appointments.items %}
                    <tr>
                        <td>
                            <strong>{{ appointment.user.name or 'N/A' }}</strong><br>
                            <small>{{ appointment.user.cpf or 'CPF não informado' }}</small>
                        </td>
                        <td>{{ appointment.created_at.strftime('%d/%m/%Y %H:%M') }}</td>
                        <td>{{ appointment.covenant_type }}</td>
                        <td>{{ appointment.get_exams()|length }} exame(s)</td>
                        <td>
                            <span class="status {{ appointment.status.lower() }}">
                                {{ 'Pendente' if appointment.status == 'PENDING' else 'Confirmado' }}
                            </span>
                        </td>
                        <td>
                            <a href="{{ url_for('dashboard.appointment_detail', appointment_id=appointment.id) }}" class="btn btn-primary">Ver Detalhes</a>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        
        {% if appointments.pages > 1 %}
        <div class="pagination">
            {% for page_num in appointments.iter_pages() %}
                {% if page_num %}
                    {% if page_num != appointments.page %}
                        <a href="{{ url_for('dashboard.appointments', page=page_num, status=status_filter) }}">{{ page_num }}</a>
                    {% else %}
                        <a href="#" class="active">{{ page_num }}</a>
                    {% endif %}
                {% endif %}
            {% endfor %}
        </div>
        {% endif %}
    </div>
</body>
</html>
'''

APPOINTMENT_DETAIL_TEMPLATE = '''
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Agendamento - ECOS Chatbot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5rem; }
        .container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
            overflow: hidden;
        }
        .card-header {
            background: #f8f9fa;
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #e9ecef;
            font-weight: 600;
        }
        .card-body {
            padding: 1.5rem;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .info-item {
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .info-item strong {
            display: block;
            color: #667eea;
            margin-bottom: 0.5rem;
        }
        .exam-list {
            list-style: none;
        }
        .exam-list li {
            padding: 0.75rem;
            border: 1px solid #e9ecef;
            border-radius: 5px;
            margin-bottom: 0.5rem;
            background: #f8f9fa;
        }
        .schedule-form {
            background: #fff3cd;
            padding: 1.5rem;
            border-radius: 10px;
            margin-top: 1rem;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        .form-group input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            cursor: pointer;
            margin-right: 1rem;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .btn-success {
            background: #28a745;
            color: white;
        }
        .status {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            display: inline-block;
        }
        .status.pending {
            background: #fff3cd;
            color: #856404;
        }
        .status.confirmed {
            background: #d4edda;
            color: #155724;
        }
        .scheduled-exams {
            background: #d4edda;
            padding: 1rem;
            border-radius: 5px;
            margin-top: 1rem;
        }
        .scheduled-exams h4 {
            color: #155724;
            margin-bottom: 1rem;
        }
        .scheduled-exam {
            padding: 0.5rem;
            background: white;
            border-radius: 5px;
            margin-bottom: 0.5rem;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>📋 Detalhes do Agendamento</h1>
        <a href="{{ url_for('dashboard.appointments') }}" class="btn btn-secondary">Voltar</a>
    </div>
    
    <div class="container">
        <div class="card">
            <div class="card-header">
                👤 Informações do Cliente
            </div>
            <div class="card-body">
                <div class="info-grid">
                    <div class="info-item">
                        <strong>Nome:</strong>
                        {{ user.name or 'Não informado' }}
                    </div>
                    <div class="info-item">
                        <strong>CPF:</strong>
                        {{ user.cpf or 'Não informado' }}
                    </div>
                    <div class="info-item">
                        <strong>Data de Nascimento:</strong>
                        {{ user.birth_date or 'Não informado' }}
                    </div>
                    <div class="info-item">
                        <strong>Convênio:</strong>
                        {{ appointment.covenant_type }}
                    </div>
                    <div class="info-item">
                        <strong>Data da Solicitação:</strong>
                        {{ appointment.created_at.strftime('%d/%m/%Y %H:%M') }}
                    </div>
                    <div class="info-item">
                        <strong>Status:</strong>
                        <span class="status {{ appointment.status.lower() }}">
                            {{ 'Pendente' if appointment.status == 'PENDING' else 'Confirmado' }}
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                🔬 Exames Solicitados
            </div>
            <div class="card-body">
                <ul class="exam-list">
                    {% for exam in appointment.get_exams() %}
                    <li>
                        <strong>{{ exam.exam_name }}</strong><br>
                        <small>Categoria: {{ exam.category }}</small><br>
                        {% if appointment.covenant_type != 'UNIMED' %}
                        <small>Valor: R$ {{ "%.2f"|format(exam.price) }}</small>
                        {% else %}
                        <small>Valor: Coberto pelo plano</small>
                        {% endif %}
                    </li>
                    {% endfor %}
                </ul>
                
                {% if appointment.covenant_type != 'UNIMED' %}
                <p><strong>Total: R$ {{ "%.2f"|format(appointment.total_price) }}</strong></p>
                {% endif %}
                
                {% if appointment.preparation_instructions %}
                <div style="margin-top: 1rem; padding: 1rem; background: #e7f3ff; border-radius: 5px;">
                    <strong>Instruções de Preparo:</strong><br>
                    {{ appointment.preparation_instructions|replace('\n', '<br>')|safe }}
                </div>
                {% endif %}
            </div>
        </div>
        
        {% if appointment.status == 'PENDING' %}
        <div class="card">
            <div class="card-header">
                📅 Agendar Horários
            </div>
            <div class="card-body">
                <div class="schedule-form">
                    <h4>⚠️ Defina data e horário para cada exame:</h4>
                    <form method="POST" action="{{ url_for('dashboard.schedule_appointment', appointment_id=appointment.id) }}">
                        {% for exam in appointment.get_exams() %}
                        <div class="form-group">
                            <label>{{ exam.exam_name }}:</label>
                            <div class="form-row">
                                <input type="date" name="date_{{ loop.index0 }}" required>
                                <input type="time" name="time_{{ loop.index0 }}" required>
                            </div>
                        </div>
                        {% endfor %}
                        
                        <button type="submit" class="btn btn-success">✅ Confirmar Agendamentos</button>
                    </form>
                </div>
            </div>
        </div>
        {% endif %}
        
        {% if appointment.status == 'CONFIRMED' and appointment.scheduled_exams %}
        <div class="card">
            <div class="card-header">
                ✅ Agendamentos Confirmados
            </div>
            <div class="card-body">
                <div class="scheduled-exams">
                    <h4>Horários Agendados:</h4>
                    {% for exam_id, schedule in appointment.get_scheduled_exams().items() %}
                    <div class="scheduled-exam">
                        <strong>{{ schedule.exam_name }}</strong><br>
                        📅 {{ schedule.date }} às {{ schedule.time }}
                    </div>
                    {% endfor %}
                    
                    <p style="margin-top: 1rem;">
                        <strong>Agendado por:</strong> {{ appointment.scheduled_by }}<br>
                        <strong>Data do agendamento:</strong> {{ appointment.scheduled_at.strftime('%d/%m/%Y %H:%M') if appointment.scheduled_at else 'N/A' }}
                    </p>
                </div>
            </div>
        </div>
        {% endif %}
    </div>
</body>
</html>
'''

EXAMS_TEMPLATE = '''
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Exames - ECOS Chatbot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5rem; }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .filters select {
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .table-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
        }
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            cursor: pointer;
            margin-right: 0.5rem;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-success {
            background: #28a745;
            color: white;
        }
        .btn-warning {
            background: #ffc107;
            color: #212529;
        }
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🔬 Gestão de Exames</h1>
        <a href="{{ url_for('dashboard.index') }}" class="btn btn-secondary">Voltar ao Dashboard</a>
    </div>
    
    <div class="container">
        <div class="actions">
            <div class="filters">
                <form method="GET" style="display: inline;">
                    <select name="category" onchange="this.form.submit()">
                        <option value="all" {{ 'selected' if category_filter == 'all' else '' }}>Todas as Categorias</option>
                        {% for category in categories %}
                        <option value="{{ category }}" {{ 'selected' if category_filter == category else '' }}>{{ category }}</option>
                        {% endfor %}
                    </select>
                </form>
            </div>
            <a href="{{ url_for('dashboard.add_exam') }}" class="btn btn-success">➕ Adicionar Exame</a>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome do Exame</th>
                        <th>Categoria</th>
                        <th>Preço Particular</th>
                        <th>Preço Funerária</th>
                        <th>Preparo</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    {% for exam in exams.items %}
                    <tr>
                        <td>{{ exam.exam_id }}</td>
                        <td>{{ exam.exam_name }}</td>
                        <td>{{ exam.category }}</td>
                        <td>R$ {{ "%.2f"|format(exam.price_particular) }}</td>
                        <td>R$ {{ "%.2f"|format(exam.price_funeraria) }}</td>
                        <td>{{ '✅' if exam.preparation_required else '❌' }}</td>
                        <td>
                            <a href="{{ url_for('dashboard.edit_exam', exam_id=exam.id) }}" class="btn btn-warning">Editar</a>
                            <form method="POST" action="{{ url_for('dashboard.delete_exam', exam_id=exam.id) }}" style="display: inline;" onsubmit="return confirm('Tem certeza que deseja remover este exame?')">
                                <button type="submit" class="btn btn-danger">Remover</button>
                            </form>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
'''

EXAM_FORM_TEMPLATE = '''
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ action }} Exame - ECOS Chatbot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5rem; }
        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 2rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        .form-group textarea {
            height: 100px;
            resize: vertical;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .checkbox-group input[type="checkbox"] {
            width: auto;
        }
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            cursor: pointer;
            margin-right: 1rem;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ action }} Exame</h1>
        <a href="{{ url_for('dashboard.exams') }}" class="btn btn-secondary">Voltar</a>
    </div>
    
    <div class="container">
        <div class="card">
            <form method="POST">
                <div class="form-group">
                    <label for="exam_id">ID do Exame:</label>
                    <input type="text" id="exam_id" name="exam_id" value="{{ exam.exam_id if exam else '' }}" {{ 'readonly' if exam else 'required' }}>
                </div>
                
                <div class="form-group">
                    <label for="exam_name">Nome do Exame:</label>
                    <input type="text" id="exam_name" name="exam_name" value="{{ exam.exam_name if exam else '' }}" required>
                </div>
                
                <div class="form-group">
                    <label for="category">Categoria:</label>
                    <input type="text" id="category" name="category" value="{{ exam.category if exam else '' }}" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="price_particular">Preço Particular (R$):</label>
                        <input type="number" step="0.01" id="price_particular" name="price_particular" value="{{ exam.price_particular if exam else '' }}" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="price_funeraria">Preço Funerária (R$):</label>
                        <input type="number" step="0.01" id="price_funeraria" name="price_funeraria" value="{{ exam.price_funeraria if exam else '' }}" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <div class="checkbox-group">
                        <input type="checkbox" id="preparation_required" name="preparation_required" {{ 'checked' if exam and exam.preparation_required else '' }}>
                        <label for="preparation_required">Requer preparo</label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="preparation_instructions">Instruções de Preparo:</label>
                    <textarea id="preparation_instructions" name="preparation_instructions">{{ exam.preparation_instructions if exam else '' }}</textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">{{ action }} Exame</button>
                <a href="{{ url_for('dashboard.exams') }}" class="btn btn-secondary">Cancelar</a>
            </form>
        </div>
    </div>
</body>
</html>
'''

ADMIN_USERS_TEMPLATE = '''
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Usuários - ECOS Chatbot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5rem; }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .actions {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 2rem;
        }
        .table-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
        }
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            cursor: pointer;
            margin-right: 0.5rem;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-success {
            background: #28a745;
            color: white;
        }
        .btn-warning {
            background: #ffc107;
            color: #212529;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .badge {
            padding: 0.25rem 0.5rem;
            border-radius: 10px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .badge-master {
            background: #dc3545;
            color: white;
        }
        .badge-operator {
            background: #17a2b8;
            color: white;
        }
        .status-active {
            color: #28a745;
        }
        .status-inactive {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>👥 Gestão de Usuários</h1>
        <a href="{{ url_for('dashboard.index') }}" class="btn btn-secondary">Voltar ao Dashboard</a>
    </div>
    
    <div class="container">
        <div class="actions">
            <a href="{{ url_for('dashboard.add_admin_user') }}" class="btn btn-success">➕ Adicionar Usuário</a>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Usuário</th>
                        <th>Nome Completo</th>
                        <th>Email</th>
                        <th>Tipo</th>
                        <th>Status</th>
                        <th>Último Login</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    {% for user in users %}
                    <tr>
                        <td>{{ user.username }}</td>
                        <td>{{ user.full_name }}</td>
                        <td>{{ user.email }}</td>
                        <td>
                            <span class="badge badge-{{ 'master' if user.user_type == 'MASTER' else 'operator' }}">
                                {{ 'Master' if user.user_type == 'MASTER' else 'Operador' }}
                            </span>
                        </td>
                        <td>
                            <span class="status-{{ 'active' if user.active else 'inactive' }}">
                                {{ 'Ativo' if user.active else 'Inativo' }}
                            </span>
                        </td>
                        <td>{{ user.last_login.strftime('%d/%m/%Y %H:%M') if user.last_login else 'Nunca' }}</td>
                        <td>
                            <a href="{{ url_for('dashboard.edit_admin_user', user_id=user.id) }}" class="btn btn-warning">Editar</a>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
'''

ADMIN_USER_FORM_TEMPLATE = '''
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ action }} Usuário - ECOS Chatbot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5rem; }
        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 2rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-top: 0.5rem;
        }
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .checkbox-item input[type="checkbox"] {
            width: auto;
        }
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            cursor: pointer;
            margin-right: 1rem;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .permissions-section {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 5px;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ action }} Usuário</h1>
        <a href="{{ url_for('dashboard.admin_users') }}" class="btn btn-secondary">Voltar</a>
    </div>
    
    <div class="container">
        <div class="card">
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="username">Nome de Usuário:</label>
                        <input type="text" id="username" name="username" value="{{ user.username if user else '' }}" {{ 'readonly' if user else 'required' }}>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">{{ 'Nova Senha (deixe vazio para manter)' if user else 'Senha' }}:</label>
                        <input type="password" id="password" name="password" {{ 'required' if not user else '' }}>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="full_name">Nome Completo:</label>
                    <input type="text" id="full_name" name="full_name" value="{{ user.full_name if user else '' }}" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="{{ user.email if user else '' }}" required>
                </div>
                
                <div class="form-group">
                    <label for="user_type">Tipo de Usuário:</label>
                    <select id="user_type" name="user_type" required>
                        <option value="OPERATOR" {{ 'selected' if user and user.user_type == 'OPERATOR' else '' }}>Operador</option>
                        <option value="MASTER" {{ 'selected' if user and user.user_type == 'MASTER' else '' }}>Master</option>
                    </select>
                </div>
                
                <div class="permissions-section">
                    <label>Permissões:</label>
                    <div class="checkbox-group">
                        <div class="checkbox-item">
                            <input type="checkbox" id="can_schedule" name="can_schedule" {{ 'checked' if user and user.can_schedule else 'checked' }}>
                            <label for="can_schedule">Pode agendar</label>
                        </div>
                        
                        <div class="checkbox-item">
                            <input type="checkbox" id="can_manage_exams" name="can_manage_exams" {{ 'checked' if user and user.can_manage_exams else '' }}>
                            <label for="can_manage_exams">Gerenciar exames</label>
                        </div>
                        
                        <div class="checkbox-item">
                            <input type="checkbox" id="can_manage_users" name="can_manage_users" {{ 'checked' if user and user.can_manage_users else '' }}>
                            <label for="can_manage_users">Gerenciar usuários</label>
                        </div>
                        
                        <div class="checkbox-item">
                            <input type="checkbox" id="can_view_reports" name="can_view_reports" {{ 'checked' if user and user.can_view_reports else '' }}>
                            <label for="can_view_reports">Ver relatórios</label>
                        </div>
                        
                        {% if user %}
                        <div class="checkbox-item">
                            <input type="checkbox" id="active" name="active" {{ 'checked' if user.active else '' }}>
                            <label for="active">Usuário ativo</label>
                        </div>
                        {% endif %}
                    </div>
                </div>
                
                <div style="margin-top: 2rem;">
                    <button type="submit" class="btn btn-primary">{{ action }} Usuário</button>
                    <a href="{{ url_for('dashboard.admin_users') }}" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
'''

SETTINGS_TEMPLATE = '''
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações - ECOS Chatbot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5rem; }
        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
            overflow: hidden;
        }
        .card-header {
            background: #f8f9fa;
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #e9ecef;
            font-weight: 600;
        }
        .card-body {
            padding: 1.5rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        .form-group textarea {
            height: 100px;
            resize: vertical;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            cursor: pointer;
            margin-right: 1rem;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>⚙️ Configurações</h1>
        <a href="{{ url_for('dashboard.index') }}" class="btn btn-secondary">Voltar ao Dashboard</a>
    </div>
    
    <div class="container">
        <div class="card">
            <div class="card-header">
                🏥 Informações da Clínica
            </div>
            <div class="card-body">
                <form method="POST" action="{{ url_for('dashboard.update_clinic_info') }}">
                    <div class="form-group">
                        <label for="name">Nome da Clínica:</label>
                        <input type="text" id="name" name="name" value="{{ clinic.name if clinic else 'ECOS - Radiologia e Diagnóstico' }}" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Descrição:</label>
                        <textarea id="description" name="description" required>{{ clinic.description if clinic else 'ECOS - Radiologia e Diagnóstico por imagem com tecnologia de ponta, médicos especialistas (RQE) e atendimento humanizado. Precisão, cuidado e conforto em cada exame.' }}</textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Endereço:</label>
                        <input type="text" id="address" name="address" value="{{ clinic.address if clinic else 'Rua São Paulo, 407 - Lençóis Paulista - CEP 18.682-049' }}" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="phone_call">Telefone (ligações):</label>
                            <input type="text" id="phone_call" name="phone_call" value="{{ clinic.phone_call if clinic else '(14) 3436-2300' }}" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone_whatsapp">WhatsApp (mensagens):</label>
                            <input type="text" id="phone_whatsapp" name="phone_whatsapp" value="{{ clinic.phone_whatsapp if clinic else '(14) 98171-3057' }}" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="{{ clinic.email if clinic else 'contato@onindigital.com.br' }}" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="business_hours">Horário de Funcionamento:</label>
                        <input type="text" id="business_hours" name="business_hours" value="{{ clinic.business_hours if clinic else 'Segunda a Sexta: 7h às 18h | Sábado: 7h às 12h' }}" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
'''

