from flask import Blueprint, request, jsonify, current_app
import json
import hmac
import hashlib
from datetime import datetime
from src.models.multi_tenant import db, User, Appointment, Clinic, ChatLog
from src.services.telegram_service import TelegramService
from src.services.whatsapp_service import WhatsAppService
from src.services.meta_service import MetaService
from src.services.chatbot_handler import ChatbotHandler
from src.utils.multi_tenant import MultiTenantManager

webhook_omnichannel_bp = Blueprint('webhook_omnichannel', __name__)

@webhook_omnichannel_bp.route('/telegram/<clinic_slug>', methods=['POST'])
def telegram_webhook(clinic_slug):
    """Webhook para receber mensagens do Telegram"""
    try:
        # Define clínica atual
        MultiTenantManager.set_current_clinic_slug(clinic_slug)
        clinic = MultiTenantManager.get_current_clinic()
        
        if not clinic or not clinic.active:
            return jsonify({'error': 'Clínica não encontrada ou inativa'}), 404
        
        # Obtém dados do webhook
        webhook_data = request.get_json()
        
        if not webhook_data:
            return jsonify({'error': 'Dados inválidos'}), 400
        
        # Processa mensagem via Telegram Service
        telegram_service = TelegramService.get_clinic_telegram_service(clinic_slug)
        if not telegram_service:
            return jsonify({'error': 'Serviço Telegram não configurado'}), 500
        
        # Extrai informações da mensagem
        message_data = telegram_service.process_webhook_message(webhook_data)
        
        if message_data:
            # Processa via ChatbotHandler
            chatbot_handler = ChatbotHandler()
            response = chatbot_handler.process_omnichannel_message(message_data)
            
            # Log da interação
            log_interaction(clinic.id, message_data, response)
            
            return jsonify({'status': 'success', 'processed': True})
        
        return jsonify({'status': 'success', 'processed': False})
        
    except Exception as e:
        print(f"Erro no webhook Telegram: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@webhook_omnichannel_bp.route('/whatsapp/<clinic_slug>', methods=['POST'])
def whatsapp_webhook(clinic_slug):
    """Webhook para receber mensagens do WhatsApp"""
    try:
        # Define clínica atual
        MultiTenantManager.set_current_clinic_slug(clinic_slug)
        clinic = MultiTenantManager.get_current_clinic()
        
        if not clinic or not clinic.active:
            return jsonify({'error': 'Clínica não encontrada ou inativa'}), 404
        
        # Obtém dados do webhook
        webhook_data = request.get_json()
        
        if not webhook_data:
            return jsonify({'error': 'Dados inválidos'}), 400
        
        # Processa mensagem via WhatsApp Service
        whatsapp_service = WhatsAppService.get_clinic_whatsapp_service(clinic_slug)
        if not whatsapp_service:
            return jsonify({'error': 'Serviço WhatsApp não configurado'}), 500
        
        # Extrai informações da mensagem
        message_data = whatsapp_service.process_webhook_message(webhook_data)
        
        if message_data:
            # Processa via ChatbotHandler
            chatbot_handler = ChatbotHandler()
            response = chatbot_handler.process_omnichannel_message(message_data)
            
            # Log da interação
            log_interaction(clinic.id, message_data, response)
            
            return jsonify({'status': 'success', 'processed': True})
        
        return jsonify({'status': 'success', 'processed': False})
        
    except Exception as e:
        print(f"Erro no webhook WhatsApp: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@webhook_omnichannel_bp.route('/whatsapp/<clinic_slug>/verify', methods=['GET'])
def whatsapp_webhook_verify(clinic_slug):
    """Verificação do webhook WhatsApp (se necessário)"""
    try:
        verify_token = request.args.get('hub.verify_token')
        challenge = request.args.get('hub.challenge')
        
        # Verifica token (configurar conforme necessário)
        expected_token = current_app.config.get('WHATSAPP_VERIFY_TOKEN', 'ecos_whatsapp_verify')
        
        if verify_token == expected_token:
            return challenge
        else:
            return 'Token inválido', 403
            
    except Exception as e:
        print(f"Erro na verificação webhook WhatsApp: {e}")
        return 'Erro', 500

@webhook_omnichannel_bp.route('/facebook/<clinic_slug>', methods=['POST'])
def facebook_webhook(clinic_slug):
    """Webhook para receber mensagens do Facebook"""
    try:
        # Define clínica atual
        MultiTenantManager.set_current_clinic_slug(clinic_slug)
        clinic = MultiTenantManager.get_current_clinic()
        
        if not clinic or not clinic.active:
            return jsonify({'error': 'Clínica não encontrada ou inativa'}), 404
        
        # Verifica assinatura do webhook
        signature = request.headers.get('X-Hub-Signature-256')
        if signature:
            meta_service = MetaService.get_clinic_meta_service(clinic_slug)
            if meta_service and not meta_service.verify_webhook_signature(request.data, signature):
                return jsonify({'error': 'Assinatura inválida'}), 403
        
        # Obtém dados do webhook
        webhook_data = request.get_json()
        
        if not webhook_data:
            return jsonify({'error': 'Dados inválidos'}), 400
        
        # Processa mensagem via Meta Service
        meta_service = MetaService.get_clinic_meta_service(clinic_slug)
        if not meta_service:
            return jsonify({'error': 'Serviço Facebook não configurado'}), 500
        
        # Extrai informações da mensagem
        message_data = meta_service.process_facebook_webhook(webhook_data)
        
        if message_data:
            # Processa via ChatbotHandler
            chatbot_handler = ChatbotHandler()
            response = chatbot_handler.process_omnichannel_message(message_data)
            
            # Log da interação
            log_interaction(clinic.id, message_data, response)
            
            return jsonify({'status': 'success', 'processed': True})
        
        return jsonify({'status': 'success', 'processed': False})
        
    except Exception as e:
        print(f"Erro no webhook Facebook: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@webhook_omnichannel_bp.route('/facebook/<clinic_slug>/verify', methods=['GET'])
def facebook_webhook_verify(clinic_slug):
    """Verificação do webhook Facebook"""
    try:
        verify_token = request.args.get('hub.verify_token')
        challenge = request.args.get('hub.challenge')
        mode = request.args.get('hub.mode')
        
        # Obtém token de verificação da clínica
        clinic = Clinic.query.filter_by(slug=clinic_slug, active=True).first()
        if not clinic:
            return 'Clínica não encontrada', 404
        
        expected_token = clinic.facebook_verify_token or current_app.config.get('META_VERIFY_TOKEN')
        
        if mode == 'subscribe' and verify_token == expected_token:
            return challenge
        else:
            return 'Token inválido', 403
            
    except Exception as e:
        print(f"Erro na verificação webhook Facebook: {e}")
        return 'Erro', 500

@webhook_omnichannel_bp.route('/instagram/<clinic_slug>', methods=['POST'])
def instagram_webhook(clinic_slug):
    """Webhook para receber mensagens do Instagram"""
    try:
        # Define clínica atual
        MultiTenantManager.set_current_clinic_slug(clinic_slug)
        clinic = MultiTenantManager.get_current_clinic()
        
        if not clinic or not clinic.active:
            return jsonify({'error': 'Clínica não encontrada ou inativa'}), 404
        
        # Verifica assinatura do webhook
        signature = request.headers.get('X-Hub-Signature-256')
        if signature:
            meta_service = MetaService.get_clinic_meta_service(clinic_slug)
            if meta_service and not meta_service.verify_webhook_signature(request.data, signature):
                return jsonify({'error': 'Assinatura inválida'}), 403
        
        # Obtém dados do webhook
        webhook_data = request.get_json()
        
        if not webhook_data:
            return jsonify({'error': 'Dados inválidos'}), 400
        
        # Processa mensagem via Meta Service
        meta_service = MetaService.get_clinic_meta_service(clinic_slug)
        if not meta_service:
            return jsonify({'error': 'Serviço Instagram não configurado'}), 500
        
        # Extrai informações da mensagem
        message_data = meta_service.process_instagram_webhook(webhook_data)
        
        if message_data:
            # Processa via ChatbotHandler
            chatbot_handler = ChatbotHandler()
            response = chatbot_handler.process_omnichannel_message(message_data)
            
            # Log da interação
            log_interaction(clinic.id, message_data, response)
            
            return jsonify({'status': 'success', 'processed': True})
        
        return jsonify({'status': 'success', 'processed': False})
        
    except Exception as e:
        print(f"Erro no webhook Instagram: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@webhook_omnichannel_bp.route('/instagram/<clinic_slug>/verify', methods=['GET'])
def instagram_webhook_verify(clinic_slug):
    """Verificação do webhook Instagram"""
    try:
        verify_token = request.args.get('hub.verify_token')
        challenge = request.args.get('hub.challenge')
        mode = request.args.get('hub.mode')
        
        # Obtém token de verificação da clínica
        clinic = Clinic.query.filter_by(slug=clinic_slug, active=True).first()
        if not clinic:
            return 'Clínica não encontrada', 404
        
        expected_token = clinic.instagram_verify_token or current_app.config.get('META_VERIFY_TOKEN')
        
        if mode == 'subscribe' and verify_token == expected_token:
            return challenge
        else:
            return 'Token inválido', 403
            
    except Exception as e:
        print(f"Erro na verificação webhook Instagram: {e}")
        return 'Erro', 500

@webhook_omnichannel_bp.route('/unified/<clinic_slug>', methods=['POST'])
def unified_webhook(clinic_slug):
    """Webhook unificado para todas as plataformas"""
    try:
        # Define clínica atual
        MultiTenantManager.set_current_clinic_slug(clinic_slug)
        clinic = MultiTenantManager.get_current_clinic()
        
        if not clinic or not clinic.active:
            return jsonify({'error': 'Clínica não encontrada ou inativa'}), 404
        
        # Obtém dados do webhook
        webhook_data = request.get_json()
        
        if not webhook_data:
            return jsonify({'error': 'Dados inválidos'}), 400
        
        # Identifica plataforma baseado nos dados
        platform = identify_platform(webhook_data, request.headers)
        
        if not platform:
            return jsonify({'error': 'Plataforma não identificada'}), 400
        
        # Processa baseado na plataforma
        message_data = None
        
        if platform == 'telegram':
            telegram_service = TelegramService.get_clinic_telegram_service(clinic_slug)
            if telegram_service:
                message_data = telegram_service.process_webhook_message(webhook_data)
        
        elif platform == 'whatsapp':
            whatsapp_service = WhatsAppService.get_clinic_whatsapp_service(clinic_slug)
            if whatsapp_service:
                message_data = whatsapp_service.process_webhook_message(webhook_data)
        
        elif platform in ['facebook', 'instagram']:
            meta_service = MetaService.get_clinic_meta_service(clinic_slug)
            if meta_service:
                if platform == 'facebook':
                    message_data = meta_service.process_facebook_webhook(webhook_data)
                else:
                    message_data = meta_service.process_instagram_webhook(webhook_data)
        
        if message_data:
            # Processa via ChatbotHandler
            chatbot_handler = ChatbotHandler()
            response = chatbot_handler.process_omnichannel_message(message_data)
            
            # Log da interação
            log_interaction(clinic.id, message_data, response)
            
            return jsonify({'status': 'success', 'platform': platform, 'processed': True})
        
        return jsonify({'status': 'success', 'platform': platform, 'processed': False})
        
    except Exception as e:
        print(f"Erro no webhook unificado: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@webhook_omnichannel_bp.route('/health', methods=['GET'])
def health_check():
    """Health check para webhooks"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'webhooks': {
            'telegram': 'active',
            'whatsapp': 'active',
            'facebook': 'active',
            'instagram': 'active',
            'unified': 'active'
        }
    })

def identify_platform(webhook_data, headers):
    """Identifica a plataforma baseado nos dados do webhook"""
    try:
        # Telegram
        if 'update_id' in webhook_data or 'message' in webhook_data:
            return 'telegram'
        
        # WhatsApp (Evolution API)
        if 'event' in webhook_data and 'instance' in webhook_data:
            return 'whatsapp'
        
        # Facebook/Instagram (Meta)
        if 'entry' in webhook_data:
            entries = webhook_data.get('entry', [])
            for entry in entries:
                # Facebook Messenger
                if 'messaging' in entry:
                    messaging = entry['messaging'][0] if entry['messaging'] else {}
                    if 'sender' in messaging and 'recipient' in messaging:
                        # Verifica se é Instagram baseado no ID
                        sender_id = str(messaging.get('sender', {}).get('id', ''))
                        if len(sender_id) > 15:  # Instagram IDs são mais longos
                            return 'instagram'
                        else:
                            return 'facebook'
        
        # User-Agent header check
        user_agent = headers.get('User-Agent', '').lower()
        if 'telegram' in user_agent:
            return 'telegram'
        elif 'whatsapp' in user_agent or 'evolution' in user_agent:
            return 'whatsapp'
        elif 'facebook' in user_agent or 'meta' in user_agent:
            return 'facebook'
        
        return None
        
    except Exception as e:
        print(f"Erro ao identificar plataforma: {e}")
        return None

def log_interaction(clinic_id, message_data, response):
    """Registra log da interação"""
    try:
        platform = message_data.get('platform', 'unknown')
        user_id = message_data.get('user_id') or message_data.get('phone_number') or message_data.get('chat_id')
        
        # Busca ou cria usuário
        user = User.query.filter_by(
            clinic_id=clinic_id,
            platform_user_id=str(user_id),
            platform=platform.upper()
        ).first()
        
        if not user:
            user = User(
                clinic_id=clinic_id,
                platform_user_id=str(user_id),
                platform=platform.upper(),
                current_state='MENU',
                created_at=datetime.utcnow()
            )
            db.session.add(user)
            db.session.flush()
        
        # Cria log
        log = ChatLog(
            clinic_id=clinic_id,
            user_id=user.id,
            platform=platform.upper(),
            message_type='RECEIVED',
            message_content=json.dumps(message_data, default=str),
            state_at_time=user.current_state,
            response_sent=json.dumps(response, default=str) if response else None,
            created_at=datetime.utcnow()
        )
        
        db.session.add(log)
        db.session.commit()
        
    except Exception as e:
        print(f"Erro ao registrar log: {e}")
        db.session.rollback()

# Rotas de configuração para administradores
@webhook_omnichannel_bp.route('/config/<clinic_slug>/webhooks', methods=['GET'])
def get_webhook_urls(clinic_slug):
    """Retorna URLs dos webhooks para configuração"""
    try:
        clinic = Clinic.query.filter_by(slug=clinic_slug, active=True).first()
        if not clinic:
            return jsonify({'error': 'Clínica não encontrada'}), 404
        
        base_url = current_app.config.get('WEBHOOK_BASE_URL', 'https://seudominio.com')
        
        webhook_urls = {
            'telegram': f"{base_url}/webhook/telegram/{clinic_slug}",
            'whatsapp': f"{base_url}/webhook/whatsapp/{clinic_slug}",
            'whatsapp_verify': f"{base_url}/webhook/whatsapp/{clinic_slug}/verify",
            'facebook': f"{base_url}/webhook/facebook/{clinic_slug}",
            'facebook_verify': f"{base_url}/webhook/facebook/{clinic_slug}/verify",
            'instagram': f"{base_url}/webhook/instagram/{clinic_slug}",
            'instagram_verify': f"{base_url}/webhook/instagram/{clinic_slug}/verify",
            'unified': f"{base_url}/webhook/unified/{clinic_slug}",
            'health': f"{base_url}/webhook/health"
        }
        
        return jsonify({
            'clinic': clinic.name,
            'slug': clinic_slug,
            'webhooks': webhook_urls,
            'status': 'active' if clinic.active else 'inactive'
        })
        
    except Exception as e:
        print(f"Erro ao obter URLs de webhook: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500
