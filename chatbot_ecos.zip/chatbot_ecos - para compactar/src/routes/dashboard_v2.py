from flask import Blueprint, render_template_string, session, request, jsonify, redirect, url_for, Response
from datetime import datetime, timedelta
from src.models.multi_tenant import db, User, Exam, Appointment, AdminUser, Clinic
from src.routes.auth import login_required, master_required
from src.utils.multi_tenant import require_clinic, clinic_context, QueryFilter, MultiTenantManager
from src.services.image_service import ImageService
from werkzeug.security import generate_password_hash
import json

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/admin')
@login_required
@clinic_context
def index():
    """Dashboard principal com suporte multi-tenant"""
    try:
        clinic = MultiTenantManager.get_current_clinic()
        
        # Estatísticas gerais filtradas por clínica
        total_users = QueryFilter.filter_users().count()
        total_appointments = QueryFilter.filter_appointments().count()
        pending_appointments = QueryFilter.filter_appointments().filter_by(status='PENDING').count()
        confirmed_appointments = QueryFilter.filter_appointments().filter_by(status='CONFIRMED').count()
        
        # Agendamentos recentes
        recent_appointments = QueryFilter.filter_appointments().order_by(
            Appointment.created_at.desc()
        ).limit(10).all()
        
        # Estatísticas de imagens
        image_stats = ImageService.get_image_stats()
        
        # Usuários por plataforma
        telegram_users = QueryFilter.filter_users().filter(User.telegram_id.isnot(None)).count()
        whatsapp_users = QueryFilter.filter_users().filter(User.whatsapp_id.isnot(None)).count()
        facebook_users = QueryFilter.filter_users().filter(User.facebook_id.isnot(None)).count()
        
        # Exames mais solicitados (versão simplificada)
        exam_stats = []
        try:
            appointments = QueryFilter.filter_appointments().all()
            exam_count = {}
            
            for appointment in appointments:
                try:
                    exams = appointment.get_exams()
                    for exam in exams:
                        exam_name = exam.get('exam_name', 'Desconhecido')
                        exam_count[exam_name] = exam_count.get(exam_name, 0) + 1
                except:
                    continue
            
            exam_stats = sorted(exam_count.items(), key=lambda x: x[1], reverse=True)[:5]
            
        except Exception as e:
            print(f"Erro ao calcular estatísticas de exames: {e}")
            exam_stats = []
        
        return render_template_string(DASHBOARD_TEMPLATE, 
            total_users=total_users,
            total_appointments=total_appointments,
            pending_appointments=pending_appointments,
            confirmed_appointments=confirmed_appointments,
            recent_appointments=recent_appointments,
            exam_stats=exam_stats,
            telegram_users=telegram_users,
            whatsapp_users=whatsapp_users,
            facebook_users=facebook_users,
            image_stats=image_stats,
            current_user=session,
            clinic=clinic
        )
        
    except Exception as e:
        print(f"Erro no dashboard: {e}")
        return f"Erro no dashboard: {e}", 500

@dashboard_bp.route('/admin/appointments')
@login_required
@clinic_context
def appointments():
    """Lista de agendamentos com visualização de fotos"""
    try:
        # Filtros
        status_filter = request.args.get('status', 'all')
        date_filter = request.args.get('date', 'all')
        
        # Query base
        query = QueryFilter.filter_appointments()
        
        # Aplica filtros
        if status_filter != 'all':
            query = query.filter_by(status=status_filter.upper())
        
        if date_filter == 'today':
            today = datetime.utcnow().date()
            query = query.filter(db.func.date(Appointment.created_at) == today)
        elif date_filter == 'week':
            week_ago = datetime.utcnow() - timedelta(days=7)
            query = query.filter(Appointment.created_at >= week_ago)
        
        # Ordena por data
        appointments = query.order_by(Appointment.created_at.desc()).all()
        
        # Adiciona informações de imagem para cada agendamento
        for appointment in appointments:
            appointment.images = ImageService.get_appointment_images(appointment.id)
        
        return render_template_string(APPOINTMENTS_TEMPLATE,
            appointments=appointments,
            status_filter=status_filter,
            date_filter=date_filter,
            current_user=session
        )
        
    except Exception as e:
        print(f"Erro na lista de agendamentos: {e}")
        return f"Erro na lista de agendamentos: {e}", 500

@dashboard_bp.route('/admin/appointments/<int:appointment_id>')
@login_required
@clinic_context
def appointment_detail(appointment_id):
    """Detalhes do agendamento com visualização de fotos"""
    try:
        appointment = QueryFilter.filter_appointments().filter_by(id=appointment_id).first()
        
        if not appointment:
            return "Agendamento não encontrado", 404
        
        # Obtém imagens do agendamento
        images = ImageService.get_appointment_images(appointment_id)
        
        return render_template_string(APPOINTMENT_DETAIL_TEMPLATE,
            appointment=appointment,
            images=images,
            current_user=session
        )
        
    except Exception as e:
        print(f"Erro nos detalhes do agendamento: {e}")
        return f"Erro nos detalhes do agendamento: {e}", 500

@dashboard_bp.route('/admin/images/pending')
@login_required
@clinic_context
def pending_images():
    """Lista de imagens pendentes de aprovação"""
    try:
        pending_images = ImageService.get_pending_images()
        
        return render_template_string(PENDING_IMAGES_TEMPLATE,
            pending_images=pending_images,
            current_user=session
        )
        
    except Exception as e:
        print(f"Erro na lista de imagens pendentes: {e}")
        return f"Erro na lista de imagens pendentes: {e}", 500

@dashboard_bp.route('/admin/images/approve', methods=['POST'])
@login_required
@clinic_context
def approve_image():
    """Aprova uma imagem"""
    try:
        data = request.get_json()
        file_id = data.get('file_id')
        
        if not file_id:
            return jsonify({'error': 'file_id é obrigatório'}), 400
        
        approved_by = session.get('username', 'Sistema')
        success = ImageService.approve_image(file_id, approved_by)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Imagem aprovada com sucesso!'
            })
        else:
            return jsonify({
                'error': 'Erro ao aprovar imagem'
            }), 500
            
    except Exception as e:
        print(f"Erro ao aprovar imagem: {e}")
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/admin/images/reject', methods=['POST'])
@login_required
@clinic_context
def reject_image():
    """Rejeita uma imagem"""
    try:
        data = request.get_json()
        file_id = data.get('file_id')
        reason = data.get('reason', 'Motivo não especificado')
        
        if not file_id:
            return jsonify({'error': 'file_id é obrigatório'}), 400
        
        rejected_by = session.get('username', 'Sistema')
        success = ImageService.reject_image(file_id, rejected_by, reason)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Imagem rejeitada com sucesso!'
            })
        else:
            return jsonify({
                'error': 'Erro ao rejeitar imagem'
            }), 500
            
    except Exception as e:
        print(f"Erro ao rejeitar imagem: {e}")
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/admin/images/view/<file_id>')
@clinic_context
def view_image(file_id):
    """Serve imagem via proxy"""
    try:
        clinic = MultiTenantManager.get_current_clinic()
        if not clinic or not clinic.telegram_token:
            return "Token do Telegram não configurado", 400
        
        platform = request.args.get('platform', 'telegram')
        
        if platform == 'telegram':
            image_data, content_type = ImageService.serve_telegram_image(
                file_id, 
                clinic.telegram_token
            )
            
            if image_data:
                return Response(image_data, mimetype=content_type)
            else:
                return "Imagem não encontrada", 404
        else:
            return "Plataforma não suportada", 400
            
    except Exception as e:
        print(f"Erro ao servir imagem: {e}")
        return "Erro ao carregar imagem", 500

# Templates HTML com branding On In Digital

DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - {{ clinic.name if clinic else 'ECOS Chatbot' }}</title>
    <style>
        :root {
            --primary-color: {{ clinic.primary_color if clinic else '#1627a3' }};
            --secondary-color: {{ clinic.secondary_color if clinic else '#15aae5' }};
            --gradient: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        
        .header {
            background: var(--gradient);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .logo-section {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .clinic-logo {
            font-size: 1.5rem;
            font-weight: bold;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary-color);
        }
        
        .stat-card h3 {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .stat-card .number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .image-stats {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-left: 4px solid #fff;
        }
        
        .image-stats h3 {
            color: rgba(255,255,255,0.9);
        }
        
        .image-stats .number {
            color: white;
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header {
            background: var(--gradient);
            color: white;
            padding: 1rem 1.5rem;
            font-weight: bold;
        }
        
        .card-content {
            padding: 1.5rem;
        }
        
        .appointment-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid #eee;
        }
        
        .appointment-item:last-child {
            border-bottom: none;
        }
        
        .appointment-info h4 {
            color: var(--primary-color);
            margin-bottom: 0.25rem;
        }
        
        .appointment-info p {
            color: #666;
            font-size: 0.9rem;
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-confirmed {
            background: #d4edda;
            color: #155724;
        }
        
        .nav-menu {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .nav-link {
            background: var(--primary-color);
            color: white;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .nav-link:hover {
            background: var(--secondary-color);
        }
        
        .footer {
            text-align: center;
            padding: 2rem;
            color: #666;
            border-top: 1px solid #eee;
            margin-top: 3rem;
        }
        
        .powered-by {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 1rem;
        }
        
        .on-in-logo {
            width: 24px;
            height: 24px;
        }
        
        @media (max-width: 768px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
            
            .header-content {
                flex-direction: column;
                gap: 1rem;
            }
            
            .nav-menu {
                flex-wrap: wrap;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <div class="logo-section">
                <div class="clinic-logo">
                    {{ clinic.name if clinic else 'ECOS Chatbot' }}
                </div>
            </div>
            <div class="user-info">
                <span>Olá, {{ current_user.username }}!</span>
                <a href="/auth/logout" style="color: white; text-decoration: none;">Sair</a>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total de Usuários</h3>
                <div class="number">{{ total_users }}</div>
            </div>
            
            <div class="stat-card">
                <h3>Agendamentos</h3>
                <div class="number">{{ total_appointments }}</div>
            </div>
            
            <div class="stat-card">
                <h3>Pendentes</h3>
                <div class="number">{{ pending_appointments }}</div>
            </div>
            
            <div class="stat-card">
                <h3>Confirmados</h3>
                <div class="number">{{ confirmed_appointments }}</div>
            </div>
            
            <div class="stat-card image-stats">
                <h3>Imagens Pendentes</h3>
                <div class="number">{{ image_stats.pending }}</div>
            </div>
            
            <div class="stat-card image-stats">
                <h3>Taxa de Aprovação</h3>
                <div class="number">{{ image_stats.approval_rate }}%</div>
            </div>
        </div>
        
        <div class="nav-menu">
            <a href="/admin/appointments" class="nav-link">📅 Agendamentos</a>
            <a href="/admin/images/pending" class="nav-link">📸 Imagens Pendentes</a>
            {% if current_user.user_type == 'MASTER' or current_user.user_type == 'SUPER_ADMIN' %}
            <a href="/admin/exams" class="nav-link">🧪 Exames</a>
            <a href="/admin/users" class="nav-link">👥 Usuários</a>
            <a href="/admin/settings" class="nav-link">⚙️ Configurações</a>
            {% endif %}
            {% if current_user.user_type == 'SUPER_ADMIN' %}
            <a href="/admin/clinics" class="nav-link">🏥 Clínicas</a>
            {% endif %}
        </div>
        
        <div class="content-grid">
            <div class="card">
                <div class="card-header">
                    📅 Agendamentos Recentes
                </div>
                <div class="card-content">
                    {% for appointment in recent_appointments %}
                    <div class="appointment-item">
                        <div class="appointment-info">
                            <h4>{{ appointment.user.name or 'Nome não informado' }}</h4>
                            <p>{{ appointment.created_at.strftime('%d/%m/%Y %H:%M') }} - R$ {{ "%.2f"|format(appointment.total_price) }}</p>
                        </div>
                        <span class="status-badge status-{{ appointment.status.lower() }}">
                            {{ appointment.status }}
                        </span>
                    </div>
                    {% endfor %}
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    📊 Usuários por Plataforma
                </div>
                <div class="card-content">
                    <div class="appointment-item">
                        <div class="appointment-info">
                            <h4>Telegram</h4>
                            <p>Usuários ativos</p>
                        </div>
                        <span class="number" style="color: var(--primary-color);">{{ telegram_users }}</span>
                    </div>
                    
                    <div class="appointment-item">
                        <div class="appointment-info">
                            <h4>WhatsApp</h4>
                            <p>Usuários ativos</p>
                        </div>
                        <span class="number" style="color: var(--primary-color);">{{ whatsapp_users }}</span>
                    </div>
                    
                    <div class="appointment-item">
                        <div class="appointment-info">
                            <h4>Facebook</h4>
                            <p>Usuários ativos</p>
                        </div>
                        <span class="number" style="color: var(--primary-color);">{{ facebook_users }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer">
        <p>&copy; 2025 {{ clinic.name if clinic else 'ECOS Chatbot' }}. Todos os direitos reservados.</p>
        <div class="powered-by">
            <span>Powered by</span>
            <img src="/static/images/logo-on-inperfilinstagram.png" alt="On In Digital" class="on-in-logo">
            <strong>On In Digital</strong>
        </div>
    </div>
</body>
</html>
"""

PENDING_IMAGES_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imagens Pendentes - {{ clinic.name if clinic else 'ECOS Chatbot' }}</title>
    <style>
        :root {
            --primary-color: {{ clinic.primary_color if clinic else '#1627a3' }};
            --secondary-color: {{ clinic.secondary_color if clinic else '#15aae5' }};
            --gradient: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        
        .header {
            background: var(--gradient);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        
        .back-link {
            display: inline-block;
            background: var(--primary-color);
            color: white;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 2rem;
        }
        
        .images-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
            gap: 2rem;
        }
        
        .image-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .image-preview {
            width: 100%;
            height: 300px;
            object-fit: cover;
            cursor: pointer;
        }
        
        .image-info {
            padding: 1.5rem;
        }
        
        .user-info h3 {
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .user-info p {
            color: #666;
            margin-bottom: 0.25rem;
        }
        
        .appointments-list {
            margin: 1rem 0;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 5px;
        }
        
        .appointment-item {
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            text-transform: uppercase;
            transition: all 0.3s;
        }
        
        .btn-approve {
            background: #28a745;
            color: white;
        }
        
        .btn-approve:hover {
            background: #218838;
        }
        
        .btn-reject {
            background: #dc3545;
            color: white;
        }
        
        .btn-reject:hover {
            background: #c82333;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.9);
        }
        
        .modal-content {
            margin: auto;
            display: block;
            width: 80%;
            max-width: 700px;
            max-height: 80%;
            object-fit: contain;
        }
        
        .close {
            position: absolute;
            top: 15px;
            right: 35px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: #bbb;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #666;
        }
        
        .empty-state h2 {
            margin-bottom: 1rem;
            color: var(--primary-color);
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>📸 Imagens Pendentes de Aprovação</h1>
            <span>{{ pending_images|length }} imagem(ns) pendente(s)</span>
        </div>
    </div>
    
    <div class="container">
        <a href="/admin" class="back-link">← Voltar ao Dashboard</a>
        
        {% if pending_images %}
        <div class="images-grid">
            {% for image in pending_images %}
            <div class="image-card">
                <img src="{{ image.url }}" alt="Pedido médico" class="image-preview" onclick="openModal('{{ image.url }}')">
                
                <div class="image-info">
                    <div class="user-info">
                        <h3>{{ image.user.name }}</h3>
                        <p><strong>CPF:</strong> {{ image.user.cpf }}</p>
                        <p><strong>Telegram:</strong> {{ image.user.telegram_id }}</p>
                        <p><strong>Enviado em:</strong> {{ image.created_at }}</p>
                    </div>
                    
                    <div class="appointments-list">
                        <h4>Agendamentos:</h4>
                        {% for appointment in image.appointments %}
                        <div class="appointment-item">
                            <strong>{{ appointment.covenant_type }}</strong> - R$ {{ "%.2f"|format(appointment.total_price) }}
                            <br>
                            {% for exam in appointment.exams %}
                            • {{ exam.exam_name }}{% if not loop.last %}<br>{% endif %}
                            {% endfor %}
                        </div>
                        {% endfor %}
                    </div>
                    
                    <div class="action-buttons">
                        <button class="btn btn-approve" onclick="approveImage('{{ image.file_id }}')">
                            ✅ Aprovar
                        </button>
                        <button class="btn btn-reject" onclick="rejectImage('{{ image.file_id }}')">
                            ❌ Rejeitar
                        </button>
                    </div>
                </div>
            </div>
            {% endfor %}
        </div>
        {% else %}
        <div class="empty-state">
            <h2>🎉 Nenhuma imagem pendente!</h2>
            <p>Todas as imagens foram processadas.</p>
        </div>
        {% endif %}
    </div>
    
    <!-- Modal para visualizar imagem em tamanho maior -->
    <div id="imageModal" class="modal">
        <span class="close" onclick="closeModal()">&times;</span>
        <img class="modal-content" id="modalImage">
    </div>
    
    <script>
        function openModal(imageSrc) {
            document.getElementById('imageModal').style.display = 'block';
            document.getElementById('modalImage').src = imageSrc;
        }
        
        function closeModal() {
            document.getElementById('imageModal').style.display = 'none';
        }
        
        function approveImage(fileId) {
            if (confirm('Tem certeza que deseja aprovar esta imagem?')) {
                fetch('/admin/images/approve', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        file_id: fileId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Imagem aprovada com sucesso!');
                        location.reload();
                    } else {
                        alert('Erro ao aprovar imagem: ' + data.error);
                    }
                })
                .catch(error => {
                    alert('Erro ao aprovar imagem: ' + error);
                });
            }
        }
        
        function rejectImage(fileId) {
            const reason = prompt('Motivo da rejeição (opcional):');
            if (reason !== null) {
                fetch('/admin/images/reject', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        file_id: fileId,
                        reason: reason
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Imagem rejeitada com sucesso!');
                        location.reload();
                    } else {
                        alert('Erro ao rejeitar imagem: ' + data.error);
                    }
                })
                .catch(error => {
                    alert('Erro ao rejeitar imagem: ' + error);
                });
            }
        }
        
        // Fecha modal ao clicar fora da imagem
        window.onclick = function(event) {
            const modal = document.getElementById('imageModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>
"""

APPOINTMENTS_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamentos - {{ clinic.name if clinic else 'ECOS Chatbot' }}</title>
    <style>
        /* Estilos similares ao dashboard principal */
        :root {
            --primary-color: {{ clinic.primary_color if clinic else '#1627a3' }};
            --secondary-color: {{ clinic.secondary_color if clinic else '#15aae5' }};
            --gradient: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        
        .header {
            background: var(--gradient);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        
        .filters {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .filter-group label {
            font-weight: bold;
            color: #666;
        }
        
        .filter-group select {
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        
        .appointments-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .appointment-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .appointment-header {
            background: var(--gradient);
            color: white;
            padding: 1rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .appointment-content {
            padding: 1.5rem;
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 2rem;
            align-items: start;
        }
        
        .appointment-info h3 {
            color: var(--primary-color);
            margin-bottom: 1rem;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }
        
        .info-label {
            font-weight: bold;
            color: #666;
            font-size: 0.9rem;
        }
        
        .info-value {
            color: #333;
        }
        
        .exams-list {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 5px;
            margin-top: 1rem;
        }
        
        .exam-item {
            padding: 0.5rem 0;
            border-bottom: 1px solid #eee;
        }
        
        .exam-item:last-child {
            border-bottom: none;
        }
        
        .image-preview {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 5px;
            cursor: pointer;
            border: 2px solid #ddd;
        }
        
        .no-image {
            width: 150px;
            height: 150px;
            background: #f8f9fa;
            border: 2px dashed #ddd;
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            font-size: 0.9rem;
            text-align: center;
        }
        
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-confirmed {
            background: #d4edda;
            color: #155724;
        }
        
        .status-cancelled {
            background: #f8d7da;
            color: #721c24;
        }
        
        .back-link {
            display: inline-block;
            background: var(--primary-color);
            color: white;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>📅 Agendamentos</h1>
        </div>
    </div>
    
    <div class="container">
        <a href="/admin" class="back-link">← Voltar ao Dashboard</a>
        
        <div class="filters">
            <div class="filter-group">
                <label>Status:</label>
                <select onchange="filterAppointments()" id="statusFilter">
                    <option value="all" {{ 'selected' if status_filter == 'all' }}>Todos</option>
                    <option value="pending" {{ 'selected' if status_filter == 'pending' }}>Pendentes</option>
                    <option value="confirmed" {{ 'selected' if status_filter == 'confirmed' }}>Confirmados</option>
                    <option value="cancelled" {{ 'selected' if status_filter == 'cancelled' }}>Cancelados</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Período:</label>
                <select onchange="filterAppointments()" id="dateFilter">
                    <option value="all" {{ 'selected' if date_filter == 'all' }}>Todos</option>
                    <option value="today" {{ 'selected' if date_filter == 'today' }}>Hoje</option>
                    <option value="week" {{ 'selected' if date_filter == 'week' }}>Última semana</option>
                </select>
            </div>
        </div>
        
        <div class="appointments-list">
            {% for appointment in appointments %}
            <div class="appointment-card">
                <div class="appointment-header">
                    <h3>Agendamento #{{ appointment.id }}</h3>
                    <span class="status-badge status-{{ appointment.status.lower() }}">
                        {{ appointment.status }}
                    </span>
                </div>
                
                <div class="appointment-content">
                    <div class="appointment-info">
                        <div class="info-grid">
                            <div class="info-item">
                                <span class="info-label">Paciente:</span>
                                <span class="info-value">{{ appointment.user.name or 'Nome não informado' }}</span>
                            </div>
                            
                            <div class="info-item">
                                <span class="info-label">CPF:</span>
                                <span class="info-value">{{ appointment.user.cpf or 'Não informado' }}</span>
                            </div>
                            
                            <div class="info-item">
                                <span class="info-label">Convênio:</span>
                                <span class="info-value">{{ appointment.covenant_type }}</span>
                            </div>
                            
                            <div class="info-item">
                                <span class="info-label">Total:</span>
                                <span class="info-value">R$ {{ "%.2f"|format(appointment.total_price) }}</span>
                            </div>
                            
                            <div class="info-item">
                                <span class="info-label">Data:</span>
                                <span class="info-value">{{ appointment.created_at.strftime('%d/%m/%Y %H:%M') }}</span>
                            </div>
                        </div>
                        
                        <div class="exams-list">
                            <h4>Exames solicitados:</h4>
                            {% for exam in appointment.get_exams() %}
                            <div class="exam-item">
                                <strong>{{ exam.exam_name }}</strong>
                                {% if exam.preparation_instructions %}
                                <br><small>Preparo: {{ exam.preparation_instructions }}</small>
                                {% endif %}
                            </div>
                            {% endfor %}
                        </div>
                    </div>
                    
                    <div class="image-section">
                        {% if appointment.images %}
                            {% for image in appointment.images %}
                            <img src="{{ image.url }}" alt="Pedido médico" class="image-preview" onclick="openModal('{{ image.url }}')">
                            {% endfor %}
                        {% else %}
                        <div class="no-image">
                            📷<br>Sem imagem
                        </div>
                        {% endif %}
                    </div>
                </div>
            </div>
            {% endfor %}
        </div>
    </div>
    
    <script>
        function filterAppointments() {
            const status = document.getElementById('statusFilter').value;
            const date = document.getElementById('dateFilter').value;
            
            const params = new URLSearchParams();
            if (status !== 'all') params.append('status', status);
            if (date !== 'all') params.append('date', date);
            
            window.location.href = '/admin/appointments?' + params.toString();
        }
        
        function openModal(imageSrc) {
            // Implementar modal se necessário
            window.open(imageSrc, '_blank');
        }
    </script>
</body>
</html>
"""

APPOINTMENT_DETAIL_TEMPLATE = """
<!-- Template para detalhes do agendamento será implementado se necessário -->
"""
