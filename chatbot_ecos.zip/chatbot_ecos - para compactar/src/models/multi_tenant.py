from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Clinic(db.Model):
    """Modelo para gerenciar múltiplas clínicas"""
    __tablename__ = 'clinics'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Identificação
    name = db.Column(db.String(100), nullable=False)
    slug = db.Column(db.String(50), unique=True, nullable=False)  # Para subdomínio
    description = db.Column(db.Text, nullable=True)
    
    # Contatos
    address = db.Column(db.String(255), nullable=True)
    phone_call = db.Column(db.String(20), nullable=True)
    phone_whatsapp = db.Column(db.String(20), nullable=True)
    email = db.Column(db.String(100), nullable=True)
    business_hours = db.Column(db.String(255), nullable=True)
    
    # Configurações visuais
    logo_url = db.Column(db.String(255), nullable=True)
    primary_color = db.Column(db.String(7), default='#1627a3')  # On In Digital
    secondary_color = db.Column(db.String(7), default='#15aae5')  # On In Digital
    
    # Configurações de bot
    telegram_token = db.Column(db.String(255), nullable=True)
    whatsapp_token = db.Column(db.String(255), nullable=True)
    facebook_token = db.Column(db.String(255), nullable=True)
    
    # Status
    active = db.Column(db.Boolean, default=True)
    plan = db.Column(db.String(20), default='BASIC')  # BASIC, PRO, ENTERPRISE
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    users = db.relationship('User', backref='clinic', lazy=True)
    appointments = db.relationship('Appointment', backref='clinic', lazy=True)
    exams = db.relationship('Exam', backref='clinic', lazy=True)
    admin_users = db.relationship('AdminUser', backref='clinic', lazy=True)
    
    def __repr__(self):
        return f'<Clinic {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'slug': self.slug,
            'description': self.description,
            'address': self.address,
            'phone_call': self.phone_call,
            'phone_whatsapp': self.phone_whatsapp,
            'email': self.email,
            'business_hours': self.business_hours,
            'logo_url': self.logo_url,
            'primary_color': self.primary_color,
            'secondary_color': self.secondary_color,
            'active': self.active,
            'plan': self.plan,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class User(db.Model):
    """Modelo de usuários com suporte multi-tenant"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    clinic_id = db.Column(db.Integer, db.ForeignKey('clinics.id'), nullable=False)
    
    # IDs das plataformas
    telegram_id = db.Column(db.String(50), nullable=True)
    whatsapp_id = db.Column(db.String(50), nullable=True)
    facebook_id = db.Column(db.String(50), nullable=True)
    
    # Dados pessoais
    name = db.Column(db.String(100), nullable=True)
    cpf = db.Column(db.String(14), nullable=True)
    birth_date = db.Column(db.String(10), nullable=True)
    
    # Estado da conversa
    current_state = db.Column(db.String(50), default='START')
    covenant_type = db.Column(db.String(20), nullable=True)  # PARTICULAR, FUNERARIA, UNIMED
    selected_exams = db.Column(db.Text, nullable=True)  # JSON string
    total_price = db.Column(db.Float, default=0.0)
    
    # Foto do pedido médico
    photo_file_id = db.Column(db.String(200), nullable=True)
    photo_approved = db.Column(db.Boolean, default=False)
    
    # Avaliação
    satisfaction_rating = db.Column(db.Integer, nullable=True)  # 1-5
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_interaction = db.Column(db.DateTime, default=datetime.utcnow)
    session_start = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Índices únicos compostos para evitar duplicatas por clínica
    __table_args__ = (
        db.UniqueConstraint('clinic_id', 'telegram_id', name='unique_clinic_telegram'),
        db.UniqueConstraint('clinic_id', 'whatsapp_id', name='unique_clinic_whatsapp'),
        db.UniqueConstraint('clinic_id', 'facebook_id', name='unique_clinic_facebook'),
    )
    
    def get_selected_exams(self):
        if self.selected_exams:
            return json.loads(self.selected_exams)
        return []
    
    def set_selected_exams(self, exams_list):
        self.selected_exams = json.dumps(exams_list)
    
    def add_exam(self, exam_data):
        exams = self.get_selected_exams()
        exams.append(exam_data)
        self.set_selected_exams(exams)
    
    def clear_exams(self):
        self.selected_exams = None
        self.total_price = 0.0
    
    def get_session_data(self):
        """Retorna dados da sessão atual do usuário"""
        return {
            'current_state': self.current_state,
            'covenant_type': self.covenant_type,
            'selected_exams': self.get_selected_exams(),
            'total_price': self.total_price,
            'photo_file_id': self.photo_file_id,
            'photo_approved': self.photo_approved,
            'session_start': self.session_start.isoformat() if self.session_start else None,
            'last_interaction': self.last_interaction.isoformat() if self.last_interaction else None
        }
    
    def __repr__(self):
        return f'<User {self.id}: {self.name} (Clinic: {self.clinic_id})>'

class Exam(db.Model):
    """Modelo de exames com suporte multi-tenant"""
    __tablename__ = 'exams'
    
    id = db.Column(db.Integer, primary_key=True)
    clinic_id = db.Column(db.Integer, db.ForeignKey('clinics.id'), nullable=False)
    
    exam_id = db.Column(db.String(20), nullable=False)
    exam_name = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    
    # Preços por tipo de convênio
    price_particular = db.Column(db.Float, nullable=False)
    price_funeraria = db.Column(db.Float, nullable=False)
    price_unimed = db.Column(db.Float, nullable=False, default=0.0)  # 0 = coberto pelo plano
    
    # Preparo
    preparation_required = db.Column(db.Boolean, default=False)
    preparation_instructions = db.Column(db.Text, nullable=True)
    
    # Status
    active = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Índice único composto para evitar duplicatas por clínica
    __table_args__ = (
        db.UniqueConstraint('clinic_id', 'exam_id', name='unique_clinic_exam'),
    )
    
    def get_price(self, covenant_type):
        if covenant_type.upper() == 'FUNERARIA':
            return self.price_funeraria
        elif covenant_type.upper() == 'PARTICULAR':
            return self.price_particular
        elif covenant_type.upper() == 'UNIMED':
            return self.price_unimed  # 0 = coberto pelo plano
        return self.price_particular
    
    def __repr__(self):
        return f'<Exam {self.exam_id}: {self.exam_name} (Clinic: {self.clinic_id})>'

class Appointment(db.Model):
    """Modelo de agendamentos com suporte multi-tenant"""
    __tablename__ = 'appointments'
    
    id = db.Column(db.Integer, primary_key=True)
    clinic_id = db.Column(db.Integer, db.ForeignKey('clinics.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Dados do agendamento
    exams = db.Column(db.Text, nullable=False)  # JSON string com lista de exames
    total_price = db.Column(db.Float, nullable=False)
    covenant_type = db.Column(db.String(20), nullable=False)
    
    # Status
    status = db.Column(db.String(20), default='PENDING')  # PENDING, CONFIRMED, CANCELLED, SCHEDULED
    
    # Instruções de preparo consolidadas
    preparation_instructions = db.Column(db.Text, nullable=True)
    
    # Agendamentos individuais (JSON com data/hora para cada exame)
    scheduled_exams = db.Column(db.Text, nullable=True)  # JSON: [{"exam_name": "...", "date": "...", "time": "..."}]
    
    # Foto do pedido médico
    photo_file_id = db.Column(db.String(200), nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    confirmed_at = db.Column(db.DateTime, nullable=True)
    scheduled_at = db.Column(db.DateTime, nullable=True)  # Quando foi agendado pelo operador
    scheduled_by = db.Column(db.String(100), nullable=True)  # Quem agendou
    
    # Relacionamento
    user = db.relationship('User', backref=db.backref('appointments', lazy=True))
    
    def get_exams(self):
        return json.loads(self.exams)
    
    def get_scheduled_exams(self):
        if self.scheduled_exams:
            return json.loads(self.scheduled_exams)
        return []
    
    def set_scheduled_exams(self, scheduled_list):
        self.scheduled_exams = json.dumps(scheduled_list)
    
    def __repr__(self):
        return f'<Appointment {self.id}: User {self.user_id} (Clinic: {self.clinic_id})>'

class AdminUser(db.Model):
    """Modelo de usuários administrativos com suporte multi-tenant"""
    __tablename__ = 'admin_users'
    
    id = db.Column(db.Integer, primary_key=True)
    clinic_id = db.Column(db.Integer, db.ForeignKey('clinics.id'), nullable=True)  # NULL = super admin
    
    username = db.Column(db.String(50), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=True)
    
    # Tipos de usuário
    user_type = db.Column(db.String(20), default='OPERATOR')  # SUPER_ADMIN, MASTER, OPERATOR
    
    # Permissões
    can_manage_exams = db.Column(db.Boolean, default=False)
    can_manage_users = db.Column(db.Boolean, default=False)
    can_view_reports = db.Column(db.Boolean, default=False)
    can_schedule = db.Column(db.Boolean, default=True)
    can_manage_clinics = db.Column(db.Boolean, default=False)  # Apenas super admin
    
    # Status
    active = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    
    # Índice único composto para evitar duplicatas por clínica
    __table_args__ = (
        db.UniqueConstraint('clinic_id', 'username', name='unique_clinic_username'),
    )
    
    def __repr__(self):
        return f'<AdminUser {self.username}: {self.full_name} (Clinic: {self.clinic_id})>'

class ChatLog(db.Model):
    """Modelo de logs de chat com suporte multi-tenant"""
    __tablename__ = 'chat_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    clinic_id = db.Column(db.Integer, db.ForeignKey('clinics.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Dados da mensagem
    platform = db.Column(db.String(20), nullable=False)  # TELEGRAM, WHATSAPP, FACEBOOK
    message_type = db.Column(db.String(20), nullable=False)  # TEXT, PHOTO, CALLBACK, etc.
    message_content = db.Column(db.Text, nullable=False)  # JSON string com dados completos
    
    # Estado no momento da mensagem
    state_at_time = db.Column(db.String(50), nullable=False)
    
    # Resposta enviada
    response_sent = db.Column(db.Text, nullable=True)
    
    # Timestamp
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamento
    user = db.relationship('User', backref=db.backref('chat_logs', lazy=True))
    
    def __repr__(self):
        return f'<ChatLog {self.id}: User {self.user_id} (Clinic: {self.clinic_id})>'

class SystemConfig(db.Model):
    """Configurações do sistema com suporte multi-tenant"""
    __tablename__ = 'system_config'
    
    id = db.Column(db.Integer, primary_key=True)
    clinic_id = db.Column(db.Integer, db.ForeignKey('clinics.id'), nullable=True)  # NULL = global
    
    key = db.Column(db.String(100), nullable=False)
    value = db.Column(db.Text, nullable=True)
    description = db.Column(db.String(255), nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Índice único composto
    __table_args__ = (
        db.UniqueConstraint('clinic_id', 'key', name='unique_clinic_config'),
    )
    
    def __repr__(self):
        return f'<SystemConfig {self.key}: {self.value} (Clinic: {self.clinic_id})>'
