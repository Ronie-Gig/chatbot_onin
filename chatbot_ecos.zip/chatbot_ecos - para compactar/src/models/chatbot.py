from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    telegram_id = db.Column(db.String(50), unique=True, nullable=True)
    whatsapp_id = db.Column(db.String(50), unique=True, nullable=True)
    facebook_id = db.Column(db.String(50), unique=True, nullable=True)
    
    # Dados pessoais
    name = db.Column(db.String(100), nullable=True)
    cpf = db.Column(db.String(14), nullable=True)
    birth_date = db.Column(db.String(10), nullable=True)
    
    # Estado da conversa
    current_state = db.Column(db.String(50), default='START')
    covenant_type = db.Column(db.String(20), nullable=True)  # PARTICULAR, FUNERARIA, UNIMED
    selected_exams = db.Column(db.Text, nullable=True)  # JSON string
    total_price = db.Column(db.Float, default=0.0)
    
    # Foto do pedido médico
    photo_file_id = db.Column(db.String(200), nullable=True)
    photo_approved = db.Column(db.Boolean, default=False)
    
    # Avaliação
    satisfaction_rating = db.Column(db.Integer, nullable=True)  # 1-5
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_interaction = db.Column(db.DateTime, default=datetime.utcnow)
    session_start = db.Column(db.DateTime, default=datetime.utcnow)
    
    def get_selected_exams(self):
        if self.selected_exams:
            return json.loads(self.selected_exams)
        return []
    
    def set_selected_exams(self, exams_list):
        self.selected_exams = json.dumps(exams_list)
    
    def add_exam(self, exam_data):
        exams = self.get_selected_exams()
        exams.append(exam_data)
        self.set_selected_exams(exams)
    
    def clear_exams(self):
        self.selected_exams = None
        self.total_price = 0.0
    
    def get_session_data(self):
        """Retorna dados da sessão atual do usuário"""
        return {
            'current_state': self.current_state,
            'covenant_type': self.covenant_type,
            'selected_exams': self.get_selected_exams(),
            'total_price': self.total_price,
            'photo_file_id': self.photo_file_id,
            'photo_approved': self.photo_approved,
            'session_start': self.session_start.isoformat() if self.session_start else None,
            'last_interaction': self.last_interaction.isoformat() if self.last_interaction else None
        }
    
    def __repr__(self):
        return f'<User {self.id}: {self.name}>'

class Exam(db.Model):
    __tablename__ = 'exams'
    
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.String(20), unique=True, nullable=False)
    exam_name = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    
    # Preços por tipo de convênio
    price_particular = db.Column(db.Float, nullable=False)
    price_funeraria = db.Column(db.Float, nullable=False)
    price_unimed = db.Column(db.Float, nullable=False, default=0.0)  # 0 = coberto pelo plano
    
    # Preparo
    preparation_required = db.Column(db.Boolean, default=False)
    preparation_instructions = db.Column(db.Text, nullable=True)
    
    # Status
    active = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def get_price(self, covenant_type):
        if covenant_type.upper() == 'FUNERARIA':
            return self.price_funeraria
        elif covenant_type.upper() == 'PARTICULAR':
            return self.price_particular
        elif covenant_type.upper() == 'UNIMED':
            return self.price_unimed  # 0 = coberto pelo plano
        return self.price_particular
    
    def __repr__(self):
        return f'<Exam {self.exam_id}: {self.exam_name}>'

class Appointment(db.Model):
    __tablename__ = 'appointments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Dados do agendamento
    exams = db.Column(db.Text, nullable=False)  # JSON string com lista de exames
    total_price = db.Column(db.Float, nullable=False)
    covenant_type = db.Column(db.String(20), nullable=False)
    
    # Status
    status = db.Column(db.String(20), default='PENDING')  # PENDING, CONFIRMED, CANCELLED, SCHEDULED
    
    # Instruções de preparo consolidadas
    preparation_instructions = db.Column(db.Text, nullable=True)
    
    # Agendamentos individuais (JSON com data/hora para cada exame)
    scheduled_exams = db.Column(db.Text, nullable=True)  # JSON: [{"exam_name": "...", "date": "...", "time": "..."}]
    
    # Foto do pedido médico
    photo_file_id = db.Column(db.String(200), nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    confirmed_at = db.Column(db.DateTime, nullable=True)
    scheduled_at = db.Column(db.DateTime, nullable=True)  # Quando foi agendado pelo operador
    scheduled_by = db.Column(db.String(100), nullable=True)  # Quem agendou
    
    # Relacionamento
    user = db.relationship('User', backref=db.backref('appointments', lazy=True))
    
    def get_exams(self):
        return json.loads(self.exams)
    
    def get_scheduled_exams(self):
        if self.scheduled_exams:
            return json.loads(self.scheduled_exams)
        return []
    
    def set_scheduled_exams(self, scheduled_list):
        self.scheduled_exams = json.dumps(scheduled_list)
    
    def __repr__(self):
        return f'<Appointment {self.id}: User {self.user_id}>'

class AdminUser(db.Model):
    __tablename__ = 'admin_users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=True)
    
    # Tipos de usuário
    user_type = db.Column(db.String(20), default='OPERATOR')  # MASTER, OPERATOR
    
    # Permissões
    can_manage_exams = db.Column(db.Boolean, default=False)
    can_manage_users = db.Column(db.Boolean, default=False)
    can_view_reports = db.Column(db.Boolean, default=False)
    can_schedule = db.Column(db.Boolean, default=True)
    
    # Status
    active = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    
    def __repr__(self):
        return f'<AdminUser {self.username}: {self.full_name}>'

class ChatLog(db.Model):
    __tablename__ = 'chat_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Dados da mensagem
    platform = db.Column(db.String(20), nullable=False)  # TELEGRAM, WHATSAPP, FACEBOOK
    message_type = db.Column(db.String(20), nullable=False)  # TEXT, PHOTO, CALLBACK, etc.
    message_content = db.Column(db.Text, nullable=False)  # JSON string com dados completos
    
    # Estado no momento da mensagem
    state_at_time = db.Column(db.String(50), nullable=False)
    
    # Resposta enviada
    response_sent = db.Column(db.Text, nullable=True)
    
    # Timestamp
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamento
    user = db.relationship('User', backref=db.backref('chat_logs', lazy=True))
    
    def __repr__(self):
        return f'<ChatLog {self.id}: User {self.user_id}>'

class SystemConfig(db.Model):
    __tablename__ = 'system_config'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text, nullable=True)
    description = db.Column(db.String(255), nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<SystemConfig {self.key}: {self.value}>'

class ClinicInfo(db.Model):
    __tablename__ = 'clinic_info'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), default='ECOS - Radiologia e Diagnóstico')
    description = db.Column(db.Text, default='ECOS - Radiologia e Diagnóstico por imagem com tecnologia de ponta, médicos especialistas (RQE) e atendimento humanizado. Precisão, cuidado e conforto em cada exame.')
    
    # Endereço
    address = db.Column(db.String(255), default='Rua São Paulo, 407 - Lençóis Paulista - CEP 18.682-049')
    
    # Contatos
    phone_call = db.Column(db.String(20), default='(14) 3436-2300')  # Só ligação
    phone_whatsapp = db.Column(db.String(20), default='(14) 98171-3057')  # Só mensagem
    email = db.Column(db.String(100), default='contato@onindigital.com.br')
    
    # Horários
    business_hours = db.Column(db.String(255), default='Segunda a Sexta: 7h às 18h | Sábado: 7h às 12h')
    
    # Timestamps
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<ClinicInfo {self.name}>'

