import os
from flask import Flask, request, session, redirect, url_for, jsonify
from flask_cors import CORS
from src.config.database import DatabaseConfig
from src.models.multi_tenant import db
from src.utils.multi_tenant import MultiTenantManager

def create_app():
    """Cria e configura a aplicação Flask"""
    app = Flask(__name__)
    
    # Configurações básicas
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'ecos-chatbot-secret-key-2025-multitenant')
    app.config['DEBUG'] = os.getenv('FLASK_DEBUG', 'True').lower() == 'true'
    
    # Configuração do banco de dados
    db_config = DatabaseConfig.get_config()
    for key, value in db_config.items():
        app.config[key] = value
    
    # Configurações de upload
    app.config['UPLOAD_FOLDER'] = os.getenv('UPLOAD_FOLDER', 'uploads')
    app.config['MAX_CONTENT_LENGTH'] = int(os.getenv('MAX_UPLOAD_SIZE', 16777216))  # 16MB
    
    # Inicializa extensões
    db.init_app(app)
    CORS(app)
    
    # Middleware para identificação de clínica
    @app.before_request
    def identify_clinic():
        """Identifica a clínica baseada no subdomínio ou parâmetro"""
        try:
            # Ignora rotas estáticas e de sistema
            if request.endpoint and (
                request.endpoint.startswith('static') or
                request.endpoint.startswith('auth.') or
                request.endpoint.startswith('super_admin.') or
                request.path.startswith('/health') or
                request.path.startswith('/api/clinics')
            ):
                return
            
            clinic_slug = None
            
            # 1. Tenta obter do parâmetro URL
            clinic_slug = request.args.get('clinic')
            
            # 2. Se não encontrou, tenta obter do subdomínio
            if not clinic_slug:
                host = request.host.lower()
                if '.' in host:
                    subdomain = host.split('.')[0]
                    if subdomain not in ['www', 'chatbot', 'admin']:
                        clinic_slug = subdomain
            
            # 3. Se não encontrou, tenta obter da sessão
            if not clinic_slug:
                clinic_slug = session.get('clinic_slug')
            
            # 4. Define clínica no contexto
            if clinic_slug:
                MultiTenantManager.set_current_clinic_slug(clinic_slug)
                session['clinic_slug'] = clinic_slug
            
        except Exception as e:
            print(f"Erro na identificação da clínica: {e}")
    
    # Registra blueprints
    try:
        # Rotas de autenticação
        from src.routes.auth_v2 import auth_bp
        app.register_blueprint(auth_bp, url_prefix='/auth')
        
        # Rotas de webhook
        from src.routes.webhook import webhook_bp
        app.register_blueprint(webhook_bp, url_prefix='/webhook')
        
        # Dashboard principal (multi-tenant)
        from src.routes.dashboard_v2 import dashboard_bp
        app.register_blueprint(dashboard_bp)
        
        # Super administrador
        from src.routes.super_admin import super_admin_bp
        app.register_blueprint(super_admin_bp)
        
        # Rotas de relatórios
        from src.routes.reports import reports_bp
        app.register_blueprint(reports_bp, url_prefix='/reports')
        
    except ImportError as e:
        print(f"Erro ao importar blueprints: {e}")
        # Fallback para blueprints básicos
        from src.routes.auth_v2 import auth_bp
        from src.routes.webhook import webhook_bp
        app.register_blueprint(auth_bp, url_prefix='/auth')
        app.register_blueprint(webhook_bp, url_prefix='/webhook')
    
    # Rotas básicas
    @app.route('/')
    def index():
        """Página inicial - redireciona baseado no contexto"""
        try:
            clinic = MultiTenantManager.get_current_clinic()
            
            if clinic:
                # Se há clínica identificada, vai para login da clínica
                return redirect(url_for('auth.login'))
            else:
                # Se não há clínica, vai para seleção ou super admin
                if 'username' in session and session.get('user_type') == 'SUPER_ADMIN':
                    return redirect(url_for('super_admin.dashboard'))
                else:
                    return redirect(url_for('auth.login'))
                    
        except Exception as e:
            print(f"Erro na página inicial: {e}")
            return redirect(url_for('auth.login'))
    
    @app.route('/health')
    def health_check():
        """Health check para monitoramento"""
        try:
            # Testa conexão com banco
            db.session.execute(db.text('SELECT 1'))
            
            # Conta clínicas ativas
            from src.models.multi_tenant import Clinic
            active_clinics = Clinic.query.filter_by(active=True).count()
            
            return jsonify({
                'status': 'healthy',
                'database': 'connected',
                'active_clinics': active_clinics,
                'version': '2.0.0-multitenant'
            })
            
        except Exception as e:
            return jsonify({
                'status': 'unhealthy',
                'error': str(e)
            }), 500
    
    @app.route('/api/clinics')
    def list_clinics():
        """Lista clínicas ativas (para desenvolvimento)"""
        try:
            from src.models.multi_tenant import Clinic
            
            clinics = Clinic.query.filter_by(active=True).all()
            
            return jsonify({
                'clinics': [{
                    'id': clinic.id,
                    'name': clinic.name,
                    'slug': clinic.slug,
                    'url': f"http://{clinic.slug}.onindigital.com.br",
                    'plan': clinic.plan
                } for clinic in clinics]
            })
            
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/clinic/<slug>')
    def clinic_info(slug):
        """Informações de uma clínica específica"""
        try:
            from src.models.multi_tenant import Clinic
            
            clinic = Clinic.query.filter_by(slug=slug, active=True).first()
            
            if not clinic:
                return jsonify({'error': 'Clínica não encontrada'}), 404
            
            return jsonify({
                'clinic': clinic.to_dict()
            })
            
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    # Handlers de erro
    @app.errorhandler(404)
    def not_found(error):
        """Página não encontrada"""
        return jsonify({'error': 'Página não encontrada'}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        """Erro interno do servidor"""
        db.session.rollback()
        return jsonify({'error': 'Erro interno do servidor'}), 500
    
    # Context processors
    @app.context_processor
    def inject_globals():
        """Injeta variáveis globais nos templates"""
        try:
            clinic = MultiTenantManager.get_current_clinic()
            
            return {
                'current_clinic': clinic,
                'on_in_digital': {
                    'name': 'On In Digital',
                    'website': 'https://onindigital.com.br',
                    'logo_light': '/static/images/logo-on-inperfilinstagram.png',
                    'logo_dark': '/static/images/logo-on-inperfilinstagraminvertido.png'
                }
            }
            
        except Exception as e:
            print(f"Erro no context processor: {e}")
            return {}
    
    return app

def main():
    """Função principal para execução standalone"""
    app = create_app()
    
    with app.app_context():
        try:
            # Cria tabelas se não existirem
            db.create_all()
            print("✅ Tabelas do banco de dados verificadas/criadas")
            
            # Executa configuração inicial se necessário
            from src.models.multi_tenant import Clinic
            if Clinic.query.count() == 0:
                print("🔧 Executando configuração inicial...")
                from src.data.initial_setup_multitenant import run_initial_setup
                run_initial_setup()
            
        except Exception as e:
            print(f"❌ Erro na inicialização: {e}")
    
    # Configurações do servidor
    host = os.getenv('HOST', '127.0.0.1')
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', 'True').lower() == 'true'
    
    print(f"""
🚀 Iniciando ECOS Chatbot Multi-tenant v2.0.0

📊 Dashboard: http://{host}:{port}/admin
🏥 ECOS: http://{host}:{port}/?clinic=ecos
🔧 Super Admin: http://{host}:{port}/super/dashboard
💊 Health Check: http://{host}:{port}/health

🔑 Credenciais:
👑 Super Admin: onindigital / onindigital2025@super
👑 Master ECOS: master / ecos2025@master
👤 Operadores: operador1, operador2, operador3 / ecos2025

🎨 Branding: On In Digital
🌐 Multi-tenant: Ativo
📱 Plataformas: Telegram, WhatsApp, Facebook (preparado)
""")
    
    app.run(host=host, port=port, debug=debug)

if __name__ == '__main__':
    main()
