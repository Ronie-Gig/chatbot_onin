import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, jsonify, session, request, redirect, url_for
from flask_cors import CORS
from datetime import datetime

# Configuração de banco
from src.config.database import DatabaseConfig

# Modelos multi-tenant
from src.models.multi_tenant import db, Clinic, User, Exam, Appointment, AdminUser

# Utilitários multi-tenant
from src.utils.multi_tenant import init_multi_tenant_app, MultiTenantManager

# Rotas
from src.routes.webhook import webhook_bp
from src.routes.auth import auth_bp
from src.routes.dashboard import dashboard_bp
from src.routes.reports import reports_bp

def create_app():
    """Factory para criar aplicação Flask"""
    app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
    
    # Configurações básicas
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'ecos-chatbot-secret-key-2025')
    
    # Configuração do banco de dados
    db_config = DatabaseConfig.get_config()
    app.config.update(db_config)
    
    # CORS
    CORS(app, origins=['*'])
    
    # Inicializa banco
    db.init_app(app)
    
    # Inicializa multi-tenant
    init_multi_tenant_app(app)
    
    # Registra blueprints
    app.register_blueprint(webhook_bp, url_prefix='/webhook')
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(dashboard_bp, url_prefix='/')
    app.register_blueprint(reports_bp, url_prefix='/reports')
    
    # Rota raiz - redireciona para login
    @app.route('/')
    def index():
        return redirect(url_for('auth.login'))
    
    # Rotas de sistema
    @app.route('/health')
    def health_check():
        """Health check para monitoramento"""
        try:
            # Testa conexão com banco
            db.session.execute(db.text('SELECT 1'))
            
            # Informações do sistema
            clinic = MultiTenantManager.get_current_clinic()
            
            return jsonify({
                'status': 'healthy',
                'timestamp': datetime.utcnow().isoformat(),
                'database': 'postgresql' if DatabaseConfig.is_postgresql() else 'sqlite',
                'clinic': clinic.name if clinic else 'No clinic context',
                'version': '2.0.0-multitenant'
            })
        except Exception as e:
            return jsonify({
                'status': 'unhealthy',
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }), 500
    
    @app.route('/api/clinics')
    def list_clinics():
        """Lista clínicas ativas (para desenvolvimento)"""
        try:
            clinics = Clinic.query.filter_by(active=True).all()
            return jsonify({
                'clinics': [clinic.to_dict() for clinic in clinics]
            })
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route('/setup/clinic', methods=['POST'])
    def setup_clinic():
        """Endpoint para configurar nova clínica"""
        try:
            data = request.get_json()
            
            clinic = Clinic(
                name=data['name'],
                slug=data['slug'],
                description=data.get('description'),
                address=data.get('address'),
                phone_call=data.get('phone_call'),
                phone_whatsapp=data.get('phone_whatsapp'),
                email=data.get('email'),
                business_hours=data.get('business_hours'),
                primary_color=data.get('primary_color', '#1627a3'),
                secondary_color=data.get('secondary_color', '#15aae5'),
                telegram_token=data.get('telegram_token'),
                whatsapp_token=data.get('whatsapp_token'),
                facebook_token=data.get('facebook_token'),
                plan=data.get('plan', 'BASIC')
            )
            
            db.session.add(clinic)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'clinic': clinic.to_dict(),
                'message': f'Clínica {clinic.name} criada com sucesso!'
            })
            
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500
    
    @app.route('/setup/telegram', methods=['POST'])
    def setup_telegram():
        """Configura webhook do Telegram para clínica atual"""
        try:
            data = request.get_json()
            webhook_url = data.get('webhook_url')
            
            if not webhook_url:
                return jsonify({'error': 'webhook_url é obrigatório'}), 400
            
            clinic = MultiTenantManager.get_current_clinic()
            if not clinic:
                return jsonify({'error': 'Clínica não identificada'}), 400
            
            if not clinic.telegram_token:
                return jsonify({'error': 'Token do Telegram não configurado para esta clínica'}), 400
            
            # Configura webhook
            import requests
            telegram_url = f"https://api.telegram.org/bot{clinic.telegram_token}/setWebhook"
            
            response = requests.post(telegram_url, json={
                'url': f"{webhook_url}?clinic={clinic.slug}",
                'allowed_updates': ['message', 'callback_query']
            })
            
            if response.status_code == 200:
                return jsonify({
                    'success': True,
                    'message': f'Webhook configurado para {clinic.name}',
                    'webhook_url': f"{webhook_url}?clinic={clinic.slug}"
                })
            else:
                return jsonify({
                    'error': 'Erro ao configurar webhook',
                    'details': response.text
                }), 500
                
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    # Tratamento de erros
    @app.errorhandler(404)
    def not_found(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Endpoint não encontrado'}), 404
        
        # Para rotas web, redireciona para login
        return redirect('/login')
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Erro interno do servidor'}), 500
        
        return "Erro interno do servidor", 500
    
    return app

def init_database():
    """Inicializa banco de dados"""
    with app.app_context():
        try:
            # Cria todas as tabelas
            db.create_all()
            print("✅ Tabelas criadas com sucesso!")
            
            # Verifica se há dados
            clinic_count = Clinic.query.count()
            if clinic_count == 0:
                print("⚠️ Nenhuma clínica encontrada. Execute a migração ou crie uma clínica.")
            else:
                print(f"✅ {clinic_count} clínica(s) encontrada(s)")
                
        except Exception as e:
            print(f"❌ Erro ao inicializar banco: {e}")

# Cria aplicação
app = create_app()

if __name__ == '__main__':
    # Inicializa banco
    init_database()
    
    # Configurações de desenvolvimento
    debug_mode = os.getenv('FLASK_DEBUG', 'True').lower() == 'true'
    port = int(os.getenv('PORT', 5000))
    host = os.getenv('HOST', '127.0.0.1')
    
    print("🚀 Iniciando ECOS Chatbot Multi-tenant")
    print(f"📊 Banco: {'PostgreSQL' if DatabaseConfig.is_postgresql() else 'SQLite'}")
    print(f"🌐 Servidor: http://{host}:{port}")
    print(f"🔧 Debug: {debug_mode}")
    print("\n📋 Credenciais padrão:")
    print("👑 Super Admin: onindigital / onindigital2025@super")
    print("👑 Master ECOS: master / ecos2025@master")
    print("👤 Operadores: operador1, operador2, operador3 / ecos2025")
    print("\n🌐 Para usar com ngrok:")
    print("1. Execute: ngrok http 5000")
    print("2. Configure webhook: https://SEU_NGROK.ngrok-free.app/webhook/telegram?clinic=ecos")
    print("\n" + "="*60)
    
    # Inicia servidor
    app.run(
        host=host,
        port=port,
        debug=debug_mode,
        threaded=True
    )

