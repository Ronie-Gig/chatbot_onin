import os
import time
import psutil
import logging
from datetime import datetime, timedelta
from functools import wraps
from flask import request, g, current_app
from src.models.multi_tenant import db, ChatLog
from src.utils.multi_tenant import MultiTenantManager

class SystemMonitor:
    """Monitor de sistema para métricas de performance"""
    
    @staticmethod
    def get_system_metrics():
        """Obtém métricas do sistema"""
        try:
            # CPU
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_count = psutil.cpu_count()
            
            # Memória
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_used = memory.used / (1024**3)  # GB
            memory_total = memory.total / (1024**3)  # GB
            
            # Disco
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            disk_used = disk.used / (1024**3)  # GB
            disk_total = disk.total / (1024**3)  # GB
            
            # Rede
            network = psutil.net_io_counters()
            
            return {
                'timestamp': datetime.utcnow().isoformat(),
                'cpu': {
                    'percent': cpu_percent,
                    'count': cpu_count
                },
                'memory': {
                    'percent': memory_percent,
                    'used_gb': round(memory_used, 2),
                    'total_gb': round(memory_total, 2)
                },
                'disk': {
                    'percent': disk_percent,
                    'used_gb': round(disk_used, 2),
                    'total_gb': round(disk_total, 2)
                },
                'network': {
                    'bytes_sent': network.bytes_sent,
                    'bytes_recv': network.bytes_recv,
                    'packets_sent': network.packets_sent,
                    'packets_recv': network.packets_recv
                }
            }
        except Exception as e:
            current_app.logger.error(f"Erro ao obter métricas do sistema: {e}")
            return None
    
    @staticmethod
    def get_application_metrics():
        """Obtém métricas da aplicação"""
        try:
            # Estatísticas do banco
            total_users = db.session.execute('SELECT COUNT(*) FROM users').scalar()
            total_appointments = db.session.execute('SELECT COUNT(*) FROM appointments').scalar()
            total_clinics = db.session.execute('SELECT COUNT(*) FROM clinics').scalar()
            
            # Mensagens por plataforma (últimas 24h)
            yesterday = datetime.utcnow() - timedelta(days=1)
            
            platform_stats = {}
            platforms = ['TELEGRAM', 'WHATSAPP', 'FACEBOOK', 'INSTAGRAM']
            
            for platform in platforms:
                count = db.session.execute(
                    'SELECT COUNT(*) FROM chat_logs WHERE platform = :platform AND created_at > :yesterday',
                    {'platform': platform, 'yesterday': yesterday}
                ).scalar()
                platform_stats[platform.lower()] = count
            
            return {
                'timestamp': datetime.utcnow().isoformat(),
                'database': {
                    'total_users': total_users,
                    'total_appointments': total_appointments,
                    'total_clinics': total_clinics
                },
                'messages_24h': platform_stats,
                'total_messages_24h': sum(platform_stats.values())
            }
        except Exception as e:
            current_app.logger.error(f"Erro ao obter métricas da aplicação: {e}")
            return None
    
    @staticmethod
    def check_health():
        """Verifica saúde do sistema"""
        health_status = {
            'timestamp': datetime.utcnow().isoformat(),
            'status': 'healthy',
            'checks': {}
        }
        
        # Verifica banco de dados
        try:
            db.session.execute('SELECT 1')
            health_status['checks']['database'] = 'healthy'
        except Exception as e:
            health_status['checks']['database'] = f'unhealthy: {str(e)}'
            health_status['status'] = 'unhealthy'
        
        # Verifica uso de CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        if cpu_percent > 90:
            health_status['checks']['cpu'] = f'warning: {cpu_percent}%'
            if health_status['status'] == 'healthy':
                health_status['status'] = 'warning'
        else:
            health_status['checks']['cpu'] = f'healthy: {cpu_percent}%'
        
        # Verifica uso de memória
        memory_percent = psutil.virtual_memory().percent
        if memory_percent > 90:
            health_status['checks']['memory'] = f'warning: {memory_percent}%'
            if health_status['status'] == 'healthy':
                health_status['status'] = 'warning'
        else:
            health_status['checks']['memory'] = f'healthy: {memory_percent}%'
        
        # Verifica uso de disco
        disk_percent = psutil.disk_usage('/').percent
        if disk_percent > 90:
            health_status['checks']['disk'] = f'warning: {disk_percent}%'
            if health_status['status'] == 'healthy':
                health_status['status'] = 'warning'
        else:
            health_status['checks']['disk'] = f'healthy: {disk_percent}%'
        
        return health_status

class RequestLogger:
    """Logger de requisições HTTP"""
    
    @staticmethod
    def log_request():
        """Registra informações da requisição"""
        g.start_time = time.time()
        
        # Log da requisição
        current_app.logger.info(
            f"REQUEST: {request.method} {request.path} "
            f"from {request.remote_addr} "
            f"User-Agent: {request.headers.get('User-Agent', 'Unknown')}"
        )
    
    @staticmethod
    def log_response(response):
        """Registra informações da resposta"""
        duration = time.time() - g.get('start_time', time.time())
        
        # Log da resposta
        current_app.logger.info(
            f"RESPONSE: {response.status_code} "
            f"Duration: {duration:.3f}s "
            f"Size: {response.content_length or 0} bytes"
        )
        
        # Log de requisições lentas
        if duration > 5.0:
            current_app.logger.warning(
                f"SLOW REQUEST: {request.method} {request.path} "
                f"took {duration:.3f}s"
            )
        
        return response

class ChatLogger:
    """Logger específico para conversas do chatbot"""
    
    @staticmethod
    def log_message(user_id, platform, message_type, content, clinic_id=None):
        """Registra mensagem do chatbot"""
        try:
            if not clinic_id:
                clinic = MultiTenantManager.get_current_clinic()
                clinic_id = clinic.id if clinic else None
            
            chat_log = ChatLog(
                user_id=user_id,
                clinic_id=clinic_id,
                platform=platform.upper(),
                message_type=message_type,
                content=content[:1000],  # Limita tamanho
                created_at=datetime.utcnow()
            )
            
            db.session.add(chat_log)
            db.session.commit()
            
        except Exception as e:
            current_app.logger.error(f"Erro ao registrar chat log: {e}")
    
    @staticmethod
    def get_chat_statistics(clinic_id=None, days=7):
        """Obtém estatísticas de chat"""
        try:
            start_date = datetime.utcnow() - timedelta(days=days)
            
            query = db.session.query(ChatLog).filter(
                ChatLog.created_at >= start_date
            )
            
            if clinic_id:
                query = query.filter(ChatLog.clinic_id == clinic_id)
            
            logs = query.all()
            
            # Agrupa por plataforma
            platform_stats = {}
            for log in logs:
                platform = log.platform.lower()
                if platform not in platform_stats:
                    platform_stats[platform] = 0
                platform_stats[platform] += 1
            
            # Agrupa por dia
            daily_stats = {}
            for log in logs:
                day = log.created_at.date().isoformat()
                if day not in daily_stats:
                    daily_stats[day] = 0
                daily_stats[day] += 1
            
            return {
                'period_days': days,
                'total_messages': len(logs),
                'platform_breakdown': platform_stats,
                'daily_breakdown': daily_stats
            }
            
        except Exception as e:
            current_app.logger.error(f"Erro ao obter estatísticas de chat: {e}")
            return None

class PerformanceMonitor:
    """Monitor de performance para funções críticas"""
    
    @staticmethod
    def monitor_function(func_name=None):
        """Decorator para monitorar performance de funções"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                start_time = time.time()
                function_name = func_name or f"{func.__module__}.{func.__name__}"
                
                try:
                    result = func(*args, **kwargs)
                    duration = time.time() - start_time
                    
                    # Log performance
                    current_app.logger.info(
                        f"PERFORMANCE: {function_name} "
                        f"executed in {duration:.3f}s"
                    )
                    
                    # Log funções lentas
                    if duration > 2.0:
                        current_app.logger.warning(
                            f"SLOW FUNCTION: {function_name} "
                            f"took {duration:.3f}s"
                        )
                    
                    return result
                    
                except Exception as e:
                    duration = time.time() - start_time
                    current_app.logger.error(
                        f"ERROR in {function_name} "
                        f"after {duration:.3f}s: {str(e)}"
                    )
                    raise
            
            return wrapper
        return decorator

class AlertManager:
    """Gerenciador de alertas do sistema"""
    
    @staticmethod
    def check_and_send_alerts():
        """Verifica condições e envia alertas se necessário"""
        alerts = []
        
        # Verifica CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        if cpu_percent > 90:
            alerts.append({
                'type': 'cpu_high',
                'severity': 'critical',
                'message': f'CPU usage is {cpu_percent}%',
                'timestamp': datetime.utcnow().isoformat()
            })
        
        # Verifica memória
        memory_percent = psutil.virtual_memory().percent
        if memory_percent > 90:
            alerts.append({
                'type': 'memory_high',
                'severity': 'critical',
                'message': f'Memory usage is {memory_percent}%',
                'timestamp': datetime.utcnow().isoformat()
            })
        
        # Verifica disco
        disk_percent = psutil.disk_usage('/').percent
        if disk_percent > 90:
            alerts.append({
                'type': 'disk_high',
                'severity': 'critical',
                'message': f'Disk usage is {disk_percent}%',
                'timestamp': datetime.utcnow().isoformat()
            })
        
        # Verifica banco de dados
        try:
            db.session.execute('SELECT 1')
        except Exception as e:
            alerts.append({
                'type': 'database_error',
                'severity': 'critical',
                'message': f'Database error: {str(e)}',
                'timestamp': datetime.utcnow().isoformat()
            })
        
        # Envia alertas (log por enquanto, pode integrar com email/Slack)
        for alert in alerts:
            current_app.logger.critical(
                f"ALERT [{alert['severity'].upper()}] "
                f"{alert['type']}: {alert['message']}"
            )
        
        return alerts

def setup_monitoring(app):
    """Configura monitoramento na aplicação Flask"""
    
    # Middleware de logging de requisições
    @app.before_request
    def before_request():
        RequestLogger.log_request()
    
    @app.after_request
    def after_request(response):
        return RequestLogger.log_response(response)
    
    # Rotas de monitoramento
    @app.route('/monitoring/health')
    def health_check():
        """Health check detalhado"""
        return SystemMonitor.check_health()
    
    @app.route('/monitoring/metrics')
    def system_metrics():
        """Métricas do sistema"""
        system_metrics = SystemMonitor.get_system_metrics()
        app_metrics = SystemMonitor.get_application_metrics()
        
        return {
            'system': system_metrics,
            'application': app_metrics
        }
    
    @app.route('/monitoring/chat-stats')
    def chat_statistics():
        """Estatísticas de chat"""
        clinic = MultiTenantManager.get_current_clinic()
        clinic_id = clinic.id if clinic else None
        
        stats = ChatLogger.get_chat_statistics(clinic_id)
        return stats or {'error': 'Unable to fetch statistics'}
    
    # Comando CLI para verificar alertas
    @app.cli.command()
    def check_alerts():
        """Verifica e exibe alertas do sistema"""
        alerts = AlertManager.check_and_send_alerts()
        
        if alerts:
            print(f"Found {len(alerts)} alert(s):")
            for alert in alerts:
                print(f"  [{alert['severity'].upper()}] {alert['message']}")
        else:
            print("No alerts found. System is healthy.")
    
    app.logger.info("Monitoring system initialized")
