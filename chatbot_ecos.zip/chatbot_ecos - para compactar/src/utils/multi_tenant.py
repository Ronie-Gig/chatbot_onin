from flask import request, session, g, abort
from functools import wraps
from src.models.multi_tenant import Clinic, db
import re

class MultiTenantManager:
    """Gerenciador de multi-tenancy"""
    
    @staticmethod
    def get_clinic_from_request():
        """Identifica a clínica baseada na requisição"""
        
        # 1. Tenta pelo subdomínio
        host = request.host.lower()
        
        # Remove porta se existir
        if ':' in host:
            host = host.split(':')[0]
        
        # Extrai subdomínio
        parts = host.split('.')
        if len(parts) >= 3:  # ex: ecos.onindigital.com.br
            subdomain = parts[0]
            
            # Busca clínica pelo slug
            clinic = Clinic.query.filter_by(slug=subdomain, active=True).first()
            if clinic:
                return clinic
        
        # 2. Tenta pelo parâmetro clinic_slug
        clinic_slug = request.args.get('clinic') or request.form.get('clinic')
        if clinic_slug:
            clinic = Clinic.query.filter_by(slug=clinic_slug, active=True).first()
            if clinic:
                return clinic
        
        # 3. Tenta pela sessão (para dashboard)
        if 'clinic_id' in session:
            clinic = Clinic.query.get(session['clinic_id'])
            if clinic and clinic.active:
                return clinic
        
        # 4. Fallback: primeira clínica ativa (desenvolvimento)
        return Clinic.query.filter_by(active=True).first()
    
    @staticmethod
    def set_current_clinic(clinic):
        """Define a clínica atual no contexto da requisição"""
        g.current_clinic = clinic
        if clinic:
            session['clinic_id'] = clinic.id
    
    @staticmethod
    def get_current_clinic():
        """Retorna a clínica atual"""
        return getattr(g, 'current_clinic', None)
    
    @staticmethod
    def filter_by_clinic(query, model_class):
        """Aplica filtro de clínica automaticamente"""
        clinic = MultiTenantManager.get_current_clinic()
        if clinic and hasattr(model_class, 'clinic_id'):
            return query.filter(model_class.clinic_id == clinic.id)
        return query
    
    @staticmethod
    def create_with_clinic(model_instance):
        """Adiciona clinic_id automaticamente ao criar registros"""
        clinic = MultiTenantManager.get_current_clinic()
        if clinic and hasattr(model_instance, 'clinic_id'):
            model_instance.clinic_id = clinic.id
        return model_instance

def require_clinic(f):
    """Decorator que exige uma clínica válida"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        clinic = MultiTenantManager.get_clinic_from_request()
        if not clinic:
            abort(404, description="Clínica não encontrada")
        
        MultiTenantManager.set_current_clinic(clinic)
        return f(*args, **kwargs)
    return decorated_function

def clinic_context(f):
    """Decorator que define contexto de clínica (opcional)"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        clinic = MultiTenantManager.get_clinic_from_request()
        MultiTenantManager.set_current_clinic(clinic)
        return f(*args, **kwargs)
    return decorated_function

def super_admin_required(f):
    """Decorator para rotas que requerem super admin"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            abort(401, description="Login necessário")
        
        from src.models.multi_tenant import AdminUser
        user = AdminUser.query.get(session['user_id'])
        
        if not user or user.user_type != 'SUPER_ADMIN':
            abort(403, description="Acesso negado. Apenas super administradores.")
        
        return f(*args, **kwargs)
    return decorated_function

class QueryFilter:
    """Filtros automáticos para consultas multi-tenant"""
    
    @staticmethod
    def apply_clinic_filter(query, model_class):
        """Aplica filtro de clínica se o modelo suportar"""
        clinic = MultiTenantManager.get_current_clinic()
        if clinic and hasattr(model_class, 'clinic_id'):
            return query.filter(model_class.clinic_id == clinic.id)
        return query
    
    @staticmethod
    def filter_users():
        """Filtra usuários da clínica atual"""
        from src.models.multi_tenant import User
        query = User.query
        return QueryFilter.apply_clinic_filter(query, User)
    
    @staticmethod
    def filter_appointments():
        """Filtra agendamentos da clínica atual"""
        from src.models.multi_tenant import Appointment
        query = Appointment.query
        return QueryFilter.apply_clinic_filter(query, Appointment)
    
    @staticmethod
    def filter_exams():
        """Filtra exames da clínica atual"""
        from src.models.multi_tenant import Exam
        query = Exam.query
        return QueryFilter.apply_clinic_filter(query, Exam)
    
    @staticmethod
    def filter_admin_users():
        """Filtra usuários admin da clínica atual"""
        from src.models.multi_tenant import AdminUser
        query = AdminUser.query
        return QueryFilter.apply_clinic_filter(query, AdminUser)

def init_multi_tenant_app(app):
    """Inicializa configurações multi-tenant na aplicação"""
    
    @app.before_request
    def before_request():
        """Executa antes de cada requisição"""
        
        # Pula para rotas estáticas e de sistema
        if request.endpoint and (
            request.endpoint.startswith('static') or
            request.endpoint in ['health', 'webhook.test_webhook']
        ):
            return
        
        # Define contexto de clínica para todas as requisições
        clinic = MultiTenantManager.get_clinic_from_request()
        MultiTenantManager.set_current_clinic(clinic)
    
    @app.context_processor
    def inject_clinic():
        """Injeta dados da clínica nos templates"""
        clinic = MultiTenantManager.get_current_clinic()
        return {
            'current_clinic': clinic,
            'clinic_name': clinic.name if clinic else 'Sistema',
            'clinic_colors': {
                'primary': clinic.primary_color if clinic else '#1627a3',
                'secondary': clinic.secondary_color if clinic else '#15aae5'
            } if clinic else {'primary': '#1627a3', 'secondary': '#15aae5'}
        }
    
    return app
