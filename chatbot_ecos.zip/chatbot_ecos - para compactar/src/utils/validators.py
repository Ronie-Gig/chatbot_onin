import re
from datetime import datetime

def validate_cpf(cpf):
    """Valida CPF brasileiro"""
    # Remove caracteres não numéricos
    cpf = re.sub(r'[^0-9]', '', cpf)
    
    # Verifica se tem 11 dígitos
    if len(cpf) != 11:
        return False
    
    # Verifica se todos os dígitos são iguais
    if cpf == cpf[0] * 11:
        return False
    
    # Calcula primeiro dígito verificador
    sum1 = 0
    for i in range(9):
        sum1 += int(cpf[i]) * (10 - i)
    
    remainder1 = sum1 % 11
    digit1 = 0 if remainder1 < 2 else 11 - remainder1
    
    # Verifica primeiro dígito
    if int(cpf[9]) != digit1:
        return False
    
    # Calcula segundo dígito verificador
    sum2 = 0
    for i in range(10):
        sum2 += int(cpf[i]) * (11 - i)
    
    remainder2 = sum2 % 11
    digit2 = 0 if remainder2 < 2 else 11 - remainder2
    
    # Verifica segundo dígito
    if int(cpf[10]) != digit2:
        return False
    
    return True

def format_cpf(cpf):
    """Formata CPF com pontuação"""
    cpf = re.sub(r'[^0-9]', '', cpf)
    if len(cpf) == 11:
        return f"{cpf[:3]}.{cpf[3:6]}.{cpf[6:9]}-{cpf[9:]}"
    return cpf

def validate_phone(phone):
    """Valida número de telefone brasileiro"""
    phone = re.sub(r'[^0-9]', '', phone)
    
    # Telefone deve ter 10 ou 11 dígitos
    if len(phone) not in [10, 11]:
        return False
    
    # Se tem 11 dígitos, o terceiro deve ser 9 (celular)
    if len(phone) == 11 and phone[2] != '9':
        return False
    
    return True

def format_phone(phone):
    """Formata telefone com pontuação"""
    phone = re.sub(r'[^0-9]', '', phone)
    
    if len(phone) == 10:
        return f"({phone[:2]}) {phone[2:6]}-{phone[6:]}"
    elif len(phone) == 11:
        return f"({phone[:2]}) {phone[2:7]}-{phone[7:]}"
    
    return phone

def validate_email(email):
    """Valida formato de email"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_date(date_str, format='%d/%m/%Y'):
    """Valida formato de data"""
    try:
        datetime.strptime(date_str, format)
        return True
    except ValueError:
        return False

def format_currency(value):
    """Formata valor monetário"""
    if value == 0:
        return "Coberto pelo plano"
    return f"R$ {value:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')

def clean_text(text):
    """Remove caracteres especiais e normaliza texto"""
    if not text:
        return ""
    
    # Remove quebras de linha extras
    text = re.sub(r'\n+', '\n', text.strip())
    
    # Remove espaços extras
    text = re.sub(r' +', ' ', text)
    
    return text

def validate_username(username):
    """Valida nome de usuário"""
    # Apenas letras, números e underscore
    # Entre 3 e 20 caracteres
    pattern = r'^[a-zA-Z0-9_]{3,20}$'
    return re.match(pattern, username) is not None

def validate_password(password):
    """Valida senha"""
    # Pelo menos 6 caracteres
    if len(password) < 6:
        return False, "Senha deve ter pelo menos 6 caracteres"
    
    return True, "Senha válida"

