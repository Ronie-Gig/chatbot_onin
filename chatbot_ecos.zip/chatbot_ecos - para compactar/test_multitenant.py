#!/usr/bin/env python3
"""
Script de teste para validar sistema multi-tenant
"""

import os
import sys
import json
from datetime import datetime

# Adiciona o diretório raiz ao path
sys.path.append(os.path.dirname(__file__))

def test_imports():
    """Testa se todos os imports funcionam"""
    try:
        print("🔍 Testando imports...")
        
        # Configuração de banco
        from src.config.database import DatabaseConfig
        print("  ✅ DatabaseConfig importado")
        
        # Modelos multi-tenant
        from src.models.multi_tenant import db, Clinic, User, Exam, Appointment, AdminUser
        print("  ✅ Modelos multi-tenant importados")
        
        # Utilitários multi-tenant
        from src.utils.multi_tenant import MultiTenantManager, require_clinic
        print("  ✅ Utilitários multi-tenant importados")
        
        # Scripts
        from src.data.initial_setup_multitenant import run_initial_setup
        print("  ✅ Setup inicial importado")
        
        from src.migrations.migrate_to_postgresql import DataMigrator
        print("  ✅ Migrador importado")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Erro no import: {e}")
        return False

def test_database_config():
    """Testa configuração do banco"""
    try:
        print("\n🔍 Testando configuração do banco...")
        
        from src.config.database import DatabaseConfig
        
        # Testa URL do banco
        db_url = DatabaseConfig.get_database_url()
        print(f"  📊 URL do banco: {db_url[:50]}...")
        
        # Testa tipo de banco
        is_postgres = DatabaseConfig.is_postgresql()
        is_sqlite = DatabaseConfig.is_sqlite()
        
        print(f"  📊 PostgreSQL: {is_postgres}")
        print(f"  📊 SQLite: {is_sqlite}")
        
        # Testa configuração completa
        config = DatabaseConfig.get_config()
        print(f"  ✅ Configuração gerada: {len(config)} parâmetros")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Erro na configuração: {e}")
        return False

def test_models():
    """Testa modelos multi-tenant"""
    try:
        print("\n🔍 Testando modelos...")
        
        from src.models.multi_tenant import Clinic, User, Exam, Appointment, AdminUser
        
        # Testa criação de instâncias
        clinic = Clinic(
            name='Teste Clinic',
            slug='teste',
            primary_color='#1627a3',
            secondary_color='#15aae5'
        )
        print("  ✅ Modelo Clinic criado")
        
        user = User(
            clinic_id=1,
            telegram_id='123456789',
            name='Usuário Teste'
        )
        print("  ✅ Modelo User criado")
        
        exam = Exam(
            clinic_id=1,
            exam_id='TEST001',
            exam_name='Exame Teste',
            category='Teste',
            price_particular=100.0,
            price_funeraria=80.0,
            price_unimed=0.0
        )
        print("  ✅ Modelo Exam criado")
        
        # Testa métodos
        clinic_dict = clinic.to_dict()
        print(f"  ✅ Clinic.to_dict(): {len(clinic_dict)} campos")
        
        user_session = user.get_session_data()
        print(f"  ✅ User.get_session_data(): {len(user_session)} campos")
        
        exam_price = exam.get_price('PARTICULAR')
        print(f"  ✅ Exam.get_price(): R$ {exam_price}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Erro nos modelos: {e}")
        return False

def test_multi_tenant_utils():
    """Testa utilitários multi-tenant"""
    try:
        print("\n🔍 Testando utilitários multi-tenant...")
        
        from src.utils.multi_tenant import MultiTenantManager, QueryFilter
        
        # Testa métodos estáticos
        print("  ✅ MultiTenantManager importado")
        print("  ✅ QueryFilter importado")
        
        # Testa decorators
        from src.utils.multi_tenant import require_clinic, clinic_context, super_admin_required
        print("  ✅ Decorators importados")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Erro nos utilitários: {e}")
        return False

def test_app_creation():
    """Testa criação da aplicação"""
    try:
        print("\n🔍 Testando criação da aplicação...")
        
        from src.main import create_app
        
        # Cria aplicação
        app = create_app()
        print("  ✅ Aplicação criada")
        
        # Testa configurações
        print(f"  📊 SECRET_KEY: {'Configurado' if app.config.get('SECRET_KEY') else 'Não configurado'}")
        print(f"  📊 DATABASE_URI: {'Configurado' if app.config.get('SQLALCHEMY_DATABASE_URI') else 'Não configurado'}")
        
        # Testa blueprints
        blueprint_names = [bp.name for bp in app.blueprints.values()]
        print(f"  ✅ Blueprints registrados: {', '.join(blueprint_names)}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Erro na criação da app: {e}")
        return False

def test_database_connection():
    """Testa conexão com banco"""
    try:
        print("\n🔍 Testando conexão com banco...")
        
        from src.main import create_app
        from src.models.multi_tenant import db
        
        app = create_app()
        
        with app.app_context():
            # Testa conexão
            db.session.execute(db.text('SELECT 1'))
            print("  ✅ Conexão com banco estabelecida")
            
            # Cria tabelas
            db.create_all()
            print("  ✅ Tabelas criadas/verificadas")
            
            return True
        
    except Exception as e:
        print(f"  ❌ Erro na conexão: {e}")
        return False

def test_initial_setup():
    """Testa configuração inicial"""
    try:
        print("\n🔍 Testando configuração inicial...")
        
        from src.main import create_app
        from src.data.initial_setup_multitenant import run_initial_setup
        from src.models.multi_tenant import db, Clinic, AdminUser
        
        app = create_app()
        
        with app.app_context():
            # Executa setup
            success = run_initial_setup()
            
            if success:
                print("  ✅ Setup inicial executado")
                
                # Verifica dados criados
                clinic_count = Clinic.query.count()
                admin_count = AdminUser.query.count()
                
                print(f"  📊 Clínicas criadas: {clinic_count}")
                print(f"  📊 Admins criados: {admin_count}")
                
                return True
            else:
                print("  ❌ Falha no setup inicial")
                return False
        
    except Exception as e:
        print(f"  ❌ Erro no setup: {e}")
        return False

def test_routes():
    """Testa rotas básicas"""
    try:
        print("\n🔍 Testando rotas...")
        
        from src.main import create_app
        
        app = create_app()
        
        with app.test_client() as client:
            # Testa health check
            response = client.get('/health')
            print(f"  📊 /health: {response.status_code}")
            
            if response.status_code == 200:
                data = response.get_json()
                print(f"  ✅ Health check: {data.get('status', 'unknown')}")
            
            # Testa lista de clínicas
            response = client.get('/api/clinics')
            print(f"  📊 /api/clinics: {response.status_code}")
            
            # Testa redirecionamento raiz
            response = client.get('/')
            print(f"  📊 /: {response.status_code} (redirect esperado)")
            
            return True
        
    except Exception as e:
        print(f"  ❌ Erro nas rotas: {e}")
        return False

def run_all_tests():
    """Executa todos os testes"""
    print("🚀 Iniciando testes do sistema multi-tenant")
    print("=" * 60)
    
    tests = [
        ("Imports", test_imports),
        ("Configuração do Banco", test_database_config),
        ("Modelos", test_models),
        ("Utilitários Multi-tenant", test_multi_tenant_utils),
        ("Criação da Aplicação", test_app_creation),
        ("Conexão com Banco", test_database_connection),
        ("Configuração Inicial", test_initial_setup),
        ("Rotas", test_routes)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ Erro crítico em {test_name}: {e}")
            results.append((test_name, False))
    
    # Relatório final
    print("\n" + "=" * 60)
    print("📊 RELATÓRIO FINAL DOS TESTES")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSOU" if result else "❌ FALHOU"
        print(f"{status} - {test_name}")
        if result:
            passed += 1
    
    print(f"\n📈 Resultado: {passed}/{total} testes passaram")
    
    if passed == total:
        print("🎉 Todos os testes passaram! Sistema multi-tenant funcionando.")
        return True
    else:
        print("⚠️ Alguns testes falharam. Verifique os erros acima.")
        return False

def main():
    """Função principal"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Testa sistema multi-tenant')
    parser.add_argument('--test', choices=[
        'imports', 'database', 'models', 'utils', 'app', 
        'connection', 'setup', 'routes', 'all'
    ], default='all', help='Teste específico para executar')
    
    args = parser.parse_args()
    
    if args.test == 'all':
        success = run_all_tests()
    else:
        test_map = {
            'imports': test_imports,
            'database': test_database_config,
            'models': test_models,
            'utils': test_multi_tenant_utils,
            'app': test_app_creation,
            'connection': test_database_connection,
            'setup': test_initial_setup,
            'routes': test_routes
        }
        
        test_func = test_map.get(args.test)
        if test_func:
            success = test_func()
        else:
            print(f"❌ Teste '{args.test}' não encontrado")
            success = False
    
    return 0 if success else 1

if __name__ == '__main__':
    exit(main())
