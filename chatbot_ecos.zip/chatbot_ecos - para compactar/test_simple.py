#!/usr/bin/env python3
"""
Teste simplificado das correções implementadas
"""

import sys
import os
sys.path.append('/home/ubuntu/chatbot_ecos_fixed')

def test_imports():
    """Testa se todos os imports funcionam"""
    print("🔍 Testando imports...")
    
    try:
        from src.models.chatbot import User, Exam, Appointment, AdminUser
        from src.services.chatbot_handler import ChatbotHandler
        from src.routes.webhook import webhook_bp
        from src.routes.dashboard import dashboard_bp
        from src.routes.auth import auth_bp
        
        print("✅ Imports: OK - todos os módulos carregaram")
        return True
        
    except Exception as e:
        print(f"❌ Imports: ERRO - {e}")
        return False

def test_user_methods():
    """Testa métodos do modelo User"""
    print("🔍 Testando métodos do User...")
    
    try:
        from src.models.chatbot import User
        
        # Cria instância sem banco
        user = User()
        user.current_state = 'START'
        user.covenant_type = 'PARTICULAR'
        user.selected_exams = None
        user.total_price = 0.0
        
        # Testa método get_session_data
        session_data = user.get_session_data()
        
        assert isinstance(session_data, dict)
        assert 'current_state' in session_data
        assert session_data['current_state'] == 'START'
        
        print("✅ User Methods: OK - get_session_data funcionando")
        return True
        
    except Exception as e:
        print(f"❌ User Methods: ERRO - {e}")
        return False

def test_appointment_fields():
    """Testa campos do modelo Appointment"""
    print("🔍 Testando campos do Appointment...")
    
    try:
        from src.models.chatbot import Appointment
        
        # Verifica se o campo scheduled_by existe
        appointment = Appointment()
        
        # Tenta definir o campo
        appointment.scheduled_by = 'teste'
        
        assert hasattr(appointment, 'scheduled_by')
        
        print("✅ Appointment Fields: OK - scheduled_by presente")
        return True
        
    except Exception as e:
        print(f"❌ Appointment Fields: ERRO - {e}")
        return False

def test_chatbot_handler_methods():
    """Testa métodos do ChatbotHandler"""
    print("🔍 Testando métodos do ChatbotHandler...")
    
    try:
        from src.services.chatbot_handler import ChatbotHandler
        
        handler = ChatbotHandler()
        
        # Verifica se os métodos existem
        assert hasattr(handler, 'process_message')
        assert hasattr(handler, 'cleanup_expired_sessions')
        assert hasattr(handler, 'get_session_stats')
        assert hasattr(handler, '_process_callback_message')
        
        print("✅ ChatbotHandler Methods: OK - todos os métodos presentes")
        return True
        
    except Exception as e:
        print(f"❌ ChatbotHandler Methods: ERRO - {e}")
        return False

def test_file_structure():
    """Testa estrutura de arquivos"""
    print("🔍 Testando estrutura de arquivos...")
    
    try:
        required_files = [
            'src/models/chatbot.py',
            'src/services/chatbot_handler.py',
            'src/routes/webhook.py',
            'src/routes/dashboard.py',
            'src/routes/auth.py',
            'src/main.py'
        ]
        
        base_path = '/home/ubuntu/chatbot_ecos_fixed'
        
        for file_path in required_files:
            full_path = os.path.join(base_path, file_path)
            assert os.path.exists(full_path), f"Arquivo {file_path} não encontrado"
        
        print("✅ File Structure: OK - todos os arquivos presentes")
        return True
        
    except Exception as e:
        print(f"❌ File Structure: ERRO - {e}")
        return False

def main():
    """Executa todos os testes"""
    print("🚀 Iniciando testes simplificados do ECOS Chatbot\n")
    
    tests = [
        test_file_structure,
        test_imports,
        test_user_methods,
        test_appointment_fields,
        test_chatbot_handler_methods
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
        print()
    
    print(f"📊 Resultado dos testes: {passed}/{total} passaram")
    
    if passed == total:
        print("🎉 Todos os testes passaram! Correções implementadas com sucesso.")
        return True
    else:
        print("⚠️ Alguns testes falharam. Verifique os erros acima.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
