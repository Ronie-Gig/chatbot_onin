#!/bin/bash
# Script de monitoramento automático do ECOS Chatbot
# Executa verificações periódicas e gera relatórios

set -e

# Cores para output
RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
BLUE='\\033[0;34m'
PURPLE='\\033[0;35m'
CYAN='\\033[0;36m'
NC='\\033[0m' # No Color

# Configurações
PROJECT_DIR=\"/opt/chatbot_ecos\"
LOG_DIR=\"/var/log/chatbot_ecos\"
MONITOR_LOG=\"$LOG_DIR/monitor.log\"
ALERT_LOG=\"$LOG_DIR/alerts.log\"
SERVICE_NAME=\"chatbot-ecos\"
DOMAIN=\"onindigital.com.br\"

# Thresholds
CPU_THRESHOLD=80
MEMORY_THRESHOLD=80
DISK_THRESHOLD=85
RESPONSE_TIME_THRESHOLD=5

# Função para log
log() {
    echo -e \"${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}\"
    echo \"[$(date +'%Y-%m-%d %H:%M:%S')] $1\" >> \"$MONITOR_LOG\"
}

error() {
    echo -e \"${RED}[ERROR] $1${NC}\"
    echo \"[$(date +'%Y-%m-%d %H:%M:%S')] [ERROR] $1\" >> \"$ALERT_LOG\"
}

warning() {
    echo -e \"${YELLOW}[WARNING] $1${NC}\"
    echo \"[$(date +'%Y-%m-%d %H:%M:%S')] [WARNING] $1\" >> \"$ALERT_LOG\"
}

info() {
    echo -e \"${BLUE}[INFO] $1${NC}\"
}

success() {
    echo -e \"${CYAN}[SUCCESS] $1${NC}\"
}

# Verifica se os diretórios de log existem
ensure_log_dirs() {
    mkdir -p \"$LOG_DIR\"
    touch \"$MONITOR_LOG\"
    touch \"$ALERT_LOG\"
}

# Verifica status do serviço
check_service_status() {
    info \"Verificando status dos serviços...\"
    
    # Chatbot principal
    if systemctl is-active --quiet \"$SERVICE_NAME\"; then
        log \"✅ Serviço $SERVICE_NAME está ativo\"
    else
        error \"❌ Serviço $SERVICE_NAME não está ativo\"
        return 1
    fi
    
    # Nginx
    if systemctl is-active --quiet nginx; then
        log \"✅ Nginx está ativo\"
    else
        error \"❌ Nginx não está ativo\"
        return 1
    fi
    
    # PostgreSQL
    if systemctl is-active --quiet postgresql; then
        log \"✅ PostgreSQL está ativo\"
    else
        error \"❌ PostgreSQL não está ativo\"
        return 1
    fi
    
    # Redis
    if systemctl is-active --quiet redis-server; then
        log \"✅ Redis está ativo\"
    else
        error \"❌ Redis não está ativo\"
        return 1
    fi
    
    # Evolution API
    if systemctl is-active --quiet evolution-api; then
        log \"✅ Evolution API está ativa\"
    else
        warning \"⚠️ Evolution API não está ativa\"
    fi
    
    return 0
}

# Verifica recursos do sistema
check_system_resources() {
    info \"Verificando recursos do sistema...\"
    
    # CPU
    CPU_USAGE=$(top -bn1 | grep \"Cpu(s)\" | awk '{print $2}' | cut -d'%' -f1)
    CPU_USAGE=${CPU_USAGE%.*}  # Remove decimais
    
    if [ \"$CPU_USAGE\" -gt \"$CPU_THRESHOLD\" ]; then
        warning \"CPU usage alto: ${CPU_USAGE}%\"
    else
        log \"CPU usage: ${CPU_USAGE}%\"
    fi
    
    # Memória
    MEMORY_USAGE=$(free | grep Mem | awk '{printf \"%.0f\", $3/$2 * 100.0}')
    
    if [ \"$MEMORY_USAGE\" -gt \"$MEMORY_THRESHOLD\" ]; then
        warning \"Memory usage alto: ${MEMORY_USAGE}%\"
    else
        log \"Memory usage: ${MEMORY_USAGE}%\"
    fi
    
    # Disco
    DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | cut -d'%' -f1)
    
    if [ \"$DISK_USAGE\" -gt \"$DISK_THRESHOLD\" ]; then
        warning \"Disk usage alto: ${DISK_USAGE}%\"
    else
        log \"Disk usage: ${DISK_USAGE}%\"
    fi
    
    # Load average
    LOAD_AVG=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | cut -d',' -f1)
    log \"Load average: $LOAD_AVG\"
}

# Verifica conectividade da aplicação
check_application_health() {
    info \"Verificando saúde da aplicação...\"
    
    # Health check local
    if curl -s -f http://localhost:5000/health > /dev/null; then
        log \"✅ Health check local OK\"
    else
        error \"❌ Health check local falhou\"
        return 1
    fi
    
    # Verifica tempo de resposta
    RESPONSE_TIME=$(curl -o /dev/null -s -w '%{time_total}' http://localhost:5000/health)
    RESPONSE_TIME_INT=$(echo \"$RESPONSE_TIME * 1000 / 1\" | bc)  # Converte para ms
    
    if [ \"$RESPONSE_TIME_INT\" -gt \"$((RESPONSE_TIME_THRESHOLD * 1000))\" ]; then
        warning \"Tempo de resposta alto: ${RESPONSE_TIME}s\"
    else
        log \"Tempo de resposta: ${RESPONSE_TIME}s\"
    fi
    
    # Verifica HTTPS (se configurado)
    if curl -s -f https://chatbot.\"$DOMAIN\"/health > /dev/null 2>&1; then
        log \"✅ HTTPS health check OK\"
    else
        warning \"⚠️ HTTPS health check falhou (pode não estar configurado)\"
    fi
    
    return 0
}

# Verifica banco de dados
check_database() {
    info \"Verificando banco de dados...\"
    
    # Conectividade PostgreSQL
    if sudo -u postgres psql -c \"SELECT 1;\" > /dev/null 2>&1; then
        log \"✅ PostgreSQL conectividade OK\"
    else
        error \"❌ PostgreSQL conectividade falhou\"
        return 1
    fi
    
    # Verifica tamanho do banco
    DB_SIZE=$(sudo -u postgres psql -d chatbot_ecos -t -c \"SELECT pg_size_pretty(pg_database_size('chatbot_ecos'));\" 2>/dev/null | xargs)
    if [ -n \"$DB_SIZE\" ]; then
        log \"Tamanho do banco: $DB_SIZE\"
    else
        warning \"Não foi possível obter tamanho do banco\"
    fi
    
    # Verifica conexões ativas
    ACTIVE_CONNECTIONS=$(sudo -u postgres psql -d chatbot_ecos -t -c \"SELECT count(*) FROM pg_stat_activity WHERE state = 'active';\" 2>/dev/null | xargs)
    if [ -n \"$ACTIVE_CONNECTIONS\" ]; then
        log \"Conexões ativas: $ACTIVE_CONNECTIONS\"
    fi
    
    return 0
}

# Verifica logs de erro
check_error_logs() {
    info \"Verificando logs de erro...\"
    
    # Verifica logs do serviço principal
    ERROR_COUNT=$(journalctl -u \"$SERVICE_NAME\" --since \"1 hour ago\" --no-pager | grep -i error | wc -l)
    if [ \"$ERROR_COUNT\" -gt 0 ]; then
        warning \"$ERROR_COUNT erros encontrados nos logs do $SERVICE_NAME na última hora\"
    else
        log \"Nenhum erro encontrado nos logs do $SERVICE_NAME\"
    fi
    
    # Verifica logs do Nginx
    if [ -f \"/var/log/nginx/chatbot_error.log\" ]; then
        NGINX_ERRORS=$(tail -n 100 /var/log/nginx/chatbot_error.log | grep \"$(date +'%Y/%m/%d %H')\" | wc -l)
        if [ \"$NGINX_ERRORS\" -gt 0 ]; then
            warning \"$NGINX_ERRORS erros encontrados nos logs do Nginx na última hora\"
        else
            log \"Nenhum erro encontrado nos logs do Nginx\"
        fi
    fi
}

# Verifica certificados SSL
check_ssl_certificates() {
    info \"Verificando certificados SSL...\"
    
    CERT_FILE=\"/etc/letsencrypt/live/$DOMAIN/fullchain.pem\"
    
    if [ -f \"$CERT_FILE\" ]; then
        # Verifica validade do certificado
        CERT_EXPIRY=$(openssl x509 -enddate -noout -in \"$CERT_FILE\" | cut -d= -f2)
        CERT_EXPIRY_EPOCH=$(date -d \"$CERT_EXPIRY\" +%s)
        CURRENT_EPOCH=$(date +%s)
        DAYS_UNTIL_EXPIRY=$(( (CERT_EXPIRY_EPOCH - CURRENT_EPOCH) / 86400 ))
        
        if [ \"$DAYS_UNTIL_EXPIRY\" -lt 30 ]; then
            warning \"Certificado SSL expira em $DAYS_UNTIL_EXPIRY dias\"
        else
            log \"Certificado SSL válido por $DAYS_UNTIL_EXPIRY dias\"
        fi
    else
        warning \"Certificado SSL não encontrado\"
    fi
}

# Verifica espaço em disco
check_disk_space() {
    info \"Verificando espaço em disco...\"
    
    # Diretório principal
    ROOT_USAGE=$(df / | tail -1 | awk '{print $5}' | cut -d'%' -f1)
    log \"Uso do disco raiz: ${ROOT_USAGE}%\"
    
    # Diretório de logs
    if [ -d \"$LOG_DIR\" ]; then
        LOG_SIZE=$(du -sh \"$LOG_DIR\" | cut -f1)
        log \"Tamanho dos logs: $LOG_SIZE\"
    fi
    
    # Diretório de uploads
    if [ -d \"/var/uploads/chatbot_ecos\" ]; then
        UPLOAD_SIZE=$(du -sh \"/var/uploads/chatbot_ecos\" | cut -f1)
        log \"Tamanho dos uploads: $UPLOAD_SIZE\"
    fi
}

# Gera relatório de status
generate_status_report() {
    info \"Gerando relatório de status...\"
    
    REPORT_FILE=\"$LOG_DIR/status_report_$(date +'%Y%m%d_%H%M%S').txt\"
    
    cat > \"$REPORT_FILE\" << EOF
ECOS Chatbot - Relatório de Status
==================================
Data: $(date)
Servidor: $(hostname)
Uptime: $(uptime -p)

SERVIÇOS:
$(systemctl is-active $SERVICE_NAME nginx postgresql redis-server evolution-api | paste <(echo -e \"$SERVICE_NAME\\nnginx\\npostgresql\\nredis-server\\nevolution-api\") -)

RECURSOS:
CPU: $(top -bn1 | grep \"Cpu(s)\" | awk '{print $2}')
Memória: $(free -h | grep Mem | awk '{print $3 \"/\" $2}')
Disco: $(df -h / | tail -1 | awk '{print $3 \"/\" $2 \" (\" $5 \" usado)\"}')
Load: $(uptime | awk -F'load average:' '{print $2}')

REDE:
$(ss -tuln | grep -E ':(80|443|5000|5432|6379|8080)' | wc -l) portas ativas

BANCO DE DADOS:
$(sudo -u postgres psql -d chatbot_ecos -t -c \"SELECT 'Tamanho: ' || pg_size_pretty(pg_database_size('chatbot_ecos'));\" 2>/dev/null || echo \"Erro ao acessar banco\")

LOGS RECENTES:
Erros na última hora: $(journalctl -u $SERVICE_NAME --since \"1 hour ago\" --no-pager | grep -i error | wc -l)

EOF
    
    log \"Relatório salvo em: $REPORT_FILE\"
}

# Função de limpeza automática
cleanup_old_files() {
    info \"Limpando arquivos antigos...\"
    
    # Remove logs antigos (mais de 30 dias)
    find \"$LOG_DIR\" -name \"*.log\" -mtime +30 -delete 2>/dev/null || true
    find \"$LOG_DIR\" -name \"status_report_*.txt\" -mtime +7 -delete 2>/dev/null || true
    
    # Limpa logs do journalctl (mantém 1 mês)
    journalctl --vacuum-time=30d > /dev/null 2>&1 || true
    
    log \"Limpeza concluída\"
}

# Função principal de monitoramento
run_monitoring() {
    local exit_code=0
    
    log \"=== Iniciando monitoramento ===\"
    
    # Executa todas as verificações
    check_service_status || exit_code=1
    check_system_resources
    check_application_health || exit_code=1
    check_database || exit_code=1
    check_error_logs
    check_ssl_certificates
    check_disk_space
    
    # Gera relatório se solicitado
    if [ \"$1\" = \"--report\" ]; then
        generate_status_report
    fi
    
    # Limpeza automática
    if [ \"$1\" = \"--cleanup\" ]; then
        cleanup_old_files
    fi
    
    if [ $exit_code -eq 0 ]; then
        success \"Monitoramento concluído - Sistema saudável\"
    else
        error \"Monitoramento concluído - Problemas detectados\"
    fi
    
    log \"=== Monitoramento finalizado ===\"
    
    return $exit_code
}

# Função de ajuda
show_help() {
    echo \"ECOS Chatbot - Script de Monitoramento\"
    echo \"======================================\"
    echo
    echo \"Uso: $0 [opções]\"
    echo
    echo \"Opções:\"
    echo \"  --help      Exibe esta ajuda\"
    echo \"  --report    Gera relatório detalhado\"
    echo \"  --cleanup   Executa limpeza de arquivos antigos\"
    echo \"  --status    Exibe apenas status dos serviços\"
    echo \"  --health    Executa apenas health check\"
    echo
    echo \"Exemplos:\"
    echo \"  $0                    # Monitoramento completo\"
    echo \"  $0 --report          # Monitoramento + relatório\"
    echo \"  $0 --status          # Apenas status dos serviços\"
    echo \"  $0 --health          # Apenas health check\"
    echo
}

# Função para status rápido
quick_status() {
    echo \"ECOS Chatbot - Status Rápido\"
    echo \"=============================\"
    echo
    
    # Serviços
    echo \"Serviços:\"
    for service in \"$SERVICE_NAME\" nginx postgresql redis-server evolution-api; do
        if systemctl is-active --quiet \"$service\"; then
            echo \"  ✅ $service\"
        else
            echo \"  ❌ $service\"
        fi
    done
    echo
    
    # Recursos
    echo \"Recursos:\"
    echo \"  CPU: $(top -bn1 | grep \"Cpu(s)\" | awk '{print $2}')\"
    echo \"  Memória: $(free -h | grep Mem | awk '{print $3 \"/\" $2}')\"
    echo \"  Disco: $(df -h / | tail -1 | awk '{print $5}')\"
    echo
    
    # Health check
    if curl -s -f http://localhost:5000/health > /dev/null; then
        echo \"  ✅ Aplicação respondendo\"
    else
        echo \"  ❌ Aplicação não responde\"
    fi
}

# Função para health check simples
simple_health_check() {
    local exit_code=0
    
    # Verifica serviço principal
    if ! systemctl is-active --quiet \"$SERVICE_NAME\"; then
        echo \"❌ Serviço principal não está ativo\"
        exit_code=1
    fi
    
    # Verifica aplicação
    if ! curl -s -f http://localhost:5000/health > /dev/null; then
        echo \"❌ Aplicação não responde\"
        exit_code=1
    fi
    
    if [ $exit_code -eq 0 ]; then
        echo \"✅ Sistema saudável\"
    fi
    
    return $exit_code
}

# Programa principal
main() {
    ensure_log_dirs
    
    case \"$1\" in
        --help)
            show_help
            ;;
        --status)
            quick_status
            ;;
        --health)
            simple_health_check
            ;;
        --report)
            run_monitoring --report
            ;;
        --cleanup)
            run_monitoring --cleanup
            ;;
        \"\")
            run_monitoring
            ;;
        *)
            echo \"Opção inválida: $1\"
            echo \"Use --help para ver as opções disponíveis\"
            exit 1
            ;;
    esac
}

# Executa programa principal
main \"$@\""
