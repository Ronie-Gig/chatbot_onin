#!/bin/bash
# Script para configurar SSL com Let's Encrypt
# Para domínio onindigital.com.br

set -e

echo \"🔒 Configurando SSL para ECOS Chatbot\"
echo \"======================================\"

# Cores para output
RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
BLUE='\\033[0;34m'
NC='\\033[0m' # No Color

# Variáveis
DOMAIN=\"onindigital.com.br\"
EMAIL=\"contato@onindigital.com.br\"  # Altere para seu email
WEBROOT=\"/var/www/certbot\"

# Função para log
log() {
    echo -e \"${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}\"
}

error() {
    echo -e \"${RED}[ERROR] $1${NC}\"
    exit 1
}

warning() {
    echo -e \"${YELLOW}[WARNING] $1${NC}\"
}

info() {
    echo -e \"${BLUE}[INFO] $1${NC}\"
}

# Verifica se está rodando como root
if [[ $EUID -ne 0 ]]; then
   error \"Este script deve ser executado como root (use sudo)\"
fi

# Verifica se o domínio está apontando para este servidor
check_dns() {
    log \"Verificando DNS para $DOMAIN...\"
    
    SERVER_IP=$(curl -s ifconfig.me)
    DOMAIN_IP=$(dig +short $DOMAIN)
    
    if [ \"$SERVER_IP\" = \"$DOMAIN_IP\" ]; then
        log \"✅ DNS configurado corretamente: $DOMAIN -> $SERVER_IP\"
    else
        warning \"⚠️ DNS pode não estar configurado corretamente\"
        info \"IP do servidor: $SERVER_IP\"
        info \"IP do domínio: $DOMAIN_IP\"
        read -p \"Deseja continuar mesmo assim? (y/N): \" -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            error \"Configuração cancelada\"
        fi
    fi
}

# Instala dependências
install_dependencies() {
    log \"Instalando dependências...\"
    
    # Atualiza repositórios
    apt update
    
    # Instala nginx se não estiver instalado
    if ! command -v nginx &> /dev/null; then
        log \"Instalando Nginx...\"
        apt install -y nginx
    else
        log \"✅ Nginx já instalado\"
    fi
    
    # Instala certbot
    if ! command -v certbot &> /dev/null; then
        log \"Instalando Certbot...\"
        apt install -y certbot python3-certbot-nginx
    else
        log \"✅ Certbot já instalado\"
    fi
    
    # Instala outras dependências
    apt install -y curl dig
}

# Configura nginx básico para certbot
setup_nginx_basic() {
    log \"Configurando Nginx básico para Certbot...\"
    
    # Cria diretório webroot
    mkdir -p $WEBROOT
    chown -R www-data:www-data $WEBROOT
    
    # Configuração básica do nginx para certbot
    cat > /etc/nginx/sites-available/certbot-temp << EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN chatbot.$DOMAIN ecos.$DOMAIN whatsapp.$DOMAIN;
    
    location /.well-known/acme-challenge/ {
        root $WEBROOT;
    }
    
    location / {
        return 200 'Configurando SSL...';
        add_header Content-Type text/plain;
    }
}
EOF
    
    # Remove configuração padrão se existir
    rm -f /etc/nginx/sites-enabled/default
    rm -f /etc/nginx/sites-enabled/chatbot_ecos
    
    # Ativa configuração temporária
    ln -sf /etc/nginx/sites-available/certbot-temp /etc/nginx/sites-enabled/
    
    # Testa configuração
    nginx -t || error \"Erro na configuração do Nginx\"
    
    # Reinicia nginx
    systemctl restart nginx
    log \"✅ Nginx configurado para Certbot\"
}

# Obtém certificados SSL
obtain_certificates() {
    log \"Obtendo certificados SSL...\"
    
    # Comando certbot
    certbot certonly \\
        --webroot \\
        --webroot-path=$WEBROOT \\
        --email $EMAIL \\
        --agree-tos \\
        --no-eff-email \\
        --expand \\
        -d $DOMAIN \\
        -d www.$DOMAIN \\
        -d chatbot.$DOMAIN \\
        -d ecos.$DOMAIN \\
        -d whatsapp.$DOMAIN \\
        || error \"Falha ao obter certificados SSL\"
    
    log \"✅ Certificados SSL obtidos com sucesso\"
}

# Configura nginx final
setup_nginx_final() {
    log \"Configurando Nginx final...\"
    
    # Copia configuração do projeto
    cp \"$(dirname \"$0\")/nginx.conf\" /etc/nginx/sites-available/chatbot_ecos
    
    # Remove configuração temporária
    rm -f /etc/nginx/sites-enabled/certbot-temp
    
    # Ativa configuração final
    ln -sf /etc/nginx/sites-available/chatbot_ecos /etc/nginx/sites-enabled/
    
    # Testa configuração
    nginx -t || error \"Erro na configuração final do Nginx\"
    
    # Reinicia nginx
    systemctl restart nginx
    log \"✅ Nginx configurado com SSL\"
}

# Configura renovação automática
setup_auto_renewal() {
    log \"Configurando renovação automática...\"
    
    # Cria script de renovação
    cat > /etc/cron.d/certbot-renewal << EOF
# Renovação automática de certificados SSL
0 12 * * * root certbot renew --quiet --post-hook \"systemctl reload nginx\"
EOF
    
    # Testa renovação
    certbot renew --dry-run || warning \"Teste de renovação falhou\"
    
    log \"✅ Renovação automática configurada\"
}

# Configura firewall
setup_firewall() {
    log \"Configurando firewall...\"
    
    if command -v ufw &> /dev/null; then
        # Permite SSH, HTTP e HTTPS
        ufw allow ssh
        ufw allow 'Nginx Full'
        ufw --force enable
        log \"✅ Firewall configurado\"
    else
        warning \"UFW não instalado, configure o firewall manualmente\"
    fi
}

# Testa configuração final
test_ssl() {
    log \"Testando configuração SSL...\"
    
    # Testa HTTPS
    if curl -s -I https://$DOMAIN | grep -q \"200 OK\"; then
        log \"✅ HTTPS funcionando\"
    else
        warning \"⚠️ Problema com HTTPS\"
    fi
    
    # Testa redirecionamento
    if curl -s -I http://$DOMAIN | grep -q \"301\"; then
        log \"✅ Redirecionamento HTTP->HTTPS funcionando\"
    else
        warning \"⚠️ Problema com redirecionamento\"
    fi
    
    # Testa subdomínios
    for subdomain in \"chatbot\" \"ecos\" \"whatsapp\"; do
        if curl -s -I https://$subdomain.$DOMAIN | grep -q -E \"(200|301|302)\"; then
            log \"✅ Subdomínio $subdomain funcionando\"
        else
            warning \"⚠️ Problema com subdomínio $subdomain\"
        fi
    done
}

# Função principal
main() {
    log \"Iniciando configuração SSL para $DOMAIN\"
    
    # Verifica DNS
    check_dns
    
    # Instala dependências
    install_dependencies
    
    # Configura nginx básico
    setup_nginx_basic
    
    # Obtém certificados
    obtain_certificates
    
    # Configura nginx final
    setup_nginx_final
    
    # Configura renovação automática
    setup_auto_renewal
    
    # Configura firewall
    setup_firewall
    
    # Testa configuração
    test_ssl
    
    log \"🎉 Configuração SSL concluída com sucesso!\"
    echo
    info \"URLs disponíveis:\"
    info \"  • https://$DOMAIN\"
    info \"  • https://www.$DOMAIN\"
    info \"  • https://chatbot.$DOMAIN\"
    info \"  • https://ecos.$DOMAIN\"
    info \"  • https://whatsapp.$DOMAIN\"
    echo
    info \"Próximos passos:\"
    info \"  1. Configure os registros DNS para apontar para este servidor\"
    info \"  2. Inicie a aplicação Flask\"
    info \"  3. Configure os webhooks das plataformas\"
    echo
}

# Executa função principal
main \"$@\""
