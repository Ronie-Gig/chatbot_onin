#!/bin/bash
# Script de instalação automatizada do ECOS Chatbot Omnichannel
# Sistema completo multi-tenant com suporte a Telegram, WhatsApp, Facebook e Instagram

set -e

# Cores para output
RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
BLUE='\\033[0;34m'
PURPLE='\\033[0;35m'
CYAN='\\033[0;36m'
NC='\\033[0m' # No Color

# Variáveis de configuração
PROJECT_NAME=\"ECOS Chatbot Omnichannel\"
PROJECT_DIR=\"/opt/chatbot_ecos\"
VENV_DIR=\"$PROJECT_DIR/venv\"
LOG_DIR=\"/var/log/chatbot_ecos\"
UPLOAD_DIR=\"/var/uploads/chatbot_ecos\"
SERVICE_NAME=\"chatbot-ecos\"
DOMAIN=\"onindigital.com.br\"

# Função para log
log() {
    echo -e \"${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}\"
}

error() {
    echo -e \"${RED}[ERROR] $1${NC}\"
    exit 1
}

warning() {
    echo -e \"${YELLOW}[WARNING] $1${NC}\"
}

info() {
    echo -e \"${BLUE}[INFO] $1${NC}\"
}

success() {
    echo -e \"${CYAN}[SUCCESS] $1${NC}\"
}

header() {
    echo -e \"${PURPLE}\"
    echo \"======================================\"
    echo \"  $1\"
    echo \"======================================\"
    echo -e \"${NC}\"
}

# Verifica se está rodando como root
check_root() {
    if [[ $EUID -ne 0 ]]; then
       error \"Este script deve ser executado como root (use sudo)\"
    fi
}

# Detecta sistema operacional
detect_os() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
    else
        error \"Sistema operacional não suportado\"
    fi
    
    log \"Sistema detectado: $OS $VER\"
    
    # Verifica se é Ubuntu/Debian
    if [[ $OS != *\"Ubuntu\"* ]] && [[ $OS != *\"Debian\"* ]]; then
        warning \"Este script foi testado apenas no Ubuntu/Debian\"
        read -p \"Deseja continuar mesmo assim? (y/N): \" -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            error \"Instalação cancelada\"
        fi
    fi
}

# Atualiza sistema
update_system() {
    header \"Atualizando Sistema\"
    
    log \"Atualizando repositórios...\"
    apt update
    
    log \"Atualizando pacotes...\"
    apt upgrade -y
    
    success \"Sistema atualizado\"
}

# Instala dependências do sistema
install_system_dependencies() {
    header \"Instalando Dependências do Sistema\"
    
    log \"Instalando pacotes essenciais...\"
    apt install -y \\
        python3 \\
        python3-pip \\
        python3-venv \\
        python3-dev \\
        build-essential \\
        curl \\
        wget \\
        git \\
        nginx \\
        postgresql \\
        postgresql-contrib \\
        redis-server \\
        supervisor \\
        certbot \\
        python3-certbot-nginx \\
        ufw \\
        htop \\
        nano \\
        vim \\
        unzip \\
        software-properties-common \\
        apt-transport-https \\
        ca-certificates \\
        gnupg \\
        lsb-release
    
    success \"Dependências do sistema instaladas\"
}

# Configura PostgreSQL
setup_postgresql() {
    header \"Configurando PostgreSQL\"
    
    log \"Iniciando serviço PostgreSQL...\"
    systemctl start postgresql
    systemctl enable postgresql
    
    # Cria usuário e banco de dados
    log \"Criando banco de dados...\"
    sudo -u postgres psql << EOF
CREATE USER chatbot_user WITH PASSWORD 'chatbot_password_2025';
CREATE DATABASE chatbot_ecos OWNER chatbot_user;
GRANT ALL PRIVILEGES ON DATABASE chatbot_ecos TO chatbot_user;
\\q
EOF
    
    success \"PostgreSQL configurado\"
}

# Configura Redis
setup_redis() {
    header \"Configurando Redis\"
    
    log \"Iniciando serviço Redis...\"
    systemctl start redis-server
    systemctl enable redis-server
    
    # Configura Redis para produção
    sed -i 's/^# maxmemory <bytes>/maxmemory 256mb/' /etc/redis/redis.conf
    sed -i 's/^# maxmemory-policy noeviction/maxmemory-policy allkeys-lru/' /etc/redis/redis.conf
    
    systemctl restart redis-server
    
    success \"Redis configurado\"
}

# Cria usuário do sistema
create_system_user() {
    header \"Criando Usuário do Sistema\"
    
    if ! id \"chatbot\" &>/dev/null; then
        log \"Criando usuário chatbot...\"
        useradd -r -s /bin/bash -d $PROJECT_DIR chatbot
        success \"Usuário chatbot criado\"
    else
        log \"Usuário chatbot já existe\"
    fi
}

# Cria diretórios
create_directories() {
    header \"Criando Diretórios\"
    
    log \"Criando estrutura de diretórios...\"
    mkdir -p $PROJECT_DIR
    mkdir -p $LOG_DIR
    mkdir -p $UPLOAD_DIR
    mkdir -p /var/www/certbot
    
    # Define permissões
    chown -R chatbot:chatbot $PROJECT_DIR
    chown -R chatbot:chatbot $LOG_DIR
    chown -R chatbot:chatbot $UPLOAD_DIR
    chown -R www-data:www-data /var/www/certbot
    
    success \"Diretórios criados\"
}

# Instala aplicação
install_application() {
    header \"Instalando Aplicação\"
    
    log \"Copiando arquivos da aplicação...\"
    
    # Copia arquivos do projeto
    SCRIPT_DIR=\"$(cd \"$(dirname \"${BASH_SOURCE[0]}\")\" && pwd)\"
    PROJECT_SOURCE=\"$(dirname \"$SCRIPT_DIR\")\"
    
    cp -r \"$PROJECT_SOURCE\"/* $PROJECT_DIR/
    chown -R chatbot:chatbot $PROJECT_DIR
    
    # Cria ambiente virtual
    log \"Criando ambiente virtual Python...\"
    sudo -u chatbot python3 -m venv $VENV_DIR
    
    # Instala dependências Python
    log \"Instalando dependências Python...\"
    sudo -u chatbot $VENV_DIR/bin/pip install --upgrade pip
    sudo -u chatbot $VENV_DIR/bin/pip install -r $PROJECT_DIR/requirements.txt
    
    # Instala dependências adicionais para produção
    sudo -u chatbot $VENV_DIR/bin/pip install \\
        gunicorn \\
        psycopg2-binary \\
        redis \\
        sentry-sdk[flask] \\
        flask-limiter
    
    success \"Aplicação instalada\"
}

# Configura banco de dados da aplicação
setup_application_database() {
    header \"Configurando Banco de Dados da Aplicação\"
    
    # Cria arquivo de configuração
    log \"Criando arquivo de configuração...\"
    cat > $PROJECT_DIR/.env << EOF
# Configuração de Produção
FLASK_ENV=production
SECRET_KEY=$(openssl rand -hex 32)

# Banco de Dados
DATABASE_URL=postgresql://chatbot_user:chatbot_password_2025@localhost/chatbot_ecos

# Telegram
TELEGRAM_BOT_TOKEN=
TELEGRAM_WEBHOOK_URL=https://chatbot.$DOMAIN/webhook/telegram

# WhatsApp (Evolution API)
WHATSAPP_BASE_URL=http://localhost:8080
WHATSAPP_API_KEY=
WHATSAPP_INSTANCE_NAME=ecos_instance

# Facebook/Instagram
FACEBOOK_PAGE_ACCESS_TOKEN=
FACEBOOK_VERIFY_TOKEN=$(openssl rand -hex 16)
FACEBOOK_APP_SECRET=

# Email
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=
MAIL_PASSWORD=

# Logs
LOG_LEVEL=INFO

# Domínio
DOMAIN=$DOMAIN
EOF
    
    chown chatbot:chatbot $PROJECT_DIR/.env
    chmod 600 $PROJECT_DIR/.env
    
    # Inicializa banco de dados
    log \"Inicializando banco de dados...\"
    cd $PROJECT_DIR
    sudo -u chatbot $VENV_DIR/bin/python -c \"
from src.main_production import create_app
from src.models.multi_tenant import db

app = create_app('production')
with app.app_context():
    db.create_all()
    print('Banco de dados inicializado')
\"
    
    # Popula dados iniciais
    log \"Inserindo dados iniciais...\"
    sudo -u chatbot $VENV_DIR/bin/python -c \"
from src.main_production import create_app
from src.data.initial_setup_multitenant import setup_initial_data

app = create_app('production')
with app.app_context():
    setup_initial_data()
    print('Dados iniciais inseridos')
\"
    
    success \"Banco de dados configurado\"
}

# Configura serviço systemd
setup_systemd_service() {
    header \"Configurando Serviço Systemd\"
    
    log \"Criando arquivo de serviço...\"
    cat > /etc/systemd/system/$SERVICE_NAME.service << EOF
[Unit]
Description=ECOS Chatbot Omnichannel
After=network.target postgresql.service redis.service
Wants=postgresql.service redis.service

[Service]
Type=exec
User=chatbot
Group=chatbot
WorkingDirectory=$PROJECT_DIR
Environment=PATH=$VENV_DIR/bin
EnvironmentFile=$PROJECT_DIR/.env
ExecStart=$VENV_DIR/bin/gunicorn --bind 127.0.0.1:5000 --workers 4 --timeout 120 --keep-alive 2 --max-requests 1000 --max-requests-jitter 100 src.main_production:create_app()
ExecReload=/bin/kill -s HUP \\$MAINPID
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=$SERVICE_NAME

# Limites de recursos
LimitNOFILE=65536
LimitNPROC=4096

# Segurança
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$PROJECT_DIR $LOG_DIR $UPLOAD_DIR

[Install]
WantedBy=multi-user.target
EOF
    
    # Recarrega systemd e habilita serviço
    systemctl daemon-reload
    systemctl enable $SERVICE_NAME
    
    success \"Serviço systemd configurado\"
}

# Configura Nginx
setup_nginx() {
    header \"Configurando Nginx\"
    
    log \"Copiando configuração do Nginx...\"
    cp $PROJECT_DIR/deploy/nginx.conf /etc/nginx/sites-available/chatbot_ecos
    
    # Remove configuração padrão
    rm -f /etc/nginx/sites-enabled/default
    
    # Ativa nova configuração
    ln -sf /etc/nginx/sites-available/chatbot_ecos /etc/nginx/sites-enabled/
    
    # Testa configuração
    nginx -t || error \"Erro na configuração do Nginx\"
    
    success \"Nginx configurado\"
}

# Configura firewall
setup_firewall() {
    header \"Configurando Firewall\"
    
    log \"Configurando UFW...\"
    
    # Reseta firewall
    ufw --force reset
    
    # Permite SSH
    ufw allow ssh
    
    # Permite HTTP e HTTPS
    ufw allow 'Nginx Full'
    
    # Permite PostgreSQL apenas localmente
    ufw allow from 127.0.0.1 to any port 5432
    
    # Permite Redis apenas localmente
    ufw allow from 127.0.0.1 to any port 6379
    
    # Permite Evolution API (WhatsApp)
    ufw allow 8080
    
    # Ativa firewall
    ufw --force enable
    
    success \"Firewall configurado\"
}

# Configura logs
setup_logging() {
    header \"Configurando Logs\"
    
    log \"Configurando rotação de logs...\"
    cat > /etc/logrotate.d/chatbot-ecos << EOF
$LOG_DIR/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 chatbot chatbot
    postrotate
        systemctl reload $SERVICE_NAME
    endscript
}
EOF
    
    success \"Logs configurados\"
}

# Instala Evolution API (WhatsApp)
install_evolution_api() {
    header \"Instalando Evolution API (WhatsApp)\"
    
    # Verifica se Node.js está instalado
    if ! command -v node &> /dev/null; then
        log \"Instalando Node.js...\"
        curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
        apt install -y nodejs
    fi
    
    log \"Clonando Evolution API...\"
    cd /opt
    git clone https://github.com/EvolutionAPI/evolution-api.git
    cd evolution-api
    
    log \"Instalando dependências...\"
    npm install
    
    log \"Configurando Evolution API...\"
    cp .env.example .env
    
    # Configura variáveis básicas
    sed -i 's/SERVER_PORT=8080/SERVER_PORT=8080/' .env
    sed -i 's/CORS_ORIGIN=\\*/CORS_ORIGIN=https:\\/\\/chatbot.onindigital.com.br/' .env
    sed -i 's/DEL_INSTANCE=false/DEL_INSTANCE=true/' .env
    
    # Cria serviço systemd para Evolution API
    cat > /etc/systemd/system/evolution-api.service << EOF
[Unit]
Description=Evolution API - WhatsApp Integration
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/evolution-api
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable evolution-api
    
    success \"Evolution API instalada\"
}

# Inicia serviços
start_services() {
    header \"Iniciando Serviços\"
    
    log \"Iniciando PostgreSQL...\"
    systemctl start postgresql
    
    log \"Iniciando Redis...\"
    systemctl start redis-server
    
    log \"Iniciando Evolution API...\"
    systemctl start evolution-api
    
    log \"Iniciando aplicação...\"
    systemctl start $SERVICE_NAME
    
    log \"Iniciando Nginx...\"
    systemctl start nginx
    
    # Verifica status dos serviços
    sleep 5
    
    if systemctl is-active --quiet $SERVICE_NAME; then
        success \"Aplicação iniciada\"
    else
        error \"Falha ao iniciar aplicação\"
    fi
    
    if systemctl is-active --quiet nginx; then
        success \"Nginx iniciado\"
    else
        error \"Falha ao iniciar Nginx\"
    fi
    
    success \"Todos os serviços iniciados\"
}

# Testa instalação
test_installation() {
    header \"Testando Instalação\"
    
    log \"Testando aplicação...\"
    if curl -s http://localhost:5000/health | grep -q \"healthy\"; then
        success \"✅ Aplicação respondendo\"
    else
        warning \"⚠️ Problema com a aplicação\"
    fi
    
    log \"Testando Nginx...\"
    if curl -s -I http://localhost | grep -q \"nginx\"; then
        success \"✅ Nginx funcionando\"
    else
        warning \"⚠️ Problema com Nginx\"
    fi
    
    log \"Testando Evolution API...\"
    if curl -s http://localhost:8080 | grep -q -i \"evolution\"; then
        success \"✅ Evolution API funcionando\"
    else
        warning \"⚠️ Problema com Evolution API\"
    fi
    
    success \"Testes concluídos\"
}

# Exibe informações finais
show_final_info() {
    header \"Instalação Concluída\"
    
    echo -e \"${GREEN}🎉 ECOS Chatbot Omnichannel instalado com sucesso!${NC}\"
    echo
    info \"Informações importantes:\"
    echo
    info \"📁 Diretório do projeto: $PROJECT_DIR\"
    info \"📋 Logs: $LOG_DIR\"
    info \"📤 Uploads: $UPLOAD_DIR\"
    info \"🔧 Configuração: $PROJECT_DIR/.env\"
    echo
    info \"🌐 URLs locais (após configurar SSL):\"
    info \"  • Dashboard: https://chatbot.$DOMAIN\"
    info \"  • Clínica ECOS: https://ecos.$DOMAIN\"
    info \"  • Evolution API: https://whatsapp.$DOMAIN\"
    echo
    info \"👤 Credenciais padrão:\"
    info \"  • Super Admin: onindigital / onindigital2025@super\"
    info \"  • Master ECOS: master / ecos2025@master\"
    echo
    warning \"⚠️ PRÓXIMOS PASSOS OBRIGATÓRIOS:\"
    echo
    info \"1. Configure o DNS do domínio $DOMAIN para apontar para este servidor\"
    info \"2. Execute o script SSL: sudo $PROJECT_DIR/deploy/setup_ssl.sh\"
    info \"3. Configure os tokens das APIs no arquivo $PROJECT_DIR/.env:\"
    info \"   - TELEGRAM_BOT_TOKEN\"
    info \"   - WHATSAPP_API_KEY\"
    info \"   - FACEBOOK_PAGE_ACCESS_TOKEN\"
    info \"   - FACEBOOK_APP_SECRET\"
    info \"4. Reinicie os serviços: sudo systemctl restart $SERVICE_NAME\"
    echo
    info \"📚 Comandos úteis:\"
    info \"  • Status: sudo systemctl status $SERVICE_NAME\"
    info \"  • Logs: sudo journalctl -u $SERVICE_NAME -f\"
    info \"  • Reiniciar: sudo systemctl restart $SERVICE_NAME\"
    echo
    success \"Sistema pronto para configuração final!\"
}

# Função principal
main() {
    header \"$PROJECT_NAME - Instalação Automatizada\"
    
    log \"Iniciando instalação...\"
    
    # Verificações iniciais
    check_root
    detect_os
    
    # Instalação
    update_system
    install_system_dependencies
    setup_postgresql
    setup_redis
    create_system_user
    create_directories
    install_application
    setup_application_database
    setup_systemd_service
    setup_nginx
    setup_firewall
    setup_logging
    install_evolution_api
    start_services
    test_installation
    
    # Informações finais
    show_final_info
}

# Executa instalação
main \"$@\""
