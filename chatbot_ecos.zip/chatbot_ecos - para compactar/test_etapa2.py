#!/usr/bin/env python3
"""
Script de teste para validar todas as funcionalidades da Etapa 2
Dashboard Profissional com Visualização de Fotos e Sistema de Aprovação
"""

import os
import sys
import traceback
from datetime import datetime

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_imports():
    """Testa se todos os módulos podem ser importados"""
    print("🧪 Testando imports dos módulos...")
    
    try:
        # Testa imports básicos
        from src.models.multi_tenant import db, User, Clinic, AdminUser, Appointment
        from src.config.database import DatabaseConfig
        from src.utils.multi_tenant import MultiTenantManager
        print("✅ Imports básicos OK")
        
        # Testa novos serviços da Etapa 2
        from src.services.image_service_v2 import ImageService
        from src.services.notification_service import NotificationService
        print("✅ Serviços de imagem e notificação OK")
        
        # Testa rotas atualizadas
        from src.routes.dashboard_v2 import dashboard_bp
        from src.routes.super_admin import super_admin_bp
        from src.routes.auth_v2 import auth_bp
        print("✅ Rotas atualizadas OK")
        
        # Testa main atualizado
        from src.main_v2 import create_app
        print("✅ Aplicação principal OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro nos imports: {e}")
        traceback.print_exc()
        return False

def test_database_connection():
    """Testa conexão com banco de dados"""
    print("🧪 Testando conexão com banco de dados...")
    
    try:
        from src.main_v2 import create_app
        
        app = create_app()
        
        with app.app_context():
            from src.models.multi_tenant import db
            
            # Testa conexão
            db.session.execute(db.text('SELECT 1'))
            print("✅ Conexão com banco OK")
            
            # Cria tabelas se necessário
            db.create_all()
            print("✅ Tabelas criadas/verificadas OK")
            
            return True
            
    except Exception as e:
        print(f"❌ Erro na conexão com banco: {e}")
        traceback.print_exc()
        return False

def test_image_service():
    """Testa serviços de imagem"""
    print("🧪 Testando serviços de imagem...")
    
    try:
        from src.services.image_service_v2 import ImageService
        
        # Testa métodos básicos
        assert hasattr(ImageService, 'get_telegram_file_url'), "Método get_telegram_file_url não encontrado"
        assert hasattr(ImageService, 'approve_image'), "Método approve_image não encontrado"
        assert hasattr(ImageService, 'reject_image'), "Método reject_image não encontrado"
        assert hasattr(ImageService, 'get_pending_images'), "Método get_pending_images não encontrado"
        assert hasattr(ImageService, 'get_image_stats'), "Método get_image_stats não encontrado"
        
        print("✅ Métodos do ImageService OK")
        
        # Testa geração de URL proxy
        proxy_url = ImageService.get_image_proxy_url('test_file_id', 'telegram')
        print(f"✅ URL proxy gerada: {proxy_url}")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro nos serviços de imagem: {e}")
        traceback.print_exc()
        return False

def test_notification_service():
    """Testa serviços de notificação"""
    print("🧪 Testando serviços de notificação...")
    
    try:
        from src.services.notification_service import NotificationService
        
        # Testa métodos básicos
        assert hasattr(NotificationService, 'send_telegram_message'), "Método send_telegram_message não encontrado"
        assert hasattr(NotificationService, 'notify_image_approved'), "Método notify_image_approved não encontrado"
        assert hasattr(NotificationService, 'notify_image_rejected'), "Método notify_image_rejected não encontrado"
        assert hasattr(NotificationService, 'notify_appointment_confirmed'), "Método notify_appointment_confirmed não encontrado"
        
        print("✅ Métodos do NotificationService OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro nos serviços de notificação: {e}")
        traceback.print_exc()
        return False

def test_super_admin_routes():
    """Testa rotas do super administrador"""
    print("🧪 Testando rotas do super administrador...")
    
    try:
        from src.routes.super_admin import super_admin_bp
        
        # Verifica se blueprint foi criado
        assert super_admin_bp is not None, "Blueprint super_admin não foi criado"
        assert super_admin_bp.url_prefix == '/super', "URL prefix incorreto"
        
        # Verifica rotas registradas
        routes = [rule.rule for rule in super_admin_bp.url_map.iter_rules()]
        expected_routes = ['/super/dashboard', '/super/clinics', '/super/system/config']
        
        print(f"✅ Blueprint super_admin criado com {len(routes)} rotas")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro nas rotas super admin: {e}")
        traceback.print_exc()
        return False

def test_dashboard_v2():
    """Testa dashboard atualizado"""
    print("🧪 Testando dashboard v2...")
    
    try:
        from src.routes.dashboard_v2 import dashboard_bp
        
        # Verifica se blueprint foi criado
        assert dashboard_bp is not None, "Blueprint dashboard_v2 não foi criado"
        
        print("✅ Dashboard v2 carregado OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro no dashboard v2: {e}")
        traceback.print_exc()
        return False

def test_auth_v2():
    """Testa autenticação atualizada"""
    print("🧪 Testando autenticação v2...")
    
    try:
        from src.routes.auth_v2 import auth_bp, login_required, super_admin_required
        
        # Verifica se blueprint foi criado
        assert auth_bp is not None, "Blueprint auth_v2 não foi criado"
        
        # Verifica decorators
        assert callable(login_required), "Decorator login_required não é callable"
        assert callable(super_admin_required), "Decorator super_admin_required não é callable"
        
        print("✅ Autenticação v2 OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro na autenticação v2: {e}")
        traceback.print_exc()
        return False

def test_application_creation():
    """Testa criação da aplicação completa"""
    print("🧪 Testando criação da aplicação...")
    
    try:
        from src.main_v2 import create_app
        
        app = create_app()
        
        # Verifica se app foi criado
        assert app is not None, "Aplicação não foi criada"
        
        # Verifica configurações
        assert 'SECRET_KEY' in app.config, "SECRET_KEY não configurada"
        assert 'SQLALCHEMY_DATABASE_URI' in app.config, "Database URI não configurada"
        
        # Verifica blueprints registrados
        blueprint_names = [bp.name for bp in app.blueprints.values()]
        expected_blueprints = ['auth', 'webhook', 'dashboard', 'super_admin']
        
        print(f"✅ Aplicação criada com blueprints: {blueprint_names}")
        
        # Testa contexto da aplicação
        with app.app_context():
            from src.models.multi_tenant import db
            db.session.execute(db.text('SELECT 1'))
            print("✅ Contexto da aplicação OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro na criação da aplicação: {e}")
        traceback.print_exc()
        return False

def test_multi_tenant_functionality():
    """Testa funcionalidades multi-tenant"""
    print("🧪 Testando funcionalidades multi-tenant...")
    
    try:
        from src.main_v2 import create_app
        from src.utils.multi_tenant import MultiTenantManager
        from src.models.multi_tenant import Clinic
        
        app = create_app()
        
        with app.app_context():
            # Testa busca de clínica por slug
            clinic = Clinic.query.filter_by(slug='ecos').first()
            
            if clinic:
                # Testa definição de clínica atual
                MultiTenantManager.set_current_clinic_slug('ecos')
                current_clinic = MultiTenantManager.get_current_clinic()
                
                assert current_clinic is not None, "Clínica atual não foi definida"
                assert current_clinic.slug == 'ecos', "Slug da clínica incorreto"
                
                print(f"✅ Multi-tenant OK - Clínica: {current_clinic.name}")
            else:
                print("⚠️ Clínica ECOS não encontrada - executar setup inicial")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro no multi-tenant: {e}")
        traceback.print_exc()
        return False

def test_image_approval_workflow():
    """Testa fluxo de aprovação de imagens"""
    print("🧪 Testando fluxo de aprovação de imagens...")
    
    try:
        from src.main_v2 import create_app
        from src.services.image_service_v2 import ImageService
        
        app = create_app()
        
        with app.app_context():
            # Testa obtenção de estatísticas
            stats = ImageService.get_image_stats()
            assert isinstance(stats, dict), "Estatísticas devem ser um dict"
            assert 'total' in stats, "Estatística 'total' não encontrada"
            assert 'approved' in stats, "Estatística 'approved' não encontrada"
            assert 'pending' in stats, "Estatística 'pending' não encontrada"
            
            print(f"✅ Estatísticas de imagem: {stats}")
            
            # Testa obtenção de imagens pendentes
            pending = ImageService.get_pending_images()
            assert isinstance(pending, list), "Imagens pendentes devem ser uma lista"
            
            print(f"✅ Imagens pendentes: {len(pending)} encontradas")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro no fluxo de aprovação: {e}")
        traceback.print_exc()
        return False

def run_all_tests():
    """Executa todos os testes"""
    print("🚀 INICIANDO TESTES DA ETAPA 2 - DASHBOARD PROFISSIONAL")
    print("=" * 60)
    
    tests = [
        ("Imports", test_imports),
        ("Conexão com Banco", test_database_connection),
        ("Serviços de Imagem", test_image_service),
        ("Serviços de Notificação", test_notification_service),
        ("Rotas Super Admin", test_super_admin_routes),
        ("Dashboard v2", test_dashboard_v2),
        ("Autenticação v2", test_auth_v2),
        ("Criação da Aplicação", test_application_creation),
        ("Multi-tenant", test_multi_tenant_functionality),
        ("Fluxo de Aprovação", test_image_approval_workflow)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n📋 {test_name}")
        print("-" * 40)
        
        try:
            result = test_func()
            results.append((test_name, result))
            
            if result:
                print(f"✅ {test_name}: PASSOU")
            else:
                print(f"❌ {test_name}: FALHOU")
                
        except Exception as e:
            print(f"💥 {test_name}: ERRO - {e}")
            results.append((test_name, False))
    
    # Resumo final
    print("\n" + "=" * 60)
    print("📊 RESUMO DOS TESTES")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSOU" if result else "❌ FALHOU"
        print(f"{test_name:.<30} {status}")
    
    print("-" * 60)
    print(f"Total: {passed}/{total} testes passaram")
    
    if passed == total:
        print("\n🎉 TODOS OS TESTES PASSARAM!")
        print("✅ Etapa 2 está funcionando perfeitamente!")
        return True
    else:
        print(f"\n⚠️ {total - passed} teste(s) falharam")
        print("❌ Verifique os erros acima")
        return False

if __name__ == '__main__':
    success = run_all_tests()
    
    if success:
        print("\n🚀 ETAPA 2 CONCLUÍDA COM SUCESSO!")
        print("📱 Dashboard profissional com visualização de fotos implementado")
        print("🔧 Sistema de aprovação/reprovação funcionando")
        print("🎨 Branding On In Digital aplicado")
        print("👑 Gestão multi-clínicas para super admin ativa")
        
        print("\n📋 PRÓXIMOS PASSOS:")
        print("1. Execute: python src/main_v2.py")
        print("2. Acesse: http://127.0.0.1:5000/super/dashboard")
        print("3. Login: onindigital / onindigital2025@super")
        print("4. Teste todas as funcionalidades")
        
        sys.exit(0)
    else:
        print("\n❌ ETAPA 2 COM PROBLEMAS!")
        print("Verifique os erros acima antes de prosseguir")
        sys.exit(1)
