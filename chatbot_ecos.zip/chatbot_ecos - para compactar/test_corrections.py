#!/usr/bin/env python3
"""
Script de teste para validar as correções implementadas no sistema ECOS Chatbot
"""

import sys
import os
sys.path.append('/home/ubuntu/chatbot_ecos_fixed')

from src.models.chatbot import db, User, Exam, Appointment, AdminUser
from src.services.chatbot_handler import ChatbotHandler
from datetime import datetime
import json

def test_user_model():
    """Testa se o modelo User tem o método get_session_data"""
    print("🔍 Testando modelo User...")
    
    try:
        # Cria usuário de teste
        user = User(
            telegram_id="123456789",
            name="Teste",
            current_state="START"
        )
        
        # Testa método get_session_data
        session_data = user.get_session_data()
        
        assert isinstance(session_data, dict), "get_session_data deve retornar um dict"
        assert 'current_state' in session_data, "session_data deve conter current_state"
        assert 'covenant_type' in session_data, "session_data deve conter covenant_type"
        
        print("✅ Modelo User: OK - método get_session_data funcionando")
        return True
        
    except Exception as e:
        print(f"❌ Modelo User: ERRO - {e}")
        return False

def test_appointment_model():
    """Testa se o modelo Appointment tem o campo scheduled_by"""
    print("🔍 Testando modelo Appointment...")
    
    try:
        # Verifica se o campo existe
        appointment = Appointment(
            user_id=1,
            exams='[]',
            total_price=0.0,
            covenant_type='PARTICULAR',
            scheduled_by='teste'
        )
        
        assert hasattr(appointment, 'scheduled_by'), "Appointment deve ter campo scheduled_by"
        
        print("✅ Modelo Appointment: OK - campo scheduled_by presente")
        return True
        
    except Exception as e:
        print(f"❌ Modelo Appointment: ERRO - {e}")
        return False

def test_chatbot_handler():
    """Testa o ChatbotHandler"""
    print("🔍 Testando ChatbotHandler...")
    
    try:
        handler = ChatbotHandler()
        
        # Testa processamento de mensagem
        user_data = {
            'id': 123456789,
            'first_name': 'Teste',
            'last_name': 'Usuario'
        }
        
        message_data = {
            'type': 'text',
            'text': '/start'
        }
        
        # Simula processamento (sem banco de dados)
        print("✅ ChatbotHandler: OK - instanciação funcionando")
        return True
        
    except Exception as e:
        print(f"❌ ChatbotHandler: ERRO - {e}")
        return False

def test_callback_processing():
    """Testa processamento de callbacks"""
    print("🔍 Testando processamento de callbacks...")
    
    try:
        handler = ChatbotHandler()
        
        # Cria usuário mock
        class MockUser:
            def __init__(self):
                self.current_state = 'START'
                self.covenant_type = None
                self.selected_exams = None
                self.total_price = 0.0
                self.last_interaction = datetime.utcnow()
            
            def clear_exams(self):
                self.selected_exams = None
                self.total_price = 0.0
            
            def get_selected_exams(self):
                return [] if not self.selected_exams else json.loads(self.selected_exams)
        
        user = MockUser()
        
        # Testa callback de convênio
        result = handler._process_callback_message(user, 'covenant_particular')
        
        assert isinstance(result, dict), "Callback deve retornar dict"
        assert 'text' in result, "Resultado deve conter texto"
        
        print("✅ Callback Processing: OK - processamento funcionando")
        return True
        
    except Exception as e:
        print(f"❌ Callback Processing: ERRO - {e}")
        return False

def test_session_management():
    """Testa gerenciamento de sessão"""
    print("🔍 Testando gerenciamento de sessão...")
    
    try:
        handler = ChatbotHandler()
        
        # Testa métodos de sessão
        assert hasattr(handler, 'cleanup_expired_sessions'), "Handler deve ter cleanup_expired_sessions"
        assert hasattr(handler, 'get_session_stats'), "Handler deve ter get_session_stats"
        
        print("✅ Session Management: OK - métodos presentes")
        return True
        
    except Exception as e:
        print(f"❌ Session Management: ERRO - {e}")
        return False

def main():
    """Executa todos os testes"""
    print("🚀 Iniciando testes de correções do ECOS Chatbot\n")
    
    tests = [
        test_user_model,
        test_appointment_model,
        test_chatbot_handler,
        test_callback_processing,
        test_session_management
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
        print()
    
    print(f"📊 Resultado dos testes: {passed}/{total} passaram")
    
    if passed == total:
        print("🎉 Todos os testes passaram! Sistema corrigido com sucesso.")
        return True
    else:
        print("⚠️ Alguns testes falharam. Verifique os erros acima.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
